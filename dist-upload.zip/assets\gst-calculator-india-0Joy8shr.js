const n=`---\r
title: "GST Calculator India — Quick Guide for Small Businesses"\r
slug: "gst-calculator-india"\r
date: "2026-02-21"\r
meta: "Understand GST calculation, input tax credit, and how to use a GST calculator for invoicing and pricing."\r
tags: [gst, india, finance]\r
---\r
\r
GST affects pricing, invoicing, and profitability for Indian businesses. This guide explains the basic GST structure, calculating GST on products and services, and applying input tax credit. We walk through examples and show how to use the Stravotech GST Calculator for quick estimates. Small businesses and freelancers will find tips on pricing with GST included, issuing GST-compliant invoices, and how to avoid common mistakes.\r
\r
## H2 Outline\r
- GST basics and rates\r
- Calculating GST on invoice amount\r
- Input tax credit example\r
- Using Stravotech GST calculator\r
- Pricing tips and common pitfalls\r
`;export{n as default};
