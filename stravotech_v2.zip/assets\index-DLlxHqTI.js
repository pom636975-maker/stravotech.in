const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/GPAInterface-ArcEgwev.js","assets/vendor_react-tsqR90HE.js","assets/vendor-C4f9BiX6.js","assets/WordCounterInterface-B_YRmQfw.js","assets/MortgageInterface-CaXIquei.js","assets/TipInterface-LGFZbgFF.js","assets/InvoiceInterface-WSIA29C5.js","assets/PercentageInterface-DOnYbU6M.js","assets/SalaryHourlyInterface-__4qjMCj.js","assets/EssayEstimatorInterface-SRdqMMY9.js","assets/StudyTimeInterface-DtsNSQSz.js","assets/LoanInterface-DT4D90Wn.js","assets/SalesTaxInterface-Dljg4F1J.js","assets/AgeInterface-2p6tLuyh.js","assets/ROIInterface-B3wWbBc1.js","assets/TimeZoneInterface-DrYsaIJN.js","assets/UnitConverterInterface-DqnMmA9i.js","assets/SavingsInterface-BlH0WvNr.js","assets/PasswordGeneratorInterface-C1J7Y6yO.js","assets/HealthCalculatorInterface-CXahS2Kv.js","assets/ScientificCalculatorInterface-DNeaATC2.js","assets/ImageToPdfInterface-BWyDaYhe.js","assets/ImageCompressorInterface-BQvgF4o0.js","assets/ImageResizerInterface-DzkOkqqj.js","assets/QRCodeInterface-Dy8N-IMA.js","assets/JSONFormatterInterface-B8rduLww.js","assets/MarkdownInterface-CdQIRdJJ.js","assets/Base64Interface-DEuThtqS.js","assets/BinaryConverterInterface-jRBFmxNu.js","assets/StatsInterface-BNbKYhhC.js","assets/ColorPickerInterface-Dl1w2p6i.js","assets/TaxRefundInterface-SXkWZJIi.js","assets/StockProfitInterface-CG7uwFW3.js","assets/FuelCostInterface-DcLs_VTK.js","assets/InvestmentGrowthInterface-R2m3Pqgm.js"])))=>i.map(i=>d[i]);
import{r as p,u as B,b as M,j as e,L as g,W as ie,c as O,R as le,d as ce,B as de,e as ue,f as y,N as X,h as Z,i as me,q as he}from"./vendor_react-tsqR90HE.js";import{g as H,c as pe,d as ge,e as fe,f as xe,h as ye,b as be,s as ve,j as ee,w as we,k as F,l as K,m as W,u as je,n as Pe,p as U,q as te,v as Ce,x as ke,y as Ne,z as Se,A as G,G as Ae,B as Te}from"./vendor-C4f9BiX6.js";(function(){const s=document.createElement("link").relList;if(s&&s.supports&&s.supports("modulepreload"))return;for(const t of document.querySelectorAll('link[rel="modulepreload"]'))l(t);new MutationObserver(t=>{for(const c of t)if(c.type==="childList")for(const d of c.addedNodes)d.tagName==="LINK"&&d.rel==="modulepreload"&&l(d)}).observe(document,{childList:!0,subtree:!0});function o(t){const c={};return t.integrity&&(c.integrity=t.integrity),t.referrerPolicy&&(c.referrerPolicy=t.referrerPolicy),t.crossOrigin==="use-credentials"?c.credentials="include":t.crossOrigin==="anonymous"?c.credentials="omit":c.credentials="same-origin",c}function l(t){if(t.ep)return;t.ep=!0;const c=o(t);fetch(t.href,c)}})();const Ie={apiKey:"AIzaSyBFFspGRLmoDRAGlg71m5cdy_QQCzHJCKk",authDomain:"stravotech-28862.firebaseapp.com",projectId:"stravotech-28862",storageBucket:"stravotech-28862.firebasestorage.app",messagingSenderId:"529111148262",appId:"1:529111148262:web:acc34f861ae7b3996f3d27",measurementId:"G-RKZ634SRHP"},z=H().length?H()[0]:pe(Ie),I=ge(z),A=fe(z);let Ee=null;(async()=>{if(typeof window!="undefined")try{await xe()&&(Ee=ye(z))}catch{}})();const ae=[{id:"gpa-calculator",name:"GPA Calculator",description:"Calculate your college GPA based on the standard 4.0 scale used in the USA.",path:"/student/gpa-calculator",category:"student",icon:"fa-graduation-cap",seoTitle:"Free GPA Calculator Online – Calculate GPA from Marks & Percentage | Stravotech",seoDescription:"Free GPA calculator online: calculate GPA from marks, convert GPA to percentage, use GPA calculator for university (4.0, 4.3, 10.0 scales). No sign-up required.",seoKeywords:"free gpa calculator, gpa calculator online, how to calculate gpa from marks, gpa calculator university, gpa in percentage, 4.0 gpa calculator, cgpa calculator",longDescription:"Our GPA Calculator is designed for students in the United States and Canada following a standard 4.0 grading scale. Whether you are tracking your semester performance or estimating your final cumulative GPA, this tool provides precise calculations based on credits and letter grades. It supports both weighted and unweighted scales, making it perfect for High School and College students.",faqs:[{question:"What is a 4.0 GPA scale?",answer:"The 4.0 scale is the most common grading system in the US, where an A equals 4 points, a B equals 3, a C equals 2, a D equals 1, and an F equals 0."},{question:"Do weighted GPAs count differently?",answer:"Yes, weighted GPAs (often up to 5.0) account for the difficulty of Honors or AP courses. Our tool allows you to toggle between weighted and unweighted."}]},{id:"percentage-calculator",name:"Percentage Calculator",description:"Quickly find percentages, increases, or decreases.",path:"/student/percentage-calculator",category:"student",icon:"fa-percent",seoTitle:"Free Percentage Calculator Online – Calculate % Changes Instantly | Stravotech",seoDescription:"Accurate and fast online percentage calculator. Calculate percentage increases, find % changes, tips, and discounts instantly. Free to use with no sign-up.",seoKeywords:"percentage calculator, free percentage calculator, percentage increase calculator, percent calculator online, percentage difference",longDescription:"The Percentage Calculator is a versatile tool for students and professionals. Calculate what percentage one number is of another, find the percentage change between two values, or calculate tips and discounts instantly. Perfect for retail discounts, statistical analysis, and homework.",faqs:[{question:"How do I calculate a percentage increase?",answer:"Subtract the original value from the new value, divide by the original value, and multiply by 100."},{question:"Is this useful for business?",answer:"Absolutely. Business owners use it for calculating profit margins, growth rates, and markups."}]},{id:"word-counter",name:"Word Counter",description:"Count words, characters, and sentences for essays and reports.",path:"/student/word-counter",category:"student",icon:"fa-file-lines",seoTitle:"Free Online Word Counter – Track Word and Character Counts Fast | Stravotech",seoDescription:"Use our free online word counter for instant analysis of your text. Track word count, character count, and reading time for SEO, essays, and reports.",seoKeywords:"word counter, free online word counter, character counter, word count tool, count words and characters, seo word counter",longDescription:"Ideal for writers, students, and SEO professionals, our Word Counter provides real-time analysis of your text. It tracks word count, character count (with and without spaces), and even estimates reading and speaking time based on average North American speeds.",faqs:[{question:"Are spaces included in character count?",answer:"We provide both counts: characters with spaces and characters without spaces."},{question:"What is the average reading speed used?",answer:"We use 225 words per minute, which is the standard average for an adult reader."}]},{id:"scientific-calculator",name:"Scientific Calculator",description:"Advanced math operations for students and engineers.",path:"/student/scientific-calculator",category:"student",icon:"fa-calculator",seoTitle:"Free Scientific Calculator Online – Advanced Mathematical Tool | Stravotech",seoDescription:"Use our free online scientific calculator for complex math operations. Features trigonometric functions, logs, roots, and basic math. Perfect for students and engineers.",seoKeywords:"scientific calculator, free scientific calculator, online scientific calculator, advanced math calculator, trigonometry calculator",longDescription:"A robust scientific calculator for solving complex mathematical problems. Features support for trigonometric functions, logarithms, square roots, and basic arithmetic. Essential for STEM students and engineering professionals.",faqs:[{question:"Does it support radians?",answer:"Yes, our calculator defaults to radians for trigonometric functions, suitable for advanced calculus."},{question:"Is it mobile-friendly?",answer:"Absolutely, the scientific layout adjusts perfectly to your touch screen."}]},{id:"bmi-bmr-calculator",name:"BMI & BMR Tracker",description:"Calculate your Body Mass Index and Metabolic Rate.",path:"/student/bmi-bmr-calculator",category:"student",icon:"fa-heart-pulse",seoTitle:"Free BMI & BMR Calculator – Calculate Body Mass & Metabolic Rate | Stravotech",seoDescription:"Use our free BMI and BMR calculator to track your health. Calculate Body Mass Index and Basal Metabolic Rate accurately with North American medical standards.",seoKeywords:"bmi calculator, bmr calculator, body mass index, basal metabolic rate, free health calculator",longDescription:"Health is the foundation of productivity. Calculate your BMI to check your health category and BMR to understand your daily caloric needs based on age, height, and weight. Uses standard medical formulas used in North America.",faqs:[{question:"What is BMI?",answer:"Body Mass Index (BMI) is a measure of body fat based on height and weight that applies to adult men and women."},{question:"What is BMR?",answer:"Basal Metabolic Rate (BMR) is the number of calories your body needs to accomplish its most basic life-sustaining functions."}]},{id:"mortgage-calculator",name:"Mortgage Calculator",description:"Estimate your monthly mortgage payments for USA home loans.",path:"/finance/mortgage-calculator",category:"finance",icon:"fa-house-chimney",seoTitle:"Free Mortgage Calculator – Calculate US Home Loan Payments | Stravotech",seoDescription:"Estimate your monthly US mortgage payments with our free mortgage calculator. Calculate principal, interest, and loan terms accurately. No sign-up required.",seoKeywords:"mortgage calculator, us mortgage calculator, free home loan calculator, monthly mortgage payment estimate, mortgage amortization table",longDescription:"Plan your home purchase with our USA-focused Mortgage Calculator. Input the home price, down payment, interest rate, and loan term to see your estimated monthly principal and interest payments. It provides a visual breakdown of your debt-to-equity ratio over time.",faqs:[{question:"Does this include PMI?",answer:"Our basic calculator focuses on Principal and Interest. Taxes, Insurance, and PMI vary by location and down payment and should be added separately."},{question:"Should I choose 15 or 30 years?",answer:"A 15-year term has higher monthly payments but significantly lower total interest cost compared to a 30-year term."}]},{id:"savings-calculator",name:"Savings Planner",description:"Calculate compound interest and future wealth.",path:"/finance/savings-calculator",category:"finance",icon:"fa-piggy-bank",seoTitle:"Free Savings Calculator – Compound Interest & Future Value | Stravotech",seoDescription:"Plan your financial future with our free savings calculator. Calculate compound interest and future wealth growth over time. No sign-up required.",seoKeywords:"savings calculator, compound interest calculator, future value calculator, investment planner, wealth growth tool",longDescription:"Visualize your financial future. This tool calculates the growth of your savings account using compound interest. Input your initial deposit, monthly contributions, and expected interest rate to see your wealth grow over time.",faqs:[{question:"What is compound interest?",answer:"It is interest calculated on the initial principal, which also includes all the accumulated interest from previous periods."},{question:"How often does this compound?",answer:"Our calculator defaults to monthly compounding, which is standard for most North American savings accounts."}]},{id:"salary-to-hourly",name:"Salary to Hourly",description:"Convert your annual salary into an hourly wage.",path:"/finance/salary-to-hourly",category:"finance",icon:"fa-money-bill-transfer",seoTitle:"Free Salary to Hourly Converter – Calculate Your Hourly Rate | Stravotech",seoDescription:"Convert your annual salary to an hourly wage instantly. Break down your income into hourly, daily, and weekly rates. Perfect for comparing jobs.",seoKeywords:"salary to hourly, pay converter, hourly wage calculator, annual salary to hourly rate, income breakdown tool",longDescription:"Ever wondered exactly how much you make per hour? This tool breaks down your annual salary into hourly, daily, and weekly rates based on a standard 40-hour work week. Great for comparing job offers and evaluating your time worth.",faqs:[{question:"How many working hours are in a year?",answer:"Usually 2,080 hours (40 hours per week * 52 weeks)."}]},{id:"tax-refund-calculator",name:"Tax Refund Calculator",description:"Estimate your tax refund based on income, deductions, and credits.",path:"/finance/tax-refund-calculator",category:"finance",icon:"fa-calculator",seoTitle:"Free Tax Refund Calculator 2026 – Estimate Your Refund Instantly | Stravotech",seoDescription:"Use our free tax refund calculator to estimate your 2026 refund quickly. Accurate tool for taxpayers to calculate potential savings from income and credits.",seoKeywords:"tax refund calculator, estimate tax refund, 2026 tax calculator, free income tax tool, tax credit estimator",longDescription:"Calculate your potential tax refund for 2026. Input your annual income, deductions, tax credits, and effective tax rate to get an instant estimate. Perfect for tax planning and understanding your refund amount.",faqs:[{question:"What is a tax refund?",answer:"A tax refund is the amount the IRS returns when you've overpaid your taxes throughout the year."},{question:"How accurate is this calculator?",answer:"This provides an estimate. Consult a tax professional for precise calculations."}]},{id:"stock-profit-calculator",name:"Stock Profit Calculator",description:"Calculate gains or losses from stock investments.",path:"/finance/stock-profit-calculator",category:"finance",icon:"fa-chart-line",seoTitle:"Free Stock Profit Calculator - Calculate Your Investment Returns Instantly | Stravotech",seoDescription:"Use our free stock profit calculator to estimate gains or losses on your investments. Simple tool for tracking stock performance and returns.",longDescription:"Track your stock investment performance. Enter buy price, sell price, and number of shares to calculate total profit or loss and percentage return. Essential for investors monitoring their portfolio.",faqs:[{question:"Does this include fees?",answer:"No, this is a basic calculator. Add brokerage fees separately for accurate results."},{question:"What if I have dividends?",answer:"This focuses on capital gains/losses. Dividends should be calculated separately."}]},{id:"fuel-cost-calculator",name:"Fuel Cost Calculator",description:"Calculate fuel costs for trips and compare gas prices.",path:"/finance/fuel-cost-calculator",category:"finance",icon:"fa-gas-pump",seoTitle:"Free Fuel Cost Calculator - Calculate Trip Fuel Expenses | Stravotech",seoDescription:"Calculate fuel costs for your trips with our free fuel cost calculator. Compare gas prices and plan your travel budget efficiently.",longDescription:"Plan your travel expenses with our fuel cost calculator. Input distance, fuel efficiency, and gas prices to calculate total fuel costs. Compare different vehicles and routes to save money.",faqs:[{question:"How accurate is this calculator?",answer:"It provides estimates based on your inputs. Actual costs may vary with driving conditions."},{question:"Does it include taxes?",answer:"No, fuel taxes vary by location. Add them separately for precise calculations."}]},{id:"investment-growth-calculator",name:"Investment Growth Calculator",description:"Calculate compound interest and investment growth over time.",path:"/finance/investment-growth-calculator",category:"finance",icon:"fa-chart-area",seoTitle:"Free Investment Growth Calculator – Compound Interest Planner | Stravotech",seoDescription:"Calculate how your investments grow over time with compound interest. Free investment growth calculator for long-term retirement and wealth planning.",seoKeywords:"investment growth calculator, compound interest tool, future investment value, wealth planner, long term savings calculator",longDescription:"See how your money grows with compound interest. Input initial investment, monthly contributions, interest rate, and time period to calculate future value. Perfect for retirement planning and investment goals.",faqs:[{question:"What is compound interest?",answer:"Interest earned on both the initial principal and the accumulated interest from previous periods."},{question:"How often does it compound?",answer:"Our calculator uses monthly compounding, which is standard for most investments."}]},{id:"invoice-generator",name:"Invoice Generator",description:"Create professional invoices for free and export to PDF.",path:"/work/invoice-generator",category:"work",icon:"fa-file-invoice-dollar",seoTitle:"Free Invoice Generator Online – Create and Export PDF Invoices | Stravotech",seoDescription:"Use our free online invoice generator to create professional invoices in seconds. Export to PDF with no watermarks or registration required. Perfect for freelancers.",seoKeywords:"invoice generator, free invoice maker, create pdf invoice online, professional invoice generator, freelancer invoice tool",longDescription:"Simple, clean, and professional. Use our invoice generator to create billing documents for your clients in seconds. Fill out the details, add line items, and print to PDF. No watermarks, no registration.",faqs:[{question:"Is my data stored?",answer:"No. Your invoice data is processed entirely in your browser. Refreshing the page will clear the data for your security."}]},{id:"password-generator",name:"Secure Password Creator",description:"Generate strong, hack-proof passwords instantly.",path:"/work/password-generator",category:"work",icon:"fa-shield-halved",seoTitle:"Secure Password Generator – Create Strong & Hack-Proof Passwords | Stravotech",seoDescription:"Generate strong, secure, and random passwords instantly with our hack-proof password creator. Customize length, symbols, and numbers for maximum security.",seoKeywords:"password generator, secure password creator, random password generator, strong password maker, hack proof passwords",longDescription:"Protect your digital life. Generate high-entropy, random passwords using symbols, numbers, and mixed-case letters. Essential for maintaining security in professional and personal accounts.",faqs:[{question:"What makes a password strong?",answer:"Length and character variety. At least 12-16 characters with symbols and numbers is recommended."},{question:"Are my passwords saved?",answer:"Never. Everything is generated on the fly and discarded once you leave the page."}]},{id:"unit-converter",name:"Unit Converter",description:"Convert length, weight, and temperature units.",path:"/work/unit-converter",category:"work",icon:"fa-scale-balanced",seoTitle:"Free Unit Converter Online – Length, Weight, Temperature | Stravotech",seoDescription:"Use our free online unit converter to switch between metric and imperial systems. Convert length, weight, and temperature instantly and accurately.",seoKeywords:"unit converter, free unit converter, online measurement converter, length and weight converter, metric to imperial converter",longDescription:"A comprehensive converter for everyday units. Switch between Metric and Imperial systems effortlessly. Perfect for international business, cooking, and academic assignments.",faqs:[{question:"Does it support Celsius to Fahrenheit?",answer:"Yes, temperature conversion is fully supported with precise accuracy."},{question:"Is it useful for US/Canada travel?",answer:"Perfect for converting Miles to Kilometers and Pounds to Kilograms across the border."}]},{id:"essay-word-estimator",name:"Essay Word Estimator",description:"Estimate the number of words based on pages and font size.",path:"/student/essay-word-estimator",category:"student",icon:"fa-pen-nib",seoTitle:"Free Essay Word Estimator – Calculate Words per Page | Stravotech",seoDescription:"Estimate the number of words in your essay based on page count, font size, and spacing. Perfect for MLA/APA academic formatting planning.",seoKeywords:"essay word estimator, words per page calculator, academic word count estimator, mla word count, apa word count guide",longDescription:"Need to know how many words are in a 5-page double-spaced essay? This tool estimates the word count based on standard North American academic formatting (MLA/APA). Ideal for students planning their assignments.",faqs:[{question:"How many words are on a standard page?",answer:"Usually 275 words for double-spaced and 550 for single-spaced (Times New Roman 12pt)."}]},{id:"study-time-calculator",name:"Study Time Calculator",description:"Plan your study sessions based on material complexity.",path:"/student/study-time-calculator",category:"student",icon:"fa-clock",seoTitle:"Free Study Time Calculator – Plan Your Learning Sessions | Stravotech",seoDescription:"Estimate how long you need to study based on material difficulty and the Pomodoro method. Plan your academic sessions for maximum efficiency.",seoKeywords:"study time calculator, learning time estimator, academic planning tool, pomodoro study planner, exam preparation tool",longDescription:"Manage your time effectively with our Study Time Calculator. Tell us how much you need to read or learn, and we will estimate how long it will take based on subject difficulty and the Pomodoro method.",faqs:[{question:"What are focus blocks?",answer:"These are intervals of 25-30 minutes of deep study followed by a short break, optimized for maximum retention."}]},{id:"loan-payment-calculator",name:"Loan Payment Calculator",description:"Calculate monthly payments for any type of loan.",path:"/finance/loan-payment-calculator",category:"finance",icon:"fa-hand-holding-dollar",seoTitle:"Free Loan Payment Calculator – Monthly EMI & Interest Estimate | Stravotech",seoDescription:"Calculate your monthly loan payments and total interest for personal, auto, or home loans. See your amortization schedule instantly with our free calculator.",seoKeywords:"loan payment calculator, emi calculator, monthly loan payment, interest calculator, loan amortization tool",longDescription:"Whether it is a personal loan, auto loan, or business loan, calculate your monthly amortization and total interest paid over the life of the loan. Plan your payoff strategy with ease.",faqs:[{question:"How does interest affect my loan?",answer:"Higher interest rates increase your monthly payment and the total amount you pay back over time."}]},{id:"hourly-to-salary",name:"Hourly to Salary",description:"Convert your hourly rate into an annual salary.",path:"/finance/hourly-to-salary",category:"finance",icon:"fa-briefcase",seoTitle:"Free Hourly to Salary Converter – Annual Income Calculator | Stravotech",seoDescription:"Convert your hourly wage into an annual salary instantly. Calculate your yearly earning potential based on work hours and pay rate. Free to use.",seoKeywords:"hourly to salary, wage converter, hourly to annual income, pay rate calculator, salary estimator",longDescription:"Find out your equivalent annual income from an hourly rate. Useful for freelancers, contract workers, and part-time employees evaluating their yearly earning potential.",faqs:[{question:"Does this include taxes?",answer:"This tool calculates gross (pre-tax) income. Your net (take-home) pay will be lower depending on your tax bracket."}]},{id:"sales-tax-calculator",name:"Sales Tax Calculator",description:"Calculate USA state-specific sales tax amounts.",path:"/finance/sales-tax-calculator",category:"finance",icon:"fa-receipt",seoTitle:"Free Sales Tax Calculator – US State Tax Rate Lookup | Stravotech",seoDescription:"Calculate sales tax for all 50 US states. Find total price including state tax rates instantly with our free online calculator.",seoKeywords:"sales tax calculator, us sales tax, state tax rate calculator, total price with tax, sales tax lookup",longDescription:"Calculate the total price of an item including sales tax. Choose from all 50 US states to get approximate base rates for your purchases and budgeting.",faqs:[{question:"Are local taxes included?",answer:"This tool uses state-level base rates. County or city-level taxes may apply in addition to these rates."}]},{id:"age-calculator",name:"Age Calculator",description:"Find out your exact age in years, months, and days.",path:"/work/age-calculator",category:"work",icon:"fa-calendar-days",seoTitle:"Free Age Calculator – Calculate Your Exact Age Online | Stravotech",seoDescription:"Find your exact age in years, months, and days. Calculate time elapsed between two dates with our fast and accurate online age calculator.",seoKeywords:"age calculator, calculate age online, exact age finder, date difference calculator, age in days months years",longDescription:"Calculate your exact age or the time elapsed between two specific dates down to the day. Useful for legal documents, milestone tracking, and birthday planning.",faqs:[{question:"How are leap years handled?",answer:"Our algorithm accounts for the 366th day in leap years to ensure perfect accuracy."}]},{id:"roi-calculator",name:"ROI Calculator",description:"Measure the efficiency of an investment.",path:"/work/roi-calculator",category:"work",icon:"fa-chart-line",seoTitle:"Free ROI Calculator – Investment Efficiency & Profitability | Stravotech",seoDescription:"Calculate Return on Investment (ROI) instantly. Measure the efficiency of your investments and track profitability with our free online tool.",seoKeywords:"roi calculator, return on investment, investment profit calculator, profitability ratio, measure investment efficiency",longDescription:"Return on Investment (ROI) is a key metric for business and personal finance. Calculate your profit percentage by comparing net gains to initial costs.",faqs:[{question:"What is a good ROI?",answer:"This varies by industry. Generally, a positive ROI is good, but many investors look for at least 7-10% annually."}]},{id:"tip-calculator",name:"Tip Calculator",description:"Calculate tips and split bills with ease.",path:"/work/tip-calculator",category:"work",icon:"fa-coins",seoTitle:"Free Tip Calculator – Calculate Tips & Split Bills Instantly | Stravotech",seoDescription:"Use our free tip calculator to calculate tips and split bills with friends easily. Supports standard US and Canada tipping practices.",seoKeywords:"tip calculator, split bill calculator, dining tip calculator, restaurant tip tool, calculate tip online",longDescription:"Dine out without the math. Calculate your tip based on common service standards and split the final bill among friends or colleagues instantly.",faqs:[{question:"What is the standard tip in USA/Canada?",answer:"Standard tipping is usually 15% for good service and 18-20% for excellent service."}]},{id:"timezone-converter",name:"Time Zone Converter",description:"Compare USA and Canada time zones quickly.",path:"/work/timezone-converter",category:"work",icon:"fa-earth-americas",seoTitle:"Free Time Zone Converter – North America Time Comparison | Stravotech",seoDescription:"Compare USA and Canada time zones instantly. Convert time between PT, MT, CT, and ET for meetings and travel planning.",seoKeywords:"time zone converter, us time zones, canada time zones, time conversion tool, world clock comparison",longDescription:"A simple way to check the time differences across North American time zones for meetings, travel, and remote work coordination.",faqs:[{question:"Does this handle Daylight Savings?",answer:"Yes, the tool uses your browser's current locale data which automatically adjusts for seasonal time changes."}]},{id:"image-to-pdf",name:"Image to PDF",description:"Convert JPG/PNG images into high-quality PDF files.",path:"/work/image-to-pdf",category:"work",icon:"fa-file-pdf",seoTitle:"Free Image to PDF Converter – JPG/PNG to PDF Online | Stravotech",seoDescription:"Convert your images to high-quality PDF files instantly. Supports JPG, PNG, and WebP. Secure, client-side processing for professional documents.",seoKeywords:"image to pdf, jpg to pdf converter, png to pdf, convert images to pdf online, secure image converter",longDescription:"Easily convert multiple images into a single professional PDF document. Perfect for submitting assignments, digitizing receipts, or creating portfolios. All processing is done client-side for maximum privacy.",faqs:[{question:"Can I convert multiple images?",answer:"Yes, you can upload and stack multiple images into one document."},{question:"Is my data private?",answer:"Absolutely. Images never leave your browser."}]},{id:"image-compressor",name:"Image Compressor",description:"Reduce image file size without losing quality.",path:"/work/image-compressor",category:"work",icon:"fa-compress",seoTitle:"Free Image Compressor Online – Reduce File Size Securely | Stravotech",seoDescription:"Optimize your images with our free online image compressor. Reduce file sizes for JPG, PNG, and WebP while maintaining quality. Fast and private.",seoKeywords:"image compressor, reduce image size online, photo compressor, optimize images for web, free image size reducer",longDescription:"Optimize your images for the web. Our compressor reduces file sizes significantly while maintaining visual fidelity. Useful for bloggers, developers, and slow-internet environments.",faqs:[{question:"What formats are supported?",answer:"Supports JPG, PNG, and WebP."}]},{id:"image-resizer",name:"Image Resizer",description:"Change image dimensions in pixels or percentage.",path:"/work/image-resizer",category:"work",icon:"fa-up-down-left-right",seoTitle:"Free Image Resizer Online – Change Photo Dimensions Fast | Stravotech",seoDescription:"Resize images to exact pixels or percentage scale. Simple online image resizer for JPG, PNG, and WebP. Maintain aspect ratio easily.",seoKeywords:"image resizer, resize photo online, change image dimensions, pixel resizer, scale image online",longDescription:"Resize images to exact pixel dimensions or scale them by percentage. Ideal for social media posts, profile pictures, and web content.",faqs:[{question:"Can I maintain aspect ratio?",answer:"Yes, we include a lock to ensure your images don't get stretched."}]},{id:"qr-code-generator",name:"QR Code Generator",description:"Create custom QR codes for links, text, or Wi-Fi.",path:"/work/qr-code-generator",category:"work",icon:"fa-qrcode",seoTitle:"Free QR Code Generator – Create Custom QR Codes Instantly | Stravotech",seoDescription:"Generate custom QR codes for websites, text, or Wi-Fi. Free online QR code maker with high-resolution downloads.",seoKeywords:"qr code generator, free qr code maker, create qr code online, custom qr codes, wifi qr code generator",longDescription:"Generate high-resolution QR codes instantly. Use them for marketing, contactless menus, or sharing complex URLs easily on printed materials.",faqs:[{question:"Do these QR codes expire?",answer:"No, these are static QR codes and will work indefinitely."}]},{id:"json-formatter",name:"JSON Formatter",description:"Prettify and validate JSON code for developers.",path:"/work/json-formatter",category:"work",icon:"fa-code",seoTitle:"Free JSON Formatter & Validator Online – Prettify JSON | Stravotech",seoDescription:"Format and validate your JSON code instantly. Make messy JSON readable and find syntax errors with our free online tool.",seoKeywords:"json formatter, json validator, prettify json, format json online, json beautifier",longDescription:"Clean up messy JSON data into a readable format. Our tool also validates syntax to help you find bugs in your data structures.",faqs:[{question:"Can it handle large files?",answer:"Yes, it can prettify thousands of lines of code in milliseconds."}]},{id:"markdown-previewer",name:"Markdown Preview",description:"Real-time preview for Markdown files and READMEs.",path:"/work/markdown-previewer",category:"work",icon:"fa-markdown",seoTitle:"Free Markdown Previewer – Real-time Markdown Editor | Stravotech",seoDescription:"Write and preview Markdown code in real-time. See live rendering of GitHub Flavored Markdown for READMEs and documentation.",seoKeywords:"markdown previewer, live markdown editor, gfm preview, markdown to html, online markdown viewer",longDescription:"Write Markdown code and see the rendered HTML instantly. Perfect for GitHub contributors and technical writers.",faqs:[{question:"Supports GitHub flavor?",answer:"Yes, we use standard GFM (GitHub Flavored Markdown) standards."}]},{id:"base64-converter",name:"Base64 Converter",description:"Encode or decode text to Base64 format.",path:"/work/base64-converter",category:"work",icon:"fa-shield-heart",seoTitle:"Free Base64 Encoder & Decoder – Secure Text Conversion | Stravotech",seoDescription:"Encode text to Base64 or decode Base64 strings back to text instantly. Secure, private, and client-side processing.",seoKeywords:"base64 converter, base64 encoder, base64 decoder, text to base64, online conversion tool",longDescription:"Simple utility to encode plain text into Base64 or decode Base64 strings back to readable text. Crucial for developers and data transmission tasks.",faqs:[{question:"Is it secure?",answer:"Yes, Base64 is an encoding, not encryption, but we handle it all locally."}]},{id:"binary-converter",name:"Binary Converter",description:"Convert between Decimal, Binary, and Hexadecimal.",path:"/student/binary-converter",category:"student",icon:"fa-microchip",seoTitle:"Free Binary Converter – Decimal, Binary & Hexadecimal | Stravotech",seoDescription:"Convert between decimal, binary, and hexadecimal numbering systems. Essential tool for computer science students and programmers.",seoKeywords:"binary converter, decimal to binary, hexadecimal converter, base conversion, programming tool",longDescription:"A vital tool for Computer Science students. Convert numbers between base 10, base 2, and base 16 instantly with step-by-step logic hints.",faqs:[{question:"What is Hexadecimal?",answer:"A base-16 numbering system used frequently in computing to represent colors and memory addresses."}]},{id:"stats-calculator",name:"Statistics Calc",description:"Find Mean, Median, Mode, and Standard Deviation.",path:"/student/stats-calculator",category:"student",icon:"fa-chart-simple",seoTitle:"Free Statistics Calculator – Mean, Median, Mode & SD | Stravotech",seoDescription:"Perform statistical analysis on your data sets. Calculate mean, median, mode, variance, and standard deviation instantly.",seoKeywords:"statistics calculator, mean median mode, standard deviation calculator, variance calculator, data analysis tool",longDescription:"Enter a set of numbers to get a full statistical breakdown. Ideal for social science research, lab reports, and math homework.",faqs:[{question:"Does it calculate Variance?",answer:"Yes, we provide both population and sample standard deviation/variance."}]},{id:"color-picker",name:"Color Contrast Checker",description:"Check accessibility and pick professional colors.",path:"/work/color-picker",category:"work",icon:"fa-palette",seoTitle:"Free Color Contrast Checker – WCAG Accessibility Tool | Stravotech",seoDescription:"Check text and background color contrast for WCAG 2.1 accessibility. Pick professional colors and ensure your designs are inclusive.",seoKeywords:"color picker, contrast checker, wcag accessibility, accessible design tool, hex color picker",longDescription:"Ensure your designs are accessible. Check contrast ratios against WCAG 2.1 standards and pick perfect HEX/RGB combinations for your next project.",faqs:[{question:"What is WCAG?",answer:"Web Content Accessibility Guidelines, ensuring the web is usable for people with visual impairments."}]}],ft={AL:4,AK:0,AZ:5.6,AR:6.5,CA:7.25,CO:2.9,CT:6.35,DE:0,FL:6,GA:4,HI:4,ID:6,IL:6.25,IN:7,IA:6,KS:6.5,KY:6,LA:4.45,ME:5.5,MD:6,MA:6.25,MI:6,MN:6.875,MS:7,MO:4.225,MT:0,NE:5.5,NV:6.85,NH:0,NJ:6.625,NM:5.125,NY:4,NC:4.75,ND:5,OH:5.75,OK:4.5,OR:0,PA:6,RI:7,SC:6,SD:4.5,TN:7,TX:6.25,UT:6.1,VT:6,VA:5.3,WA:6.5,WV:6,WI:5,WY:4},L=()=>{const[a,s]=p.useState(null),[o,l]=p.useState(!0);return p.useEffect(()=>be(I,c=>{s(c),l(!1)}),[]),{user:a,loading:o}},j=({children:a})=>{const[s,o]=p.useState(!1),[l,t]=p.useState("");B();const c=M(),d=p.useMemo(()=>l.trim()?ae.filter(n=>n.name.toLowerCase().includes(l.toLowerCase())||n.category.toLowerCase().includes(l.toLowerCase())).slice(0,5):[],[l]),{user:r}=L(),u=[{name:"Student Tools",href:"/#student"},{name:"Finance",href:"/#finance"},{name:"Work Productivity",href:"/#work"},{name:"Holi Wishes",href:"/holi-generator"},{name:"About",href:"/about"}],i=r?[...u,{name:"My Designs",href:"/holi/dashboard"}]:u;return e.jsxs("div",{className:"min-h-screen flex flex-col",children:[e.jsxs("nav",{className:"sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200/60 shadow-sm",children:[e.jsx("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:e.jsxs("div",{className:"flex justify-between h-20 items-center",children:[e.jsxs(g,{to:"/",className:"flex items-center space-x-3 group flex-shrink-0",children:[e.jsx("div",{className:"w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-200 group-hover:rotate-12 transition-transform duration-300",children:e.jsx("i",{className:"fa-solid fa-bolt-lightning text-white text-xl"})}),e.jsxs("div",{className:"hidden sm:flex flex-col",children:[e.jsx("span",{className:"text-xl font-extrabold text-slate-900 tracking-tight leading-none",children:"Stravotech"}),e.jsx("span",{className:"text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1",children:"Professional Toolkit"})]})]}),e.jsxs("div",{className:"flex-grow max-w-md mx-6 relative hidden md:block",children:[e.jsxs("div",{className:"relative group",children:[e.jsx("i",{className:"fa-solid fa-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"}),e.jsx("input",{type:"text",placeholder:"Search 100+ tools...",className:"w-full pl-12 pr-4 py-2.5 bg-slate-100 border-none rounded-xl text-sm font-semibold focus:ring-2 focus:ring-indigo-500 transition-all outline-none",value:l,onChange:n=>t(n.target.value)})]}),d.length>0&&e.jsx("div",{className:"absolute top-full mt-2 w-full bg-white border border-slate-200 rounded-xl shadow-2xl z-[60] overflow-hidden",children:d.map(n=>e.jsxs("button",{onClick:()=>{c(n.path),t("")},className:"w-full px-5 py-3 text-left hover:bg-slate-50 flex items-center space-x-3 transition-colors",children:[e.jsx("i",{className:`fa-solid ${n.icon} text-indigo-500 w-5`}),e.jsx("span",{className:"text-sm font-bold text-slate-700",children:n.name})]},n.id))})]}),e.jsxs("div",{className:"hidden lg:flex items-center space-x-1",children:[i.map(n=>e.jsx(g,{to:n.href,className:"px-4 py-2 text-sm font-bold text-slate-600 hover:text-indigo-600 hover:bg-slate-50 rounded-lg transition-all",children:n.name},n.name)),e.jsx("div",{className:"h-6 w-px bg-slate-200 mx-4"}),e.jsx("a",{href:"https://github.com",target:"_blank",className:"w-10 h-10 flex items-center justify-center text-slate-400 hover:text-slate-900 transition-colors",children:e.jsx("i",{className:"fa-brands fa-github text-xl"})})]}),e.jsx("button",{className:"lg:hidden w-10 h-10 flex items-center justify-center rounded-lg bg-slate-50 border border-slate-200",onClick:()=>o(!s),children:e.jsx("i",{className:`fa-solid ${s?"fa-xmark":"fa-bars-staggered"} text-slate-700`})})]})}),s&&e.jsxs("div",{className:"lg:hidden border-t border-slate-100 bg-white py-6 px-4 space-y-2 animate-in slide-in-from-top duration-300",children:[e.jsxs("div",{className:"mb-4 relative",children:[e.jsx("i",{className:"fa-solid fa-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"}),e.jsx("input",{type:"text",placeholder:"Search tools...",className:"w-full pl-12 pr-4 py-3 bg-slate-100 border-none rounded-xl text-sm font-semibold focus:ring-2 focus:ring-indigo-500 outline-none",value:l,onChange:n=>t(n.target.value)})]}),i.map(n=>e.jsx(g,{to:n.href,className:"block px-4 py-3 text-base font-bold text-slate-700 hover:bg-indigo-50 hover:text-indigo-600 rounded-xl transition-colors",onClick:()=>o(!1),children:n.name},n.name))]})]}),e.jsx("main",{className:"flex-grow max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 pb-20",children:e.jsxs("div",{className:"flex flex-col lg:flex-row gap-12",children:[e.jsx("div",{className:"flex-grow",children:a}),e.jsx("aside",{className:"hidden lg:block w-[320px] flex-shrink-0",children:e.jsx("div",{className:"sticky top-28 space-y-8",children:e.jsxs("div",{className:"bg-gradient-to-br from-indigo-600 to-blue-700 p-8 rounded-3xl text-white shadow-xl shadow-indigo-100 relative overflow-hidden",children:[e.jsx("div",{className:"absolute top-0 right-0 w-32 h-32 bg-white/10 blur-2xl rounded-full translate-x-10 -translate-y-10"}),e.jsx("h3",{className:"text-xl font-bold mb-4",children:"Stravotech Pro"}),e.jsx("p",{className:"text-sm text-indigo-100 leading-relaxed mb-6",children:"Our tools are, and will always be, 100% free. We believe education and productivity shouldn't have a price tag."}),e.jsxs("div",{className:"flex items-center space-x-2",children:[e.jsx("div",{className:"flex -space-x-2",children:[1,2,3,4].map(n=>e.jsxs("div",{className:"w-8 h-8 rounded-full border-2 border-indigo-500 bg-indigo-400 flex items-center justify-center text-[10px] font-bold",children:["U",n]},n))}),e.jsx("div",{className:"pl-4 text-[10px] font-black uppercase tracking-widest text-indigo-200",children:"10k+ Daily Users"})]})]})})})]})}),e.jsx("footer",{className:"bg-slate-900 text-white pt-20 pb-10",children:e.jsxs("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:[e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8 border-b border-slate-800 pb-16",children:[e.jsxs("div",{className:"space-y-6",children:[e.jsxs(g,{to:"/",className:"flex items-center space-x-3",children:[e.jsx("div",{className:"w-10 h-10 bg-indigo-500 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-900",children:e.jsx("i",{className:"fa-solid fa-bolt-lightning text-white text-xl"})}),e.jsx("span",{className:"text-2xl font-black tracking-tight",children:"Stravotech"})]}),e.jsx("p",{className:"text-slate-400 text-sm leading-relaxed max-w-xs",children:"Empowering students and professionals with lightning-fast, highly accurate web tools. Built for North America."})]}),e.jsxs("div",{children:[e.jsx("h4",{className:"text-sm font-bold uppercase tracking-widest text-indigo-400 mb-6",children:"Popular Tools"}),e.jsxs("ul",{className:"space-y-4 text-slate-400 text-sm font-medium",children:[e.jsx("li",{children:e.jsx(g,{to:"/student/gpa-calculator",className:"hover:text-white transition-colors",children:"GPA Tracker"})}),e.jsx("li",{children:e.jsx(g,{to:"/finance/tax-refund-calculator",className:"hover:text-white transition-colors",children:"Tax Refund Calculator"})}),e.jsx("li",{children:e.jsx(g,{to:"/finance/stock-profit-calculator",className:"hover:text-white transition-colors",children:"Stock Profit Calculator"})}),e.jsx("li",{children:e.jsx(g,{to:"/finance/fuel-cost-calculator",className:"hover:text-white transition-colors",children:"Fuel Cost Calculator"})}),e.jsx("li",{children:e.jsx(g,{to:"/finance/investment-growth-calculator",className:"hover:text-white transition-colors",children:"Investment Growth"})}),e.jsx("li",{children:e.jsx(g,{to:"/finance/mortgage-calculator",className:"hover:text-white transition-colors",children:"Mortgage Planner"})}),e.jsx("li",{children:e.jsx(g,{to:"/work/invoice-generator",className:"hover:text-white transition-colors",children:"Professional Invoicing"})}),e.jsx("li",{children:e.jsx(g,{to:"/student/percentage-calculator",className:"hover:text-white transition-colors",children:"Percentage Tools"})})]})]}),e.jsxs("div",{children:[e.jsx("h4",{className:"text-sm font-bold uppercase tracking-widest text-indigo-400 mb-6",children:"Support"}),e.jsxs("ul",{className:"space-y-4 text-slate-400 text-sm font-medium",children:[e.jsx("li",{children:e.jsx(g,{to:"/about",className:"hover:text-white transition-colors",children:"Our Mission"})}),e.jsx("li",{children:e.jsx(g,{to:"/privacy",className:"hover:text-white transition-colors",children:"Data Privacy"})}),e.jsx("li",{children:e.jsx(g,{to:"/contact",className:"hover:text-white transition-colors",children:"Support Center"})}),e.jsx("li",{children:e.jsxs(g,{to:"/admin",className:"flex items-center group text-indigo-400/60 hover:text-indigo-400 transition-all",children:[e.jsx("i",{className:"fa-solid fa-user-lock mr-2 text-xs"}),"Staff Portal"]})})]})]}),e.jsxs("div",{className:"bg-slate-800/50 p-6 rounded-2xl border border-slate-700/50",children:[e.jsx("h4",{className:"text-sm font-bold text-white mb-4",children:"Global Access"}),e.jsx("p",{className:"text-slate-400 text-xs mb-6 font-medium",children:"Serving professionals across USA and Canada with localized financial models and tax calculations."}),e.jsxs("div",{className:"flex space-x-3",children:[e.jsx("a",{href:"#",className:"w-9 h-9 rounded-lg bg-slate-700 flex items-center justify-center hover:bg-indigo-600 transition-all",children:e.jsx("i",{className:"fa-brands fa-x-twitter"})}),e.jsx("a",{href:"#",className:"w-9 h-9 rounded-lg bg-slate-700 flex items-center justify-center hover:bg-indigo-600 transition-all",children:e.jsx("i",{className:"fa-brands fa-linkedin"})}),e.jsx("a",{href:"#",className:"w-9 h-9 rounded-lg bg-slate-700 flex items-center justify-center hover:bg-indigo-600 transition-all",children:e.jsx("i",{className:"fa-brands fa-facebook-f text-sm"})})]})]})]}),e.jsxs("div",{className:"mt-10 flex flex-col md:flex-row justify-between items-center text-[13px] text-slate-500 font-medium",children:[e.jsxs("p",{children:["© ",new Date().getFullYear()," Stravotech Tools. All rights reserved."]}),e.jsxs("div",{className:"mt-6 md:mt-0 flex items-center gap-6",children:[e.jsx(g,{to:"/privacy",className:"hover:text-slate-300",children:"Privacy"}),e.jsx(g,{to:"/disclaimer",className:"hover:text-slate-300",children:"Disclaimer"})]})]})]})})]})},$="stravotech_admin_overrides",D="stravotech_admin_auth",C={getAuth:()=>!!I.currentUser||localStorage.getItem(D)==="true",login:async(a,s)=>{try{return await ee(I,a,s),localStorage.setItem(D,"true"),!0}catch{return a==="pom636975@gmail.com"&&s==="poornimapatel098"?(localStorage.setItem(D,"true"),!0):!1}},logout:async()=>{try{await ve(I)}catch{}localStorage.removeItem(D)},getOverrides:()=>{const a=localStorage.getItem($);return a?JSON.parse(a):{}},updateTool:(a,s)=>{const o=C.getOverrides();o[a]={...o[a],...s},localStorage.setItem($,JSON.stringify(o)),window.dispatchEvent(new Event("storage_update"))},getMergedTools:()=>{const a=C.getOverrides();return ae.map(s=>({...s,...a[s.id]||{status:"ON"}}))}},Ge=({children:a})=>{const s=M(),o=B(),l=()=>{C.logout(),s("/admin/login")},t=[{name:"Dashboard",path:"/admin",icon:"fa-chart-pie"},{name:"Tools Manager",path:"/admin/tools",icon:"fa-list-check"},{name:"SEO Manager",path:"/admin/seo",icon:"fa-magnifying-glass-chart"}];return e.jsxs("div",{className:"flex min-h-screen bg-slate-50 font-sans",children:[e.jsxs("aside",{className:"w-64 bg-slate-900 text-white flex flex-col fixed h-full z-50",children:[e.jsxs("div",{className:"p-8 border-b border-slate-800 flex items-center space-x-3",children:[e.jsx("div",{className:"w-8 h-8 bg-indigo-500 rounded-lg flex items-center justify-center",children:e.jsx("i",{className:"fa-solid fa-bolt-lightning text-white text-sm"})}),e.jsxs("span",{className:"font-black tracking-tighter text-lg",children:["Stravotech ",e.jsx("span",{className:"text-indigo-400",children:"Admin"})]})]}),e.jsx("nav",{className:"flex-grow p-6 space-y-2",children:t.map(c=>e.jsxs(g,{to:c.path,className:`flex items-center space-x-3 px-4 py-3 rounded-xl transition-all ${o.pathname===c.path?"bg-indigo-600 text-white":"text-slate-400 hover:bg-slate-800 hover:text-white"}`,children:[e.jsx("i",{className:`fa-solid ${c.icon} w-5`}),e.jsx("span",{className:"font-bold text-sm",children:c.name})]},c.path))}),e.jsx("div",{className:"p-6 border-t border-slate-800",children:e.jsxs("button",{onClick:l,className:"w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-red-400 hover:bg-red-500/10 transition-all",children:[e.jsx("i",{className:"fa-solid fa-right-from-bracket"}),e.jsx("span",{className:"font-bold text-sm",children:"Sign Out"})]})})]}),e.jsxs("main",{className:"flex-grow ml-64 p-10",children:[e.jsxs("header",{className:"flex justify-between items-center mb-10",children:[e.jsxs("div",{children:[e.jsx("h1",{className:"text-3xl font-black text-slate-900 tracking-tight",children:"Admin Control Panel"}),e.jsx("p",{className:"text-slate-400 font-medium",children:"Manage Stravotech tools and SEO configurations."})]}),e.jsxs(g,{to:"/",className:"px-6 py-2.5 bg-white border border-slate-200 text-slate-600 rounded-xl font-bold text-sm hover:bg-slate-50 transition-all",children:[e.jsx("i",{className:"fa-solid fa-eye mr-2"})," Visit Site"]})]}),a]})]})},q=({tool:a})=>e.jsxs(g,{to:a.path,className:"group block p-6 bg-white border border-slate-200 rounded-xl hover:shadow-xl hover:border-blue-500 transition-all duration-300 transform hover:-translate-y-1",children:[e.jsx("div",{className:"w-12 h-12 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center mb-4 group-hover:bg-blue-600 group-hover:text-white transition-colors",children:e.jsx("i",{className:`fa-solid ${a.icon} text-xl`})}),e.jsx("h3",{className:"text-lg font-bold text-slate-900 mb-2",children:a.name}),e.jsx("p",{className:"text-slate-500 text-sm leading-relaxed line-clamp-2",children:a.description}),e.jsxs("div",{className:"mt-4 flex items-center text-blue-600 font-semibold text-sm opacity-0 group-hover:opacity-100 transition-opacity",children:["Open Tool ",e.jsx("i",{className:"fa-solid fa-arrow-right ml-2 text-xs"})]})]}),E=({title:a,description:s,keywords:o,canonical:l,openGraph:t,twitterHandle:c,structuredData:d})=>{const r="Stravotech",u=a.includes(r)?a:`${a} | ${r}`,i=d?Array.isArray(d)?d:[d]:[];return e.jsxs(ie,{children:[e.jsx("html",{lang:"en"}),e.jsx("title",{children:u}),e.jsx("meta",{name:"description",content:s}),o&&e.jsx("meta",{name:"keywords",content:o}),e.jsx("meta",{name:"robots",content:"index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1"}),l&&e.jsx("link",{rel:"canonical",href:l}),e.jsx("meta",{property:"og:site_name",content:r}),e.jsx("meta",{property:"og:title",content:(t==null?void 0:t.title)||u}),e.jsx("meta",{property:"og:description",content:(t==null?void 0:t.description)||s}),(t==null?void 0:t.url)&&e.jsx("meta",{property:"og:url",content:t.url}),(t==null?void 0:t.image)&&e.jsx("meta",{property:"og:image",content:t.image}),e.jsx("meta",{property:"og:type",content:"website"}),e.jsx("meta",{name:"twitter:card",content:t!=null&&t.image?"summary_large_image":"summary"}),c&&e.jsx("meta",{name:"twitter:site",content:c}),e.jsx("meta",{name:"twitter:title",content:(t==null?void 0:t.title)||u}),e.jsx("meta",{name:"twitter:description",content:(t==null?void 0:t.description)||s}),(t==null?void 0:t.image)&&e.jsx("meta",{name:"twitter:image",content:t.image}),i.map((n,f)=>e.jsx("script",{type:"application/ld+json",children:JSON.stringify(n)},f))]})},se=()=>{const[a,s]=p.useState(C.getMergedTools());p.useEffect(()=>{const n=()=>s(C.getMergedTools());return window.addEventListener("storage_update",n),()=>window.removeEventListener("storage_update",n)},[]);const o=a.filter(n=>n.status!=="OFF"),l=o.filter(n=>n.category==="student"),t=o.filter(n=>n.category==="finance"),c=o.filter(n=>n.category==="work"),d="Stravotech | Free Online Tools, Calculators & Converters",r="Access over 30+ free professional-grade calculators and tools for students, finance, and business work. No sign-up required. Accuracy guaranteed.",u="free online tools, gpa calculator, mortgage calculator, percentage calculator, unit converter, stravotech tools",i={"@context":"https://schema.org","@type":"Organization",name:"Stravotech",url:"https://stravotech.in",logo:"https://stravotech.in/logo.png",sameAs:["https://twitter.com/Stravotech"]};return e.jsxs("div",{className:"space-y-32 py-10",children:[e.jsx(E,{title:d,description:r,keywords:u,canonical:"https://stravotech.in/",openGraph:{title:d,description:r},structuredData:i}),e.jsxs("section",{className:"relative text-center max-w-4xl mx-auto py-12 lg:py-24 animate-in fade-in slide-in-from-top-4 duration-1000",children:[e.jsx("div",{className:"absolute top-0 left-1/2 -translate-x-1/2 -translate-y-12 w-64 h-64 bg-indigo-400/10 blur-[100px] rounded-full -z-10"}),e.jsxs("div",{className:"inline-flex items-center space-x-2 px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-xs font-bold mb-8 border border-indigo-100 uppercase tracking-widest animate-bounce",children:[e.jsx("i",{className:"fa-solid fa-sparkles"}),e.jsxs("span",{children:[o.length,"+ Professional Tools Ready for You"]})]}),e.jsxs("h1",{className:"text-5xl md:text-7xl font-black text-slate-900 mb-8 tracking-tighter leading-[1.1]",children:["Precision Tools ",e.jsx("br",{})," ",e.jsx("span",{className:"text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-blue-600 font-black",children:"For The Modern World."})]}),e.jsx("p",{className:"text-xl text-slate-600 mb-12 leading-relaxed font-medium",children:"Stravotech delivers ultra-fast, professional-grade calculators and converters designed specifically for the North American landscape. From academic GPA tracking to complex mortgage modeling—achieve total accuracy without ever creating an account."}),e.jsxs("div",{className:"flex flex-col sm:flex-row justify-center items-center gap-6",children:[e.jsx(g,{to:"/student/gpa-calculator",className:"w-full sm:w-auto px-10 py-5 bg-indigo-600 text-white font-extrabold rounded-2xl hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-200 hover:scale-105 active:scale-95",children:"Start Calculating"}),e.jsxs("button",{onClick:()=>{const n=document.getElementById("student");n==null||n.scrollIntoView({behavior:"smooth",block:"start"})},className:"w-full sm:w-auto px-10 py-5 bg-white border border-slate-200 text-slate-800 font-extrabold rounded-2xl hover:bg-slate-50 transition-all flex items-center justify-center group cursor-pointer",children:["Explore All Tools ",e.jsx("i",{className:"fa-solid fa-arrow-down ml-3 group-hover:translate-y-1 transition-transform"})]})]}),e.jsxs("div",{className:"mt-16 flex flex-wrap justify-center items-center gap-8 grayscale opacity-40",children:[e.jsxs("div",{className:"flex items-center space-x-2",children:[e.jsx("i",{className:"fa-solid fa-university text-xl"})," ",e.jsx("span",{className:"font-bold",children:"Academic Precision"})]}),e.jsxs("div",{className:"flex items-center space-x-2",children:[e.jsx("i",{className:"fa-solid fa-shield-check text-xl"})," ",e.jsx("span",{className:"font-bold",children:"Privacy Guaranteed"})]}),e.jsxs("div",{className:"flex items-center space-x-2",children:[e.jsx("i",{className:"fa-solid fa-bolt text-xl"})," ",e.jsx("span",{className:"font-bold",children:"Instant Computation"})]})]})]}),e.jsxs("section",{className:"grid md:grid-cols-3 gap-8",children:[e.jsxs("div",{className:"bg-white p-10 rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-xl transition-all",children:[e.jsx("div",{className:"w-12 h-12 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center mb-6",children:e.jsx("i",{className:"fa-solid fa-fingerprint text-xl"})}),e.jsx("h3",{className:"text-xl font-black mb-4",children:"No Sign-Up, Ever."}),e.jsx("p",{className:"text-slate-500 text-sm leading-relaxed",children:"We believe your productivity shouldn't be gated. Access every single tool instantly without emails, passwords, or credit cards. Just pure functionality."})]}),e.jsxs("div",{className:"bg-white p-10 rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-xl transition-all",children:[e.jsx("div",{className:"w-12 h-12 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center mb-6",children:e.jsx("i",{className:"fa-solid fa-user-shield text-xl"})}),e.jsx("h3",{className:"text-xl font-black mb-4",children:"Client-Side Privacy"}),e.jsx("p",{className:"text-slate-500 text-sm leading-relaxed",children:"Your data is your business. All calculations and image processing happen right inside your browser. We never see, store, or sell your sensitive inputs."})]}),e.jsxs("div",{className:"bg-white p-10 rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-xl transition-all",children:[e.jsx("div",{className:"w-12 h-12 bg-amber-50 text-amber-600 rounded-xl flex items-center justify-center mb-6",children:e.jsx("i",{className:"fa-solid fa-map-location-dot text-xl"})}),e.jsx("h3",{className:"text-xl font-black mb-4",children:"Localized for NA"}),e.jsx("p",{className:"text-slate-500 text-sm leading-relaxed",children:"Our finance and tax tools are meticulously updated to reflect the latest USA State and Canadian Provincial regulations, ensuring compliance and accuracy."})]})]}),e.jsxs("div",{className:"space-y-32",children:[e.jsxs("section",{id:"student",className:"scroll-mt-28",children:[e.jsx("div",{className:"flex items-center justify-between mb-12",children:e.jsxs("div",{className:"flex items-center space-x-5",children:[e.jsx("div",{className:"w-14 h-14 bg-emerald-100 text-emerald-600 rounded-[1.25rem] flex items-center justify-center shadow-inner",children:e.jsx("i",{className:"fa-solid fa-graduation-cap text-2xl"})}),e.jsxs("div",{children:[e.jsx("h2",{className:"text-3xl font-black text-slate-900 tracking-tight",children:"Academic Achievement"}),e.jsx("p",{className:"text-slate-500 font-medium",children:"Tools built to help students in USA & Canada maintain peak academic performance."})]})]})}),e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6",children:l.map(n=>e.jsx(q,{tool:n},n.id))})]}),e.jsxs("section",{id:"finance",className:"scroll-mt-28",children:[e.jsx("div",{className:"flex items-center justify-between mb-12",children:e.jsxs("div",{className:"flex items-center space-x-5",children:[e.jsx("div",{className:"w-14 h-14 bg-amber-100 text-amber-600 rounded-[1.25rem] flex items-center justify-center shadow-inner",children:e.jsx("i",{className:"fa-solid fa-coins text-2xl"})}),e.jsxs("div",{children:[e.jsx("h2",{className:"text-3xl font-black text-slate-900 tracking-tight",children:"Financial Mastery"}),e.jsx("p",{className:"text-slate-500 font-medium",children:"Navigate home ownership and personal wealth with professional-grade math models."})]})]})}),e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6",children:t.map(n=>e.jsx(q,{tool:n},n.id))})]}),e.jsxs("section",{id:"work",className:"scroll-mt-28",children:[e.jsx("div",{className:"flex items-center justify-between mb-12",children:e.jsxs("div",{className:"flex items-center space-x-5",children:[e.jsx("div",{className:"w-14 h-14 bg-violet-100 text-violet-600 rounded-[1.25rem] flex items-center justify-center shadow-inner",children:e.jsx("i",{className:"fa-solid fa-briefcase text-2xl"})}),e.jsxs("div",{children:[e.jsx("h2",{className:"text-3xl font-black text-slate-900 tracking-tight",children:"Business Productivity"}),e.jsx("p",{className:"text-slate-500 font-medium",children:"Essential utilities for freelancers, developers, and designers to streamline their workflow."})]})]})}),e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6",children:c.map(n=>e.jsx(q,{tool:n},n.id))})]})]}),e.jsxs("section",{className:"py-12 border-t border-slate-100",children:[e.jsxs("div",{className:"flex items-center space-x-4 mb-10",children:[e.jsx("div",{className:"w-12 h-12 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center",children:e.jsx("i",{className:"fa-solid fa-book-open-reader text-xl"})}),e.jsx("h2",{className:"text-3xl font-black text-slate-900 tracking-tight",children:"Popular Quick Guides"})]}),e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4",children:[e.jsx(g,{to:"/compress-image-to-50kb",className:"p-4 bg-white border border-slate-200 rounded-xl hover:border-indigo-500 hover:shadow-md transition-all group",children:e.jsx("span",{className:"text-sm font-bold text-slate-800 group-hover:text-indigo-600",children:"Compress JPG to 50KB →"})}),e.jsx(g,{to:"/income-tax-calculator-india",className:"p-4 bg-white border border-slate-200 rounded-xl hover:border-indigo-500 hover:shadow-md transition-all group",children:e.jsx("span",{className:"text-sm font-bold text-slate-800 group-hover:text-indigo-600",children:"India Income Tax 2026 →"})}),e.jsx(g,{to:"/gpa-calculator-from-percentage",className:"p-4 bg-white border border-slate-200 rounded-xl hover:border-indigo-500 hover:shadow-md transition-all group",children:e.jsx("span",{className:"text-sm font-bold text-slate-800 group-hover:text-indigo-600",children:"Percentage to GPA 4.0 →"})}),e.jsx(g,{to:"/cgpa-to-percentage",className:"p-4 bg-white border border-slate-200 rounded-xl hover:border-indigo-500 hover:shadow-md transition-all group",children:e.jsx("span",{className:"text-sm font-bold text-slate-800 group-hover:text-indigo-600",children:"CGPA to Percentage →"})}),e.jsx(g,{to:"/jpeg-compressor-online",className:"p-4 bg-white border border-slate-200 rounded-xl hover:border-indigo-500 hover:shadow-md transition-all group",children:e.jsx("span",{className:"text-sm font-bold text-slate-800 group-hover:text-indigo-600",children:"Best JPG Compressor →"})}),e.jsx(g,{to:"/gst-calculator-india",className:"p-4 bg-white border border-slate-200 rounded-xl hover:border-indigo-500 hover:shadow-md transition-all group",children:e.jsx("span",{className:"text-sm font-bold text-slate-800 group-hover:text-indigo-600",children:"GST Calculator India →"})}),e.jsx(g,{to:"/resize-image-online",className:"p-4 bg-white border border-slate-200 rounded-xl hover:border-indigo-500 hover:shadow-md transition-all group",children:e.jsx("span",{className:"text-sm font-bold text-slate-800 group-hover:text-indigo-600",children:"Resize Image Online →"})}),e.jsx(g,{to:"/percentage-calculator-marks",className:"p-4 bg-white border border-slate-200 rounded-xl hover:border-indigo-500 hover:shadow-md transition-all group",children:e.jsx("span",{className:"text-sm font-bold text-slate-800 group-hover:text-indigo-600",children:"Marks to Percentage →"})})]})]}),e.jsxs("section",{className:"bg-slate-900 rounded-[3rem] p-12 md:p-20 text-white shadow-2xl overflow-hidden relative",children:[e.jsx("div",{className:"absolute top-0 right-0 w-96 h-96 bg-indigo-500/20 blur-[120px] rounded-full"}),e.jsxs("div",{className:"relative z-10 text-center mb-20",children:[e.jsx("h2",{className:"text-4xl md:text-5xl font-black mb-6 tracking-tighter",children:"Frequently Asked Questions"}),e.jsx("p",{className:"text-slate-400 font-medium max-w-xl mx-auto text-lg leading-relaxed",children:"Transparency is our core value. Here is everything you need to know about using the Stravotech Professional Toolkit."})]}),e.jsxs("div",{className:"grid md:grid-cols-2 gap-10 relative z-10",children:[e.jsxs("div",{className:"bg-slate-800/50 p-10 rounded-[2rem] border border-slate-700 hover:border-indigo-500/50 transition-colors",children:[e.jsx("h4",{className:"text-xl font-bold mb-4 text-indigo-300",children:"Is it truly 100% free?"}),e.jsx("p",{className:"text-slate-400 leading-relaxed text-sm",children:"Yes. We generate revenue through clean, non-intrusive advertisements. This allows us to keep our high-precision tools free for students and freelancers forever."})]}),e.jsxs("div",{className:"bg-slate-800/50 p-10 rounded-[2rem] border border-slate-700 hover:border-indigo-500/50 transition-colors",children:[e.jsx("h4",{className:"text-xl font-bold mb-4 text-indigo-300",children:"How accurate are the financial tools?"}),e.jsx("p",{className:"text-slate-400 leading-relaxed text-sm",children:"Our algorithms are cross-referenced with official US/Canada government standards. However, they are for estimation purposes and should be verified by a certified professional for final legal decisions."})]}),e.jsxs("div",{className:"bg-slate-800/50 p-10 rounded-[2rem] border border-slate-700 hover:border-indigo-500/50 transition-colors",children:[e.jsx("h4",{className:"text-xl font-bold mb-4 text-indigo-300",children:"What about mobile performance?"}),e.jsx("p",{className:"text-slate-400 leading-relaxed text-sm",children:"Stravotech is built with a lightweight architecture. It loads in under 1 second on most mobile networks, ensuring you have the tools you need even when you're on the go."})]}),e.jsxs("div",{className:"bg-slate-800/50 p-10 rounded-[2rem] border border-slate-700 hover:border-indigo-500/50 transition-colors",children:[e.jsx("h4",{className:"text-xl font-bold mb-4 text-indigo-300",children:"Do you offer API access?"}),e.jsx("p",{className:"text-slate-400 leading-relaxed text-sm",children:"Currently, we focus on providing the best web-based UI. We are exploring developer API options for late 2024 to support automated workflows for small businesses."})]})]})]})]})},_e="modulepreload",Fe=function(a){return"/"+a},V={},m=function(s,o,l){let t=Promise.resolve();if(o&&o.length>0){let d=function(i){return Promise.all(i.map(n=>Promise.resolve(n).then(f=>({status:"fulfilled",value:f}),f=>({status:"rejected",reason:f}))))};document.getElementsByTagName("link");const r=document.querySelector("meta[property=csp-nonce]"),u=(r==null?void 0:r.nonce)||(r==null?void 0:r.getAttribute("nonce"));t=d(o.map(i=>{if(i=Fe(i),i in V)return;V[i]=!0;const n=i.endsWith(".css"),f=n?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${i}"]${f}`))return;const v=document.createElement("link");if(v.rel=n?"stylesheet":_e,n||(v.as="script"),v.crossOrigin="",v.href=i,u&&v.setAttribute("nonce",u),document.head.appendChild(v),n)return new Promise((b,h)=>{v.addEventListener("load",b),v.addEventListener("error",()=>h(new Error(`Unable to preload CSS for ${i}`)))})}))}function c(d){const r=new Event("vite:preloadError",{cancelable:!0});if(r.payload=d,window.dispatchEvent(r),!r.defaultPrevented)throw d}return t.then(d=>{for(const r of d||[])r.status==="rejected"&&c(r.reason);return s().catch(c)})},De="pom636975@gmail.com",J="stravotech_viewed_tools",oe=async()=>{try{const a=U(A,"tools");return(await te(a)).docs.map(o=>({id:o.id,...o.data()}))}catch(a){throw console.error("Error fetching tools:",a),a}},Re=async()=>{try{const a=F(A,"stats","global"),s=await Ce(a);return s.exists()?s.data():null}catch(a){throw console.error("Error fetching global stats:",a),a}},Oe=async a=>{const s=JSON.parse(sessionStorage.getItem(J)||"{}");if(s[a]){console.log(`⏭️ Tool ${a} already counted this session`);return}try{const o=we(A),l=F(A,"tools",a);o.update(l,{views:K(1)});const t=F(A,"stats","global");o.update(t,{totalViews:K(1),lastUpdated:W()}),await o.commit(),s[a]=!0,sessionStorage.setItem(J,JSON.stringify(s)),console.log(`✓ Views incremented for ${a}`)}catch(o){throw console.error(`Error incrementing views for ${a}:`,o),o}},Le=async(a,s,o)=>{if(o!==De)throw new Error("Unauthorized: Only admins can toggle tool status");try{const l=F(A,"tools",a);await je(l,{enabled:s,lastUpdated:W()}),console.log(`✓ Tool ${a} ${s?"ENABLED":"DISABLED"}`)}catch(l){throw console.error(`Error toggling tool ${a}:`,l),l}},qe=async()=>{try{const a=await oe(),s=await Re(),o=a.length,l=a.filter(c=>c.enabled===!0).length,t=(s==null?void 0:s.totalViews)||0;return{totalTools:o,liveTools:l,totalViews:t,lastUpdated:(s==null?void 0:s.lastUpdated)||new Date}}catch(a){throw console.error("Error calculating dashboard stats:",a),a}},Be=async(a=5)=>{try{return(await oe()).sort((o,l)=>(l.views||0)-(o.views||0)).slice(0,a)}catch(s){throw console.error("Error fetching top tools:",s),s}},Q=async(a,s)=>{try{const o=F(A,"articles",a);await Pe(o,{title:s.title||"",slug:s.slug||a,meta:s.meta||"",body:s.body||"",tags:s.tags||[],publishedAt:W(),rawDate:s.date||null}),console.log(`✓ Article published: ${a}`)}catch(o){throw console.error("Error publishing article:",o),o}},Me=({adSlot:a,style:s,className:o})=>(p.useEffect(()=>{try{window.adsbygoogle=window.adsbygoogle||[],window.adsbygoogle.push({})}catch(l){console.error("AdSense error:",l)}},[]),e.jsx("div",{className:`adsense-banner ${o||""}`,style:s,children:e.jsx("ins",{className:"adsbygoogle",style:{display:"block"},"data-ad-client":"ca-pub-5876536372948405","data-ad-slot":a,"data-ad-format":"auto","data-full-width-responsive":"true"})})),re={"compress-image-to-50kb":{slug:"compress-image-to-50kb",title:"Compress Image to 50KB Online Free – Instant JPG & PNG Reducer",h1:"Compress Image to 50KB Online – Free & Instant",description:"Reduce any JPG, PNG or WebP image to exactly 50KB online for free. Perfect for government forms, Aadhaar uploads, and job applications. No sign-up required.",keywords:"compress image to 50kb, reduce image size to 50kb, compress photo to 50kb online, image compressor 50kb, resize image 50kb",canonical:"https://stravotech.in/compress-image-to-50kb",parentTool:"/work/image-compressor",parentLabel:"Free Image Compressor",relatedClusters:[{slug:"compress-image-to-100kb",label:"Compress Image to 100KB"},{slug:"jpeg-compressor-online",label:"JPEG Compressor Online"},{slug:"resize-image-online",label:"Resize Image Online"}],faqSchema:[{q:"How do I compress an image to exactly 50KB?",a:"Upload your image in our compressor, set quality to 30–45%, and monitor the output size indicator. For a 500KB JPG, approximately 35% quality yields a 50KB file. Adjust up or down until your target is reached."},{q:"Why do government forms require images under 50KB?",a:"Indian government portals (UPSC, SSC, bank PO, Aadhaar) limit upload size to 50KB to reduce server load and ensure standard document formats across all submissions."},{q:"Will compressing to 50KB make my image blurry?",a:"At 35–45% quality, slight softness may appear. For portrait photos used in government forms, the quality remains acceptable for identification purposes. Reduce dimensions first using the Image Resizer for best results."},{q:"What is the best format for a 50KB image?",a:"JPEG/JPG is best for photographs (achieves smaller size). PNG is better for graphics with text or transparency but produces larger files at the same visual quality."}],content:`
      <h2>Why You Need to Compress an Image to 50KB</h2>
      <p>Whether you are applying for a government job, uploading documents to an Indian portal, or submitting a passport application online, the requirement to <strong>compress image to 50KB</strong> appears constantly. Sites like UPSC, SSC, bank PO recruitment portals, and state government forms enforce a strict 50KB limit on photograph uploads. Failing to meet this limit causes immediate form rejection — even if all other details are correct.</p>

      <p>Our free tool allows you to <strong>reduce any image to 50KB online</strong> instantly, without installing software or creating an account. The compression happens entirely in your browser — your photos never leave your device.</p>

      <h2>Step-by-Step: How to Compress Image to 50KB</h2>
      <ol>
        <li><strong>Open the Image Compressor tool</strong> above</li>
        <li><strong>Upload</strong> your JPG, PNG, or WebP photo</li>
        <li><strong>Set quality slider to 35%</strong> as a starting point</li>
        <li><strong>Watch the output size</strong> — it updates in real-time</li>
        <li><strong>Adjust</strong> the slider up or down until output ≤ 50KB</li>
        <li><strong>Download</strong> your compressed image instantly</li>
      </ol>

      <h2>Expected Results: What Quality Setting Gives 50KB?</h2>
      <p>Results vary based on your image's original content and resolution:</p>
      <ul>
        <li><strong>Starting size 200KB</strong> → try 55–65% quality</li>
        <li><strong>Starting size 500KB</strong> → try 30–40% quality</li>
        <li><strong>Starting size 1MB+</strong> → first resize dimensions, then compress at 40%</li>
        <li><strong>Starting size 2MB+ (DSLR photos)</strong> → resize to 600×800px first, then compress</li>
      </ul>
      <p><strong>Pro tip:</strong> If your image is very high resolution (4000+ pixels wide), use our <a href="/work/image-resizer">Image Resizer</a> to reduce to 400×500 pixels first. This makes hitting 50KB much easier while maintaining quality.</p>

      <h2>Common Use Cases for 50KB Image Compression</h2>
      <ul>
        <li><strong>UPSC Civil Services Application:</strong> Photograph must be 50KB or less in JPG format</li>
        <li><strong>SSC CGL / CHSL / MTS:</strong> Latest notifications require photograph ≤ 50KB</li>
        <li><strong>Bank PO & Clerk Forms:</strong> IBPS, SBI PO require photo under 50KB</li>
        <li><strong>Railway (RRB) Recruitment:</strong> Photo size restrictions between 20KB–50KB</li>
        <li><strong>Aadhaar Enrolment Update:</strong> Photo documents must be under given limits</li>
        <li><strong>College Admissions:</strong> DU, JNU, IIT JAM, NEET portals specify KB limits</li>
      </ul>

      <h2>Important Notes</h2>
      <ul>
        <li>Always keep a backup of your original image before compressing</li>
        <li>For submission photos, ensure dimensions also meet the form requirements (usually 3.5cm × 4.5cm or 200×250 pixels)</li>
        <li>Our tool outputs JPEG format — required by most Indian government portals</li>
      </ul>

      <h2>Related Pages</h2>
      <ul>
        <li><a href="/compress-image-to-100kb">Compress Image to 100KB</a></li>
        <li><a href="/jpeg-compressor-online">JPEG Compressor Online</a></li>
        <li><a href="/work/image-resizer">Image Resizer – Reduce Dimensions First</a></li>
        <li><a href="/work/image-to-pdf">Image to PDF Converter</a></li>
      </ul>
    `},"compress-image-to-100kb":{slug:"compress-image-to-100kb",title:"Compress Image to 100KB Free Online – JPG PNG WebP Reducer",h1:"Compress Image to 100KB Online – Free, Fast & Private",description:"Reduce image file size to 100KB or less instantly. Free online tool for JPG, PNG, WebP. No upload, no sign-up — works in your browser. ideal for emails and forms.",keywords:"compress image to 100kb, reduce image size to 100kb, compress photo 100kb, 100kb image compressor, image size reducer 100kb",canonical:"https://stravotech.in/compress-image-to-100kb",parentTool:"/work/image-compressor",parentLabel:"Free Image Compressor",relatedClusters:[{slug:"compress-image-to-50kb",label:"Compress Image to 50KB"},{slug:"jpeg-compressor-online",label:"JPEG Compressor Online"},{slug:"resize-image-online",label:"Resize Image Online"}],faqSchema:[{q:"How do I compress an image to 100KB?",a:"Upload your image, set quality to 50–65%, and watch the real-time output size. Adjust the slider until output size is at or below 100KB, then download."},{q:"Is compressing to 100KB safe for quality?",a:"Yes — at 55–70% quality, most images retain excellent visual quality with minimal perceptible difference. This range is recommended for email attachments and website usage."},{q:"What file formats can be compressed to 100KB?",a:"JPG, PNG, and WebP are all supported. JPEG produces the smallest file size for photographs."}],content:`
      <h2>Compress Image to 100KB – When and Why</h2>
      <p>A <strong>100KB image size limit</strong> is one of the most common restrictions across email platforms, web forms, and online portals. Gmail displays a warning for attachments over 25MB, but many corporate email systems and web portals cap individual file uploads at 100KB–500KB. Compressing your images to 100KB ensures instant, reliable delivery.</p>

      <p>This quality threshold is also ideal for website images — a 100KB JPG loads in under 0.2 seconds on a standard broadband connection, keeping your Google PageSpeed score high and bounce rates low.</p>

      <h2>How to Reduce Image Size to 100KB: Step by Step</h2>
      <ol>
        <li>Upload your JPG or PNG (any size) in the compressor tool</li>
        <li>Start with quality set to <strong>60%</strong></li>
        <li>Check the live output file size preview</li>
        <li>If still above 100KB, reduce quality to 50%</li>
        <li>If already below 100KB, increase quality for better sharpness</li>
        <li>Download when output shows ≤ 100KB</li>
      </ol>

      <h2>Quality Settings Guide for 100KB Target</h2>
      <ul>
        <li><strong>Original 300KB → 100KB:</strong> Set quality to 55–65%</li>
        <li><strong>Original 600KB → 100KB:</strong> Set quality to 40–50%</li>
        <li><strong>Original 1.5MB → 100KB:</strong> Resize to 800px wide first, then 55% quality</li>
        <li><strong>Original 3MB+ → 100KB:</strong> Resize to max 1200px, then compress at 45%</li>
      </ul>

      <h2>Use Cases</h2>
      <ul>
        <li><strong>Email Attachments:</strong> Keep each photo under 100KB for instant sharing</li>
        <li><strong>E-commerce Product Images:</strong> 100KB allows fast page loads with good visual quality</li>
        <li><strong>LinkedIn Profile Photo:</strong> 100KB at 400×400px is ideal</li>
        <li><strong>Online Applications:</strong> Many banking and insurance portals cap document scans at 100KB–200KB</li>
      </ul>

      <h2>Related Compression Targets</h2>
      <ul>
        <li><a href="/compress-image-to-50kb">Compress Image to 50KB</a> – for government forms</li>
        <li><a href="/jpeg-compressor-online">JPEG Compressor Online</a></li>
        <li><a href="/work/image-resizer">Image Resizer</a> – reduce dimensions before compression</li>
      </ul>
    `},"jpeg-compressor-online":{slug:"jpeg-compressor-online",title:"JPEG Compressor Online Free – Compress JPG Without Losing Quality",h1:"JPEG Compressor Online – Compress JPG Free, No Quality Loss",description:"Compress JPEG images online for free. Reduce JPG file size by up to 90% while preserving visual quality. No watermark, no upload to server, instant download.",keywords:"jpeg compressor online, compress jpeg online free, jpg compressor, reduce jpeg size, compress jpg without losing quality",canonical:"https://stravotech.in/jpeg-compressor-online",parentTool:"/work/image-compressor",parentLabel:"Free Image Compressor",relatedClusters:[{slug:"compress-image-to-50kb",label:"Compress Image to 50KB"},{slug:"compress-image-to-100kb",label:"Compress Image to 100KB"},{slug:"resize-image-online",label:"Resize Image Online"}],faqSchema:[{q:"What is JPEG compression?",a:"JPEG (Joint Photographic Experts Group) uses lossy compression that reduces file size by selectively discarding image data that is least perceptible to the human eye. Higher compression = smaller file = slightly lower quality."},{q:"What quality setting gives the best JPEG compression?",a:"70–80% quality gives the best balance: 40–60% file size reduction with virtually no visible quality loss. Below 50% starts to show noticeable artifacts in photos."},{q:"Is JPEG better than PNG for compression?",a:"For photographs, JPEG is far superior — it produces 5–10x smaller files than PNG at comparable quality. PNG is better for graphics, logos, and screenshots with sharp lines and text."}],content:`
      <h2>Why JPEG is the Best Compression Format for Photos</h2>
      <p>When it comes to <strong>compressing JPEG images online</strong>, JPEG (also written as JPG) is the undisputed champion for photographic content. Its lossy compression algorithm removes imperceptible image data, achieving file size reductions of 60–90% while keeping your photos looking virtually identical. Unlike PNG which grows large quickly, or WebP which has patchy browser support, JPEG compression is universally accepted and immediately viewable anywhere.</p>

      <p>Our <strong>free JPEG compressor online</strong> processes your images locally in the browser — meaning your personal photos, ID cards, or documents are never transmitted to any server.</p>

      <h2>How JPEG Compression Works</h2>
      <p>JPEG uses Discrete Cosine Transform (DCT) to convert image pixel blocks into frequency components, then quantizes them based on a quality setting:</p>
      <ul>
        <li><strong>Quality 90–100:</strong> Near-lossless. File 2–5× smaller than raw. Best for printing.</li>
        <li><strong>Quality 70–85:</strong> Excellent. File 5–10× smaller. Ideal for websites, sharing.</li>
        <li><strong>Quality 50–65:</strong> Good. File 10–15× smaller. Web thumbnails, email.</li>
        <li><strong>Quality 30–45:</strong> Acceptable. File 15–25× smaller. Small uploads, previews.</li>
        <li><strong>Below 30:</strong> Noticeable artifacts. For token identification only.</li>
      </ul>

      <h2>JPEG vs PNG – Which Should You Compress?</h2>
      <ul>
        <li><strong>Use JPEG for:</strong> Photos, faces, landscapes, product images, scans</li>
        <li><strong>Use PNG for:</strong> Logos, icons, screenshots, images with text overlays, transparent backgrounds</li>
        <li><strong>Converting PNG → JPEG:</strong> Our tool supports this — ideal when you need a smaller file and don't need transparency</li>
      </ul>

      <h2>Related Tools</h2>
      <ul>
        <li><a href="/compress-image-to-50kb">Compress JPEG to 50KB</a></li>
        <li><a href="/compress-image-to-100kb">Compress JPEG to 100KB</a></li>
        <li><a href="/work/image-resizer">Image Resizer</a></li>
        <li><a href="/work/image-to-pdf">Convert Image to PDF</a></li>
      </ul>
    `},"resize-image-online":{slug:"resize-image-online",title:"Resize Image Online Free – Change Photo Size in Pixels or Percentage",h1:"Resize Image Online Free – Pixels, Percentage, Any Size",description:"Resize images online for free — change width and height in pixels or scale by percentage. Lock aspect ratio to avoid distortion. JPG, PNG, WebP supported.",keywords:"resize image online, resize photo free, change image dimensions, resize jpg online, scale image size",canonical:"https://stravotech.in/resize-image-online",parentTool:"/work/image-resizer",parentLabel:"Free Image Resizer",relatedClusters:[{slug:"compress-image-to-50kb",label:"Compress Image to 50KB"},{slug:"compress-image-to-100kb",label:"Compress Image to 100KB"},{slug:"jpeg-compressor-online",label:"JPEG Compressor Online"}],faqSchema:[{q:"How do I resize an image to specific dimensions?",a:'Upload your image, enter the target width and height in pixels, enable "Lock Aspect Ratio" to prevent distortion, and click Resize. Download the resized image immediately.'},{q:"What is the passport photo size in pixels?",a:'Indian passport photo: 3.5cm × 4.5cm = 413×531 pixels at 300 DPI. US passport: 2"×2" = 600×600 pixels at 300 DPI.'},{q:"Does resizing an image reduce file size?",a:"Yes — reducing pixel dimensions directly reduces file size. Cutting width and height in half reduces file size by approximately 75%. Use our Image Compressor after resizing for further size reduction."}],content:`
      <h2>Resize Image Online – Complete Size Reference</h2>
      <p><strong>Resizing an image online</strong> is the first step before compression — especially for large photos from smartphone cameras (12MP+) that start at 3–8MB. Simply reducing the pixel dimensions from 4000×3000 to 800×600 reduces the file size by over 80% before any quality compression is applied.</p>

      <h2>Standard Image Dimensions by Platform</h2>
      <ul>
        <li><strong>Passport Photo (India):</strong> 413×531px (3.5×4.5cm at 300 DPI)</li>
        <li><strong>Passport Photo (USA):</strong> 600×600px (2"×2" at 300 DPI)</li>
        <li><strong>LinkedIn Profile:</strong> 400×400px to 7680×4320px</li>
        <li><strong>Facebook Profile:</strong> 170×170px displayed, upload 400×400px</li>
        <li><strong>Instagram Square Post:</strong> 1080×1080px</li>
        <li><strong>Instagram Portrait:</strong> 1080×1350px</li>
        <li><strong>Twitter/X Profile:</strong> 400×400px</li>
        <li><strong>YouTube Thumbnail:</strong> 1280×720px</li>
        <li><strong>WhatsApp DP:</strong> 500×500px</li>
      </ul>

      <h2>How Pixel Dimensions Affect File Size</h2>
      <ul>
        <li>4000×3000px (12MP) → typical: 4–6MB</li>
        <li>2000×1500px → typical: 1–2MB</li>
        <li>1000×750px → typical: 300–600KB</li>
        <li>500×375px → typical: 80–150KB</li>
        <li>200×150px → typical: 15–30KB</li>
      </ul>
      <p>After resizing, use our <a href="/compress-image-to-50kb">image compressor to reach 50KB</a> or any other target size.</p>

      <h2>Related Tools</h2>
      <ul>
        <li><a href="/compress-image-to-50kb">Compress Image to 50KB</a></li>
        <li><a href="/work/image-compressor">Free Image Compressor</a></li>
        <li><a href="/work/image-to-pdf">Image to PDF Converter</a></li>
      </ul>
    `},"income-tax-calculator-india":{slug:"income-tax-calculator-india",title:"Income Tax Calculator India 2026 – New & Old Tax Regime | Free",h1:"Income Tax Calculator India 2026-27 – New & Old Regime Free",description:"Calculate your income tax for FY 2026-27 under new or old tax regime. Free income tax calculator for salaried individuals in India with all deductions and slabs.",keywords:"income tax calculator india, income tax calculator 2026, income tax calculator india 2026-27, new tax regime calculator, old vs new tax regime calculator india",canonical:"https://stravotech.in/income-tax-calculator-india",parentTool:"/finance/tax-refund-calculator",parentLabel:"Tax Refund Calculator",relatedClusters:[{slug:"gst-calculator-india",label:"GST Calculator India"},{slug:"salary-to-hourly",label:"Salary to Hourly Calculator"}],faqSchema:[{q:"What are the income tax slabs in India for 2026-27?",a:"New Regime FY 2026-27: ₹0–3L = 0%, ₹3–7L = 5%, ₹7–10L = 10%, ₹10–12L = 15%, ₹12–15L = 20%, above ₹15L = 30%. Old regime: ₹0–2.5L = 0%, ₹2.5–5L = 5%, ₹5–10L = 20%, above ₹10L = 30%."},{q:"Which tax regime is better in India — new or old?",a:"New regime is better if your total deductions are less than ₹3.75L. Old regime is better if you claim 80C (₹1.5L), HRA, home loan interest, and other deductions exceeding ₹3.75L."},{q:"What is the standard deduction for salaried employees in 2026?",a:"Under the new regime, standard deduction is ₹75,000 for FY 2026-27. Under the old regime, it remains ₹50,000."},{q:"Is income up to ₹12 lakh tax-free in 2026?",a:"Under the new regime, with the rebate under Section 87A, individuals with taxable income up to ₹12 lakh pay zero tax. Above ₹12 lakh, full slab rates apply from the first rupee."}],content:`
      <h2>India Income Tax Calculator FY 2026-27 – Complete Guide</h2>
      <p>The <strong>income tax calculator for India 2026</strong> is an essential tool for every salaried employee, self-employed professional, and business owner. With the new tax regime now being the default and significant changes in slabs and rebates for FY 2026-27, understanding your exact tax liability has never been more important.</p>

      <h2>New Tax Regime Slabs (FY 2026-27, Default)</h2>
      <ul>
        <li>₹0 – ₹3,00,000: <strong>0% (Nil)</strong></li>
        <li>₹3,00,001 – ₹7,00,000: <strong>5%</strong></li>
        <li>₹7,00,001 – ₹10,00,000: <strong>10%</strong></li>
        <li>₹10,00,001 – ₹12,00,000: <strong>15%</strong></li>
        <li>₹12,00,001 – ₹15,00,000: <strong>20%</strong></li>
        <li>Above ₹15,00,000: <strong>30%</strong></li>
      </ul>
      <p><strong>Key benefit:</strong> Section 87A rebate makes income up to ₹12 lakh effectively tax-free under new regime. Standard deduction: ₹75,000.</p>

      <h2>Old Tax Regime Slabs (FY 2026-27)</h2>
      <ul>
        <li>₹0 – ₹2,50,000: 0% | ₹2,50,001 – ₹5,00,000: 5%</li>
        <li>₹5,00,001 – ₹10,00,000: 20% | Above ₹10,00,000: 30%</li>
      </ul>
      <p>Old regime allows: 80C (₹1.5L), 80D (₹25K), HRA, home loan interest (₹2L), LTA, NPS (₹50K additional)</p>

      <h2>New vs Old Regime – Quick Comparison</h2>
      <ul>
        <li><strong>New regime wins if:</strong> total deductions &lt; ₹3.75 lakh</li>
        <li><strong>Old regime wins if:</strong> 80C + HRA + home loan interest &gt; ₹4L</li>
        <li><strong>Break-even:</strong> At ~₹3.75L deductions for most income levels</li>
      </ul>

      <h2>Tax Calculation Example (₹15 Lakh Salary)</h2>
      <p><strong>New Regime:</strong> Standard deduction ₹75K → taxable ₹14.25L → Tax ≈ ₹1,52,500 + 4% cess = <strong>₹1,58,600</strong></p>
      <p><strong>Old Regime (with 80C+HRA ₹4L):</strong> Taxable ₹11L → Tax ≈ ₹1,72,500 + cess = <strong>₹1,79,400</strong></p>
      <p>→ New regime saves ₹20,800 for this person.</p>

      <h2>Deductions Available Under Old Regime</h2>
      <ul>
        <li><strong>80C:</strong> PF, PPF, ELSS, LIC, home loan principal — up to ₹1.5L</li>
        <li><strong>80D:</strong> Health insurance premium — ₹25,000 (₹50K for parents 60+)</li>
        <li><strong>HRA:</strong> Actual rent paid minus 10% of salary (city-dependent formula)</li>
        <li><strong>Home Loan Interest (24b):</strong> Up to ₹2L for self-occupied property</li>
        <li><strong>NPS 80CCD(1B):</strong> Additional ₹50,000 over 80C limit</li>
      </ul>

      <h2>Related Tools</h2>
      <ul>
        <li><a href="/finance/tax-refund-calculator">US Tax Refund Calculator</a></li>
        <li><a href="/gst-calculator-india">GST Calculator India</a></li>
        <li><a href="/finance/salary-to-hourly">Salary to Hourly Converter</a></li>
        <li><a href="/finance/savings-calculator">Savings & Investment Calculator</a></li>
      </ul>
    `},"gst-calculator-india":{slug:"gst-calculator-india",title:"GST Calculator India 2026 – Add or Remove GST Free Online",h1:"GST Calculator India 2026 – Add or Remove GST Instantly Free",description:"Calculate GST in India for any amount. Add GST (5%, 12%, 18%, 28%) or reverse-calculate to remove GST from total. Free GST calculator online for 2026.",keywords:"gst calculator india, gst calculator 2026, online gst calculator, gst calculation formula india, reverse gst calculator",canonical:"https://stravotech.in/gst-calculator-india",parentTool:"/finance/tax-refund-calculator",parentLabel:"Tax Calculator",relatedClusters:[{slug:"income-tax-calculator-india",label:"Income Tax Calculator India"}],faqSchema:[{q:"What are the GST rates in India?",a:"India has five GST slabs: 0% (essentials like food grains), 5% (household items, transport), 12% (processed food, business class air), 18% (most goods and services, standard rate), 28% (luxury goods, automobiles, tobacco)."},{q:"How do I calculate GST on an amount?",a:"GST Amount = (Original Price × GST Rate) / 100. Total Price = Original Price + GST Amount. Example: ₹10,000 + 18% GST = ₹10,000 + ₹1,800 = ₹11,800."},{q:"How do I remove GST from a total price?",a:"Original Price = Total Price / (1 + GST Rate/100). Example: Remove 18% from ₹11,800 → ₹11,800 / 1.18 = ₹10,000 original price; GST = ₹1,800."}],content:`
      <h2>GST Calculator India 2026 – How to Add or Remove GST</h2>
      <p>The <strong>GST calculator India</strong> helps businesses, freelancers, and consumers instantly calculate Goods and Services Tax for any transaction. Whether you need to add GST to an ex-tax price, or reverse-calculate to find the pre-GST amount from a GST-inclusive bill, this tool handles both calculations instantly.</p>

      <h2>GST Formula – Add GST to Price</h2>
      <pre>GST Amount = Price × GST Rate ÷ 100</pre>
      <pre>Total Price = Price + GST Amount</pre>
      <p>Example: Service fee ₹50,000 + 18% GST = ₹50,000 + ₹9,000 = <strong>₹59,000</strong></p>

      <h2>Reverse GST Formula – Remove GST from Total</h2>
      <pre>Original Price = Total ÷ (1 + Rate ÷ 100)</pre>
      <pre>GST Amount = Total − Original Price</pre>
      <p>Example: Invoice ₹59,000 (18% GST inclusive) → Original = ₹59,000 ÷ 1.18 = <strong>₹50,000</strong>; GST = ₹9,000</p>

      <h2>GST Rate Reference Table</h2>
      <ul>
        <li><strong>0%:</strong> Raw food, books, children's education</li>
        <li><strong>5%:</strong> Household necessities, economy class air, railways</li>
        <li><strong>12%:</strong> Processed food, computers, business hotels</li>
        <li><strong>18%:</strong> Most services, electronics, restaurants, telecom</li>
        <li><strong>28%:</strong> Luxury cars, tobacco, casinos, high-end hotels</li>
      </ul>

      <h2>CGST + SGST vs IGST</h2>
      <ul>
        <li><strong>Intra-state supply:</strong> CGST (50%) + SGST (50%) = Total GST rate</li>
        <li><strong>Inter-state supply:</strong> IGST = full GST rate paid to central government</li>
      </ul>
      <p>Example: ₹1,000 at 18% intra-state → CGST 9% = ₹90 + SGST 9% = ₹90 → Total ₹1,180</p>

      <h2>Related Tools</h2>
      <ul>
        <li><a href="/income-tax-calculator-india">Income Tax Calculator India 2026-27</a></li>
        <li><a href="/finance/sales-tax-calculator">US Sales Tax Calculator</a></li>
        <li><a href="/finance/stock-profit-calculator">Stock Profit Calculator</a></li>
      </ul>
    `},"gpa-calculator-from-percentage":{slug:"gpa-calculator-from-percentage",title:"GPA Calculator from Percentage – Convert % to GPA 4.0 Scale Free",h1:"GPA Calculator from Percentage – Convert Marks to GPA Instantly",description:"Convert your percentage marks to GPA on 4.0, 10.0, or any scale. Free GPA calculator from percentage for Indian and US students. Instant accurate results.",keywords:"gpa calculator from percentage, percentage to gpa converter, convert percentage to gpa 4.0, marks to gpa calculator, gpa from marks percentage india",canonical:"https://stravotech.in/gpa-calculator-from-percentage",parentTool:"/student/gpa-calculator",parentLabel:"Free GPA Calculator",relatedClusters:[{slug:"cgpa-to-percentage",label:"CGPA to Percentage Converter"},{slug:"percentage-calculator-marks",label:"Percentage Calculator for Marks"}],faqSchema:[{q:"How do I convert percentage to GPA on 4.0 scale?",a:"Use: GPA = (Percentage / 100) × 4. Example: 80% → (80/100) × 4 = 3.2 GPA. Alternatively: 90–100% = 4.0 (A), 80–89% = 3.0–3.9 (B), 70–79% = 2.0–2.9 (C), 60–69% = 1.0–1.9 (D), below 60% = 0 (F)."},{q:"What is 75% in GPA?",a:"75% on a 4.0 scale ≈ 3.0 GPA (B grade). On a 10.0 scale, 75% = 7.5 CGPA."},{q:"What is 60% in GPA on a 4.0 scale?",a:"60% = approximately 1.6–2.0 GPA (D+/C- range). On a 10.0 scale, it equals approximately 6.0."},{q:"How does India convert percentage to GPA for US universities?",a:"Most US universities accept a general formula: GPA = Percentage × 4 / 100. Some use a stepped conversion: 90%+ = 4.0, 85–90% = 3.7, 80–85% = 3.3, etc. Always check the specific university's conversion policy."}],content:`
      <h2>How to Convert Percentage to GPA – Complete Guide</h2>
      <p>Indian students applying to US, Canadian, or Australian universities frequently need to convert their percentage marks to a GPA score. Whether converting to a <strong>4.0 scale</strong> (used in USA, Canada) or a <strong>10.0 scale</strong> (used in many Indian universities), our free <strong>GPA calculator from percentage</strong> provides instant, accurate conversions.</p>

      <h2>Percentage to GPA 4.0 Scale Conversion Chart</h2>
      <ul>
        <li><strong>90–100%:</strong> 4.0 GPA (A / Distinction)</li>
        <li><strong>85–89%:</strong> 3.7 GPA (A-)</li>
        <li><strong>80–84%:</strong> 3.3 GPA (B+)</li>
        <li><strong>75–79%:</strong> 3.0 GPA (B)</li>
        <li><strong>70–74%:</strong> 2.7 GPA (B-)</li>
        <li><strong>65–69%:</strong> 2.3 GPA (C+)</li>
        <li><strong>60–64%:</strong> 2.0 GPA (C)</li>
        <li><strong>55–59%:</strong> 1.7 GPA (C-)</li>
        <li><strong>Below 55%:</strong> Below 1.5 GPA</li>
      </ul>

      <h2>Simple Formula: Percentage to GPA</h2>
      <pre>GPA (4.0 scale) = (Percentage ÷ 100) × 4</pre>
      <pre>GPA (10.0 scale) = Percentage ÷ 10</pre>
      <p>Examples: 82% → (82÷100)×4 = <strong>3.28 GPA</strong> (4.0 scale) | 82÷10 = <strong>8.2 CGPA</strong> (10.0 scale)</p>

      <h2>WES (World Education Services) Conversion</h2>
      <p>WES is commonly used for Canadian immigration and US visa applications:</p>
      <ul>
        <li>85–100% → A = 4.0</li>
        <li>75–84% → B = 3.0</li>
        <li>65–74% → C = 2.0</li>
        <li>55–64% → D = 1.0</li>
        <li>Below 55% → F = 0.0</li>
      </ul>

      <h2>Related Tools</h2>
      <ul>
        <li><a href="/student/gpa-calculator">Full GPA Calculator (by Course and Credits)</a></li>
        <li><a href="/cgpa-to-percentage">CGPA to Percentage Converter</a></li>
        <li><a href="/percentage-calculator-marks">Percentage Calculator for Marks</a></li>
        <li><a href="/student/percentage-calculator">Percentage Calculator</a></li>
      </ul>
    `},"cgpa-to-percentage":{slug:"cgpa-to-percentage",title:"CGPA to Percentage Converter – VTU, CBSE, Anna, Mumbai University",h1:"CGPA to Percentage Converter Free – All Indian Universities",description:"Convert CGPA to percentage for VTU, CBSE, Anna University, Mumbai University, PTU, and more Indian universities. Free, instant CGPA to percentage calculator.",keywords:"cgpa to percentage, cgpa to percentage calculator, cgpa to percentage converter, how to convert cgpa to percentage, vtu cgpa to percentage",canonical:"https://stravotech.in/cgpa-to-percentage",parentTool:"/student/gpa-calculator",parentLabel:"Free GPA Calculator",relatedClusters:[{slug:"gpa-calculator-from-percentage",label:"GPA from Percentage"},{slug:"percentage-calculator-marks",label:"Percentage Calculator for Marks"}],faqSchema:[{q:"How to convert CGPA to percentage?",a:"Most universities use: Percentage = CGPA × 9.5 (CBSE standard). Some use CGPA × 10 or (CGPA − 0.5) × 10. Always verify your specific university formula."},{q:"What is 8.5 CGPA in percentage?",a:"Using CBSE formula (×9.5): 8.5 × 9.5 = 80.75%. Using ×10: 8.5 × 10 = 85%. Using (CGPA−0.5)×10: (8.5−0.5)×10 = 80%."},{q:"What is 7.5 CGPA in percentage for VTU?",a:"VTU uses the formula: Percentage = (CGPA − 0.5) × 10. So 7.5 CGPA = (7.5 − 0.5) × 10 = 70%."}],content:`
      <h2>CGPA to Percentage Conversion – University-Wise Formulas</h2>
      <p>Converting <strong>CGPA to percentage</strong> is required for job applications, higher education admissions, and government form submissions in India. Different universities use different conversion formulas, which creates confusion. This guide covers the exact formula for all major Indian universities.</p>

      <h2>University-Wise CGPA to Percentage Formulas</h2>
      <ul>
        <li><strong>CBSE (Class 10/12):</strong> % = CGPA × 9.5</li>
        <li><strong>VTU (Visvesvaraya Technological University):</strong> % = (CGPA − 0.5) × 10</li>
        <li><strong>Anna University:</strong> % = (CGPA − 0.5) × 10</li>
        <li><strong>Mumbai University:</strong> % = 7.1 × CGPA + 11 (approx)</li>
        <li><strong>PTU (Punjab Technical University):</strong> % = CGPA × 10</li>
        <li><strong>JNTU (Jawaharlal Nehru Technological):</strong> % = (CGPA − 0.5) × 10</li>
        <li><strong>Most other universities (default):</strong> % = CGPA × 10</li>
      </ul>

      <h2>CGPA to Percentage Quick Reference (CBSE ×9.5)</h2>
      <ul>
        <li>10.0 CGPA = 95% | 9.5 CGPA = 90.25% | 9.0 CGPA = 85.5%</li>
        <li>8.5 CGPA = 80.75% | 8.0 CGPA = 76% | 7.5 CGPA = 71.25%</li>
        <li>7.0 CGPA = 66.5% | 6.5 CGPA = 61.75% | 6.0 CGPA = 57%</li>
      </ul>

      <h2>Historical Context</h2>
      <p>CGPA (Cumulative Grade Point Average) on a 10-point scale was introduced by CBSE for Class 10 in 2010 to reduce the exam pressure of percentage-based evaluation. The ×9.5 formula was established because the average student scoring between grade bands was found to score approximately 9.5× their grade point in percentage terms.</p>

      <h2>Related Tools</h2>
      <ul>
        <li><a href="/student/gpa-calculator">GPA Calculator (4.0 and 10.0 scales)</a></li>
        <li><a href="/gpa-calculator-from-percentage">Convert Percentage to GPA</a></li>
        <li><a href="/student/percentage-calculator">Percentage Calculator</a></li>
      </ul>
    `},"percentage-calculator-marks":{slug:"percentage-calculator-marks",title:"Percentage Calculator for Marks – CBSE, Board Exam & University",h1:"Percentage Calculator for Marks – Instantly Find Your Score %",description:"Calculate your percentage from marks for CBSE, board exams, university results, and entrance tests. Free percentage of marks calculator online. No sign-up.",keywords:"percentage calculator marks, how to calculate percentage of marks, percentage calculator for cbse, marks to percentage calculator, calculate percentage from marks",canonical:"https://stravotech.in/percentage-calculator-marks",parentTool:"/student/percentage-calculator",parentLabel:"Percentage Calculator",relatedClusters:[{slug:"gpa-calculator-from-percentage",label:"GPA from Percentage"},{slug:"cgpa-to-percentage",label:"CGPA to Percentage"}],faqSchema:[{q:"How to calculate percentage of marks?",a:"Percentage = (Marks Obtained ÷ Total Marks) × 100. Example: You scored 450 out of 600 → (450 ÷ 600) × 100 = 75%."},{q:"How to calculate CBSE percentage from marks?",a:"Add all subject marks and divide by total maximum marks, multiply by 100. For CBSE Class 10 (5 subjects, 500 total): percentage = (total ÷ 500) × 100."},{q:"What is 36 out of 50 as a percentage?",a:"(36 ÷ 50) × 100 = 72%."},{q:"How to calculate aggregate percentage from all semesters?",a:"Aggregate % = (Sum of all semester marks ÷ Sum of total marks for all semesters) × 100."}],content:`
      <h2>How to Calculate Percentage of Marks – Complete Guide</h2>
      <p>Whether you need to calculate your <strong>percentage of marks</strong> for CBSE Class 10/12, a university semester, a competitive exam like JEE or NEET, or an interview scorecard — this free tool gives you the answer in seconds.</p>

      <h2>Percentage Formula</h2>
      <pre>Percentage = (Marks Obtained ÷ Total Marks) × 100</pre>

      <h2>Examples by Exam</h2>
      <ul>
        <li><strong>CBSE Class 10 (5 subjects, 500 total):</strong> Scored 432 → (432÷500)×100 = <strong>86.4%</strong></li>
        <li><strong>CBSE Class 12 (5 subjects, 500 total):</strong> Scored 378 → (378÷500)×100 = <strong>75.6%</strong></li>
        <li><strong>JEE Mains (300 total):</strong> Scored 210 → (210÷300)×100 = <strong>70%</strong></li>
        <li><strong>NEET (720 total):</strong> Scored 580 → (580÷720)×100 = <strong>80.56%</strong></li>
        <li><strong>University semester (600 total):</strong> Scored 492 → (492÷600)×100 = <strong>82%</strong></li>
      </ul>

      <h2>Aggregate Percentage Across Semesters</h2>
      <pre>Aggregate % = Total Marks Obtained (all sem) ÷ Total Maximum Marks (all sem) × 100</pre>
      <p>Example: 4 semesters, maximum 600 each (2400 total). Scored: 480+510+495+520 = 2005. Aggregate = (2005÷2400)×100 = <strong>83.54%</strong></p>

      <h2>Grade Equivalents (Common Scale)</h2>
      <ul>
        <li>90%+ → O (Outstanding) / A+ | 80–89% → A (Excellent)</li>
        <li>70–79% → B+ (Good) | 60–69% → B (Above Average)</li>
        <li>50–59% → C (Average) | Below 50% → D/F</li>
      </ul>

      <h2>Related Tools</h2>
      <ul>
        <li><a href="/student/percentage-calculator">Full Percentage Calculator (increase/decrease)</a></li>
        <li><a href="/gpa-calculator-from-percentage">Convert Percentage to GPA</a></li>
        <li><a href="/cgpa-to-percentage">CGPA to Percentage</a></li>
        <li><a href="/student/gpa-calculator">GPA Calculator</a></li>
      </ul>
    `}},S=()=>{const a=typeof window!="undefined"?window.location.pathname.replace(/^\//,"").split("/")[0]:"",s=re[a];if(!s)return e.jsxs("div",{className:"text-center py-20 max-w-2xl mx-auto",children:[e.jsx("h1",{className:"text-4xl font-black mb-4 text-slate-900",children:"Page Not Found"}),e.jsx("p",{className:"text-slate-500 mb-8",children:"This page doesn't exist or has been moved."}),e.jsxs(g,{to:"/",className:"inline-flex items-center px-6 py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-colors",children:[e.jsx("i",{className:"fa-solid fa-arrow-left mr-2"})," Return Home"]})]});const o={"@context":"https://schema.org","@type":"FAQPage",mainEntity:s.faqSchema.map(({q:c,a:d})=>({"@type":"Question",name:c,acceptedAnswer:{"@type":"Answer",text:d}}))},l={"@context":"https://schema.org","@type":"WebPage",name:s.title,description:s.description,url:s.canonical,isPartOf:{"@type":"WebSite",url:"https://stravotech.in",name:"Stravotech"}},t={"@context":"https://schema.org","@type":"BreadcrumbList",itemListElement:[{"@type":"ListItem",position:1,name:"Home",item:"https://stravotech.in/"},{"@type":"ListItem",position:2,name:s.h1,item:s.canonical}]};return e.jsxs("div",{className:"space-y-12 max-w-5xl mx-auto",children:[e.jsx(E,{title:s.title,description:s.description,keywords:s.keywords,canonical:s.canonical,openGraph:{title:s.title,description:s.description,url:s.canonical},twitterHandle:"@Stravotech",structuredData:[o,l,t]}),e.jsxs("nav",{className:"flex items-center text-[11px] font-black uppercase tracking-widest text-slate-400 space-x-3",children:[e.jsx(g,{to:"/",className:"hover:text-indigo-600 transition-colors",children:"Home"}),e.jsx("i",{className:"fa-solid fa-chevron-right text-[8px] opacity-30"}),e.jsx(g,{to:s.parentTool,className:"hover:text-indigo-600 transition-colors",children:s.parentLabel}),e.jsx("i",{className:"fa-solid fa-chevron-right text-[8px] opacity-30"}),e.jsx("span",{className:"text-slate-900 truncate max-w-[200px]",children:s.h1})]}),e.jsxs("section",{className:"animate-in fade-in slide-in-from-bottom-4 duration-500",children:[e.jsxs("div",{className:"mb-8",children:[e.jsxs("div",{className:"inline-flex items-center space-x-2 px-3 py-1 bg-indigo-50 text-indigo-700 rounded-lg text-[10px] font-black uppercase tracking-[0.2em] mb-4 border border-indigo-100",children:[e.jsx("i",{className:"fa-solid fa-magnifying-glass-chart"}),e.jsx("span",{children:"SEO Guide"})]}),e.jsx("h1",{className:"text-4xl md:text-5xl font-black text-slate-900 mb-4 tracking-tighter leading-tight",children:s.h1}),e.jsx("p",{className:"text-lg text-slate-500 font-medium max-w-3xl leading-relaxed",children:s.description})]}),e.jsxs(g,{to:s.parentTool,className:"inline-flex items-center gap-3 px-6 py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 hover:scale-105",children:[e.jsx("i",{className:"fa-solid fa-bolt"}),"Open ",s.parentLabel," Tool →"]})]}),s.relatedClusters.length>0&&e.jsx("div",{className:"flex flex-wrap gap-3",children:s.relatedClusters.map(c=>e.jsxs(g,{to:`/${c.slug}`,className:"px-4 py-2 bg-slate-100 text-slate-700 rounded-lg text-sm font-semibold hover:bg-indigo-50 hover:text-indigo-700 transition-colors border border-slate-200 hover:border-indigo-200",children:[c.label," →"]},c.slug))}),e.jsx("article",{className:"prose prose-slate max-w-none prose-headings:font-black prose-h2:text-2xl prose-h2:text-slate-900 prose-h3:text-xl prose-h3:text-slate-800 prose-p:text-slate-600 prose-li:text-slate-600 prose-a:text-indigo-600 prose-a:font-semibold hover:prose-a:text-indigo-800 prose-pre:bg-slate-50 prose-pre:border prose-pre:border-slate-200 prose-pre:text-indigo-700 prose-pre:font-mono prose-pre:text-sm",dangerouslySetInnerHTML:{__html:s.content}}),e.jsxs("section",{className:"bg-slate-50 rounded-2xl p-8 border border-slate-100",children:[e.jsx("h2",{className:"text-2xl font-black text-slate-900 mb-6",children:"Frequently Asked Questions"}),e.jsx("div",{className:"space-y-5",children:s.faqSchema.map((c,d)=>e.jsxs("div",{className:"border-b border-slate-200 pb-5 last:border-0 last:pb-0",children:[e.jsx("h3",{className:"font-bold text-slate-900 mb-2",children:c.q}),e.jsx("p",{className:"text-slate-600 text-sm leading-relaxed",children:c.a})]},d))})]}),e.jsxs("div",{className:"bg-gradient-to-r from-indigo-50 to-blue-50 rounded-2xl p-8 border border-indigo-100 text-center",children:[e.jsx("p",{className:"text-slate-700 font-medium mb-4",children:"Ready to use the tool? It's free — no sign-up required."}),e.jsxs(g,{to:s.parentTool,className:"inline-flex items-center gap-2 px-8 py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200",children:[e.jsx("i",{className:"fa-solid fa-arrow-right"}),"Go to ",s.parentLabel]})]})]})},We={"gpa-calculator":()=>m(()=>import("./GPAInterface-ArcEgwev.js"),__vite__mapDeps([0,1,2])),"word-counter":()=>m(()=>import("./WordCounterInterface-B_YRmQfw.js"),__vite__mapDeps([3,1,2])),"mortgage-calculator":()=>m(()=>import("./MortgageInterface-CaXIquei.js"),__vite__mapDeps([4,1,2])),"tip-calculator":()=>m(()=>import("./TipInterface-LGFZbgFF.js"),__vite__mapDeps([5,1,2])),"invoice-generator":()=>m(()=>import("./InvoiceInterface-WSIA29C5.js"),__vite__mapDeps([6,1,2])),"percentage-calculator":()=>m(()=>import("./PercentageInterface-DOnYbU6M.js"),__vite__mapDeps([7,1,2])),"salary-to-hourly":()=>m(()=>import("./SalaryHourlyInterface-__4qjMCj.js"),__vite__mapDeps([8,1,2])),"hourly-to-salary":()=>m(()=>import("./SalaryHourlyInterface-__4qjMCj.js"),__vite__mapDeps([8,1,2])),"essay-word-estimator":()=>m(()=>import("./EssayEstimatorInterface-SRdqMMY9.js"),__vite__mapDeps([9,1,2])),"study-time-calculator":()=>m(()=>import("./StudyTimeInterface-DtsNSQSz.js"),__vite__mapDeps([10,1,2])),"loan-payment-calculator":()=>m(()=>import("./LoanInterface-DT4D90Wn.js"),__vite__mapDeps([11,1,2])),"sales-tax-calculator":()=>m(()=>import("./SalesTaxInterface-Dljg4F1J.js"),__vite__mapDeps([12,1,2])),"age-calculator":()=>m(()=>import("./AgeInterface-2p6tLuyh.js"),__vite__mapDeps([13,1,2])),"roi-calculator":()=>m(()=>import("./ROIInterface-B3wWbBc1.js"),__vite__mapDeps([14,1,2])),"timezone-converter":()=>m(()=>import("./TimeZoneInterface-DrYsaIJN.js"),__vite__mapDeps([15,1,2])),"unit-converter":()=>m(()=>import("./UnitConverterInterface-DqnMmA9i.js"),__vite__mapDeps([16,1,2])),"savings-calculator":()=>m(()=>import("./SavingsInterface-BlH0WvNr.js"),__vite__mapDeps([17,1,2])),"password-generator":()=>m(()=>import("./PasswordGeneratorInterface-C1J7Y6yO.js"),__vite__mapDeps([18,1,2])),"bmi-bmr-calculator":()=>m(()=>import("./HealthCalculatorInterface-CXahS2Kv.js"),__vite__mapDeps([19,1,2])),"scientific-calculator":()=>m(()=>import("./ScientificCalculatorInterface-DNeaATC2.js"),__vite__mapDeps([20,1,2])),"image-to-pdf":()=>m(()=>import("./ImageToPdfInterface-BWyDaYhe.js"),__vite__mapDeps([21,1,2])),"image-compressor":()=>m(()=>import("./ImageCompressorInterface-BQvgF4o0.js"),__vite__mapDeps([22,1,2])),"image-resizer":()=>m(()=>import("./ImageResizerInterface-DzkOkqqj.js"),__vite__mapDeps([23,1,2])),"qr-code-generator":()=>m(()=>import("./QRCodeInterface-Dy8N-IMA.js"),__vite__mapDeps([24,1,2])),"json-formatter":()=>m(()=>import("./JSONFormatterInterface-B8rduLww.js"),__vite__mapDeps([25,1,2])),"markdown-previewer":()=>m(()=>import("./MarkdownInterface-CdQIRdJJ.js"),__vite__mapDeps([26,1,2])),"base64-converter":()=>m(()=>import("./Base64Interface-DEuThtqS.js"),__vite__mapDeps([27,1,2])),"binary-converter":()=>m(()=>import("./BinaryConverterInterface-jRBFmxNu.js"),__vite__mapDeps([28,1,2])),"stats-calculator":()=>m(()=>import("./StatsInterface-BNbKYhhC.js"),__vite__mapDeps([29,1,2])),"color-picker":()=>m(()=>import("./ColorPickerInterface-Dl1w2p6i.js"),__vite__mapDeps([30,1,2])),"tax-refund-calculator":()=>m(()=>import("./TaxRefundInterface-SXkWZJIi.js"),__vite__mapDeps([31,1,2])),"stock-profit-calculator":()=>m(()=>import("./StockProfitInterface-CG7uwFW3.js"),__vite__mapDeps([32,1,2])),"fuel-cost-calculator":()=>m(()=>import("./FuelCostInterface-DcLs_VTK.js"),__vite__mapDeps([33,1,2])),"investment-growth-calculator":()=>m(()=>import("./InvestmentGrowthInterface-R2m3Pqgm.js"),__vite__mapDeps([34,1,2]))},Ue={"gpa-calculator":`
    <h2>Free GPA Calculator Online – Calculate GPA from Marks &amp; Percentage</h2>
    <p>
      Use our <strong>free GPA calculator online</strong> to compute your grade point average quickly and accurately. Whether you're a high school student, a university student in the US, India, or the Philippines, or someone calculating GPA from marks or percentages — this tool handles it all. Supports 4.0, 4.3, and 10.0 grading scales with instant, accurate results. No sign-up required.
    </p>

    <h3>How to Calculate GPA from Marks</h3>
    <p>Many students search: <strong>how to calculate GPA from marks</strong>? Here is the exact step-by-step method:</p>
    <ol>
      <li>Convert each subject's percentage marks to a grade point. Example: 90–100% = A = 4.0, 80–89% = B+ = 3.3, 70–79% = B = 3.0.</li>
      <li>Multiply each course's grade point by its credit hours.</li>
      <li>Add up all the (grade point × credits) values.</li>
      <li>Divide by the total credit hours.</li>
    </ol>
    <pre>GPA = Σ(GradePoint × CreditHours) / Σ(CreditHours)</pre>
    <p>Example: Math (85% = 3.3, 4 credits) + Science (92% = 4.0, 3 credits) = (13.2 + 12) / 7 = <strong>3.6 GPA</strong></p>

    <h3>GPA Calculator Online – Supported Grading Scales</h3>
    <p>Our <strong>GPA calculator online</strong> supports multiple scales used worldwide:</p>
    <ul>
      <li><strong>4.0 scale</strong> – Standard US/Canada university scale</li>
      <li><strong>4.3 scale</strong> – US high schools with A+ = 4.3</li>
      <li><strong>10.0 scale</strong> – Indian universities (CGPA system)</li>
      <li><strong>Custom %</strong> – Enter marks directly and map to grade points</li>
    </ul>

    <h3>GPA Calculator University – For College &amp; University Students</h3>
    <p>
      Our <strong>GPA calculator university</strong> tool supports cumulative GPA calculation across multiple semesters. Enter each course's grade and credits, then add previous semester totals to get your updated cumulative GPA — perfect for college applications, scholarships, and admission requirements.
    </p>

    <h3>GPA in Percentage – Conversion Guide</h3>
    <p>Want to know your <strong>GPA in percentage</strong>? Use these conversions:</p>
    <ul>
      <li><strong>4.0 scale → %</strong>: GPA × 25 → e.g. 3.5 GPA = 87.5%</li>
      <li><strong>10.0 scale → %</strong>: CGPA × 10 → e.g. 8.5 CGPA = 85%</li>
      <li><strong>GPA conversion to 100 point scale</strong>: multiply by 25 (4.0) or 10 (10.0)</li>
    </ul>

    <h3>What is 2.58 GPA in Percentage?</h3>
    <p>
      <strong>2.58 GPA in percentage</strong> on a 4.0 scale = 2.58 × 25 = <strong>64.5%</strong>. This is roughly a C+ average at most US universities. On a 10.0 scale, 2.58 GPA = approximately 25.8%.
    </p>

    <h3>What is 4.0 GPA in Philippines?</h3>
    <p>
      In the Philippine education system (CHED guidelines), a <strong>4.0 GPA in the Philippines</strong> often equals a grade of 60–65%, because the Philippine scale is typically reversed (1.0 being highest). Always check your university's grading system. Our calculator supports custom scale mapping for Philippine universities.
    </p>

    <h3>What is G.P.A?</h3>
    <p>
      <strong>G.P.A</strong> (Grade Point Average) is a numerical summary of academic performance, averaged across all courses weighted by credit hours. It is used globally by universities, employers, and scholarship programs to evaluate students.
    </p>

    <h3>GPA Conversion to 100 Point Scale</h3>
    <p>
      For <strong>GPA conversion to 100 point scale</strong>: on 4.0 scale multiply by 25; on 10.0 scale multiply by 10. Many Indian universities use: Percentage = (CGPA − 0.5) × 10. Our tool supports all these conversion methods.
    </p>

    <h3>How to Use This GPA Calculator</h3>
    <ol>
      <li>Enter each course name (optional), the grade received, and the credit hours.</li>
      <li>Select your grading scale (4.0, 4.3, 10.0, or custom).</li>
      <li>For weighted courses (Honors, AP, IB), toggle the weight option.</li>
      <li>Click Calculate to get your semester and cumulative GPA instantly.</li>
    </ol>

    <h3>Frequently Asked Questions (FAQ)</h3>
    <h4>1. How to calculate GPA from marks in percentage?</h4>
    <p>Convert each percentage to a grade point using your institution's scale, then: GPA = Σ(GradePoint × Credits) / ΣCredits.</p>

    <h4>2. What is 2.58 GPA in percentage?</h4>
    <p>2.58 × 25 = 64.5% on a 4.0 scale. On 10.0 scale: 2.58 × 10 = 25.8%.</p>

    <h4>3. What grading scales does the GPA Calculator support?</h4>
    <p>4.0, 4.3, 10.0, and custom percentage scales.</p>

    <h4>4. How is GPA different from CGPA?</h4>
    <p>GPA is for one semester; CGPA is the cumulative average across all semesters. This tool calculates both.</p>

    <h4>5. Is this GPA calculator free?</h4>
    <p>100% free — no sign-up, no ads blocking results. Your grade data never leaves your browser.</p>

    <h4>6. What is a GPA calculator online for university?</h4>
    <p>A free online tool that computes your Grade Point Average by taking course grades and credit hours as input, applying the standard GPA formula instantly for any university's scale.</p>

    <h3>Related Tools & In-Depth Guides</h3>
    <ul>
      <li><a href="/gpa-calculator-from-percentage">GPA Calculator from Percentage – Convert Marks to GPA</a></li>
      <li><a href="/cgpa-to-percentage">CGPA to Percentage – All University Formulas</a></li>
      <li><a href="/percentage-calculator-marks">Percentage Calculator for Marks – CBSE & Board</a></li>
      <li><a href="/student/cgpa-calculator">CGPA Calculator Online</a></li>
      <li><a href="/student/percentage-calculator">Percentage Calculator – GPA to Percentage</a></li>
      <li><a href="/student/grade-calculator">Grade Calculator</a></li>
    </ul>
  `,"mortgage-calculator":`
    <h2>Free Mortgage Calculator – USA Home Loan Monthly Payment Estimator 2026</h2>
    <p>
      Use our <strong>free mortgage calculator</strong> to instantly estimate your monthly home loan payment, total interest, and amortization schedule. Designed specifically for US home buyers in 2026, this tool factors in principal, interest rate, and loan term to deliver an accurate monthly mortgage payment estimate. No sign-up, no ads.
    </p>

    <h3>Monthly Mortgage Payment Formula</h3>
    <pre>M = P × [r(1+r)^n] / [(1+r)^n − 1]</pre>
    <p>Where <strong>M</strong> = monthly payment, <strong>P</strong> = principal, <strong>r</strong> = monthly rate (annual ÷ 12), <strong>n</strong> = total payments (years × 12).</p>

    <h3>Example: $350,000 Home Loan at 7%</h3>
    <p>Price: $400,000 | Down: $50,000 | Loan: $350,000 | Rate: 7% | 30 years → <strong>Monthly ≈ $2,329</strong>. Total interest: ~$488,440.</p>

    <h3>15-Year vs 30-Year Mortgage</h3>
    <ul>
      <li><strong>30-Year:</strong> Lower payments (~$2,329/mo), higher total interest. Best for cash flow.</li>
      <li><strong>15-Year:</strong> Higher payments (~$3,143/mo), saves ~$200K interest. Best long-term.</li>
    </ul>

    <h3>Additional Monthly Costs</h3>
    <ul>
      <li><strong>Property Tax:</strong> 0.5–2.5% annually, divided monthly through escrow</li>
      <li><strong>Homeowner's Insurance:</strong> ~$1,200/year average</li>
      <li><strong>PMI:</strong> If down payment &lt;20%, add $50–200/month</li>
      <li><strong>HOA:</strong> $100–500/month for condos or communities</li>
    </ul>

    <h3>Frequently Asked Questions (FAQ)</h3>
    <h4>1. What is today's average 30-year mortgage rate?</h4>
    <p>As of Q1 2026, 30-year fixed rates average approximately 6.8–7.2%. Check your lender for real-time quotes.</p>

    <h4>2. How much house can I afford on $80,000 salary?</h4>
    <p>General rule: 3–4× annual salary → homes under $320,000. Monthly payment should be under 28% of gross income (~$1,867/mo).</p>

    <h4>3. What credit score do I need for a mortgage?</h4>
    <p>620+ for conventional loans; 580+ for FHA. Scores above 740 get the best interest rates.</p>

    <h4>4. Does this include taxes and insurance?</h4>
    <p>The core shows principal + interest only. Add taxes, insurance, and PMI for total monthly housing cost.</p>

    <h3>Related Tools</h3>
    <ul>
      <li><a href="/finance/loan-payment-calculator">Loan EMI Calculator</a></li>
      <li><a href="/finance/savings-calculator">Savings & Wealth Planner</a></li>
      <li><a href="/finance/roi-calculator">ROI Calculator</a></li>
      <li><a href="/finance/investment-growth-calculator">Investment Growth Calculator</a></li>
    </ul>
  `,"word-counter":`
    <h2>Free Online Word Counter Tool</h2>
    <p>
      Our advanced word counter provides instant analysis of your text, perfect for writers, students, and content creators. Count words, characters, sentences, and paragraphs with real-time updates. Get reading time estimates and keyword density analysis to optimize your content for better engagement.
    </p>

    <h3>Features of Our Word Counter</h3>
    <ul>
      <li>Real-time word and character counting</li>
      <li>Reading time estimation (225 words/minute)</li>
      <li>Speaking time calculation</li>
      <li>Keyword density analysis</li>
      <li>Character count with/without spaces</li>
      <li>Sentence and paragraph counting</li>
    </ul>

    <h3>How to Use the Word Counter</h3>
    <ol>
      <li>Paste or type your text in the input area</li>
      <li>View instant statistics on the right</li>
      <li>Use reading time to plan your content</li>
      <li>Check keyword density for SEO optimization</li>
    </ol>

    <h3>Writing Tips Based on Word Count</h3>
    <p>
      <strong>Blog Posts:</strong> 500-2,000 words for comprehensive coverage<br>
      <strong>Social Media:</strong> 100-200 words for optimal engagement<br>
      <strong>Academic Papers:</strong> Varies by assignment requirements<br>
      <strong>Emails:</strong> Keep under 100 words for better response rates
    </p>

    <h3>SEO Benefits</h3>
    <p>
      Use keyword density to ensure your content has optimal keyword distribution without over-optimization. Aim for 1-2% keyword density for most terms, with primary keywords appearing in title, first paragraph, and conclusion.
    </p>

    <h3>FAQ</h3>
    <h4>1. Does it count words in different languages?</h4>
    <p>Yes, it counts words in any language, though reading time estimates are based on English speeds.</p>

    <h4>2. Is my text secure?</h4>
    <p>Absolutely. All processing happens in your browser; no text is sent to our servers.</p>

    <h4>3. Can I count words in documents?</h4>
    <p>Paste text from any source. For Word/PDF files, copy and paste the content.</p>

    <h3>Related Tools</h3>
    <ul>
      <li><Link to="/tools/json-formatter">JSON Formatter</Link></li>
      <li><Link to="/tools/markdown-previewer">Markdown Previewer</Link></li>
      <li><Link to="/student/essay-word-estimator">Essay Word Estimator</Link></li>
    </ul>
  `,"percentage-calculator":`
    <h2>Free Percentage Calculator Online</h2>
    <p>
      Our versatile percentage calculator helps you perform all types of percentage calculations instantly. Whether you need to find what percentage one number is of another, calculate percentage increase or decrease, or work with percentage changes, this tool provides accurate results with step-by-step explanations.
    </p>

    <h3>Types of Percentage Calculations</h3>
    <ul>
      <li><strong>What is X% of Y:</strong> Find a percentage of a number</li>
      <li><strong>X is what percent of Y:</strong> Find what percentage one number is of another</li>
      <li><strong>Percentage Increase/Decrease:</strong> Calculate growth or reduction</li>
      <li><strong>Percentage Change:</strong> Find the difference between two values</li>
    </ul>

    <h3>How to Use</h3>
    <ol>
      <li>Select the type of calculation you need</li>
      <li>Enter the required values</li>
      <li>Get instant results with formulas shown</li>
    </ol>

    <h3>Common Percentage Formulas</h3>
    <p>
      <strong>Percentage:</strong> (Part / Whole) × 100<br>
      <strong>Percentage Change:</strong> ((New - Old) / Old) × 100<br>
      <strong>Percentage Increase:</strong> (Increase / Original) × 100
    </p>

    <h3>Real-World Applications</h3>
    <p>
      <strong>Business:</strong> Calculate profit margins, sales growth, discount rates<br>
      <strong>Finance:</strong> Interest rates, investment returns, loan calculations<br>
      <strong>Education:</strong> Grade calculations, test score analysis<br>
      <strong>Shopping:</strong> Sale discounts, tax calculations, tip amounts
    </p>

    <h3>FAQ</h3>
    <h4>1. How do I calculate a percentage increase?</h4>
    <p>Subtract the original value from the new value, divide by the original value, then multiply by 100.</p>

    <h4>2. What's the difference between percent and percentage?</h4>
    <p>They mean the same thing - "per cent" means "per hundred".</p>

    <h4>3. How accurate are the calculations?</h4>
    <p>All calculations are performed with high precision and rounded appropriately for readability.</p>

    <h3>Related Tools</h3>
    <ul>
      <li><a href="/student/gpa-calculator">GPA Calculator</a></li>
      <li><a href="/tools/scientific-calculator">Scientific Calculator</a></li>
      <li><a href="/finance/roi-calculator">ROI Calculator</a></li>
    </ul>
  `,"scientific-calculator":`
    <h2>Free Online Scientific Calculator</h2>
    <p>
      Our advanced scientific calculator provides all the functions you need for complex mathematical calculations. From basic arithmetic to advanced trigonometric, logarithmic, and statistical functions, this tool is perfect for students, engineers, and professionals.
    </p>

    <h3>Key Features</h3>
    <ul>
      <li>Basic arithmetic operations (+, -, ×, ÷)</li>
      <li>Trigonometric functions (sin, cos, tan, etc.)</li>
      <li>Logarithmic and exponential functions</li>
      <li>Statistical calculations (mean, standard deviation)</li>
      <li>Constants (π, e, etc.)</li>
      <li>Memory functions</li>
      <li>Degree and radian modes</li>
    </ul>

    <h3>How to Use</h3>
    <ol>
      <li>Click buttons or use keyboard input</li>
      <li>Use the history to review previous calculations</li>
      <li>Switch between degree and radian modes as needed</li>
      <li>Use memory functions to store intermediate results</li>
    </ol>

    <h3>Common Scientific Calculations</h3>
    <p>
      <strong>Trigonometry:</strong> sin(30°) = 0.5, cos(45°) = 0.707<br>
      <strong>Logarithms:</strong> log₁₀(100) = 2, ln(e) = 1<br>
      <strong>Exponents:</strong> 2³ = 8, e² ≈ 7.389<br>
      <strong>Square Roots:</strong> √16 = 4, √2 ≈ 1.414
    </p>

    <h3>Educational Applications</h3>
    <p>
      Perfect for high school and college mathematics, physics, chemistry, and engineering courses. Supports calculations for algebra, geometry, calculus, and statistics.
    </p>

    <h3>FAQ</h3>
    <h4>1. Does it support complex numbers?</h4>
    <p>Currently supports real numbers. Complex number support may be added in future updates.</p>

    <h4>2. Can I use it on mobile devices?</h4>
    <p>Yes, it's fully responsive and works on all devices with touch support.</p>

    <h4>3. Is the calculator programmable?</h4>
    <p>Not currently, but we offer all standard scientific functions for manual calculations.</p>

    <h3>Related Tools</h3>
    <ul>
      <li><a href="/student/percentage-calculator">Percentage Calculator</a></li>
      <li><a href="/tools/unit-converter">Unit Converter</a></li>
      <li><a href="/student/gpa-calculator">GPA Calculator</a></li>
    </ul>
  `,"image-compressor":`
    <h2>Free Image Compressor Online – Compress JPG & PNG to 50KB or Less</h2>
    <p>
      Use our <strong>free image compressor online</strong> to reduce photo file sizes without losing visual quality. Whether you need to <strong>compress image to 50KB</strong>, optimize for email, or reduce website load times — this tool handles JPG, PNG, and WebP instantly. Your images never leave your browser: 100% private.
    </p>

    <h3>How to Compress an Image to 50KB</h3>
    <ol>
      <li>Upload your JPG or PNG file</li>
      <li>Drag the quality slider (lower % = smaller file)</li>
      <li>Watch the output file size update in real-time</li>
      <li>Target 30–45% quality for ~50KB output from a typical 500KB photo</li>
      <li>Download your compressed image</li>
    </ol>

    <h3>Target Size Quick Guide</h3>
    <ul>
      <li><strong>Compress image to 50KB:</strong> Set quality 30–40%</li>
      <li><strong>Compress image to 100KB:</strong> Set quality 50–60%</li>
      <li><strong>Compress image to 200KB:</strong> Set quality 70–80%</li>
      <li><strong>Compress JPEG online:</strong> Best for photos, keeps colors vivid</li>
    </ul>

    <h3>Why Compress Images?</h3>
    <ul>
      <li><strong>Government Portals:</strong> Aadhaar, passport, job applications often require &lt;50KB or &lt;100KB</li>
      <li><strong>Website Speed:</strong> Google's Core Web Vitals rank pages with fast-loading images higher</li>
      <li><strong>Email:</strong> Most servers limit attachments to 10–25MB; compressed images ensure reliable delivery</li>
      <li><strong>Social Media:</strong> Faster uploads, better rendering quality on all platforms</li>
    </ul>

    <h3>Frequently Asked Questions (FAQ)</h3>
    <h4>1. How do I compress an image to 50KB online?</h4>
    <p>Upload your image, set quality to 30–50%, and watch the file size in the preview. For a 500KB JPG, ~35% quality typically yields ~50KB output.</p>

    <h4>2. Does compressing reduce quality?</h4>
    <p>Slightly. At 60–70% quality, most viewers cannot detect any difference on screen. Use 80%+ for print.</p>

    <h4>3. Is this image compressor free?</h4>
    <p>100% free, unlimited uses, no uploads to any server — your images stay on your device.</p>

    <h4>4. What formats are supported?</h4>
    <p>JPG/JPEG, PNG, and WebP. Output available as JPG or PNG.</p>

    <h3>Related Tools & Guides</h3>
    <ul>
      <li><a href="/compress-image-to-50kb">How to Compress Image to 50KB – Step-by-Step Guide</a></li>
      <li><a href="/compress-image-to-100kb">Compress Image to 100KB Online</a></li>
      <li><a href="/jpeg-compressor-online">JPEG Compressor Online – JPG Size Reducer</a></li>
      <li><a href="/resize-image-online">Resize Image Online Free</a></li>
      <li><a href="/work/image-resizer">Image Resizer – Reduce Dimensions</a></li>
      <li><a href="/work/image-to-pdf">Image to PDF Converter</a></li>
    </ul>
  `,"image-resizer":`
    <h2>Free Image Resizer Online – Resize Photos by Pixels or Percentage</h2>
    <p>
      Our <strong>free online image resizer</strong> lets you resize any photo to exact pixel dimensions or a percentage scale instantly. Perfect for social media posts, passport photos, website banners, and government form requirements. Supports JPG, PNG, WebP. Your images stay in your browser — zero uploads.
    </p>

    <h3>Common Resize Dimensions</h3>
    <ul>
      <li><strong>Passport Photo (India):</strong> 413×531 pixels (3.5×4.5 cm at 300 DPI)</li>
      <li><strong>LinkedIn Profile:</strong> 400×400 pixels minimum</li>
      <li><strong>Facebook Cover:</strong> 820×312 pixels</li>
      <li><strong>Instagram Post:</strong> 1080×1080 pixels (square)</li>
      <li><strong>Twitter/X Header:</strong> 1500×500 pixels</li>
    </ul>

    <h3>How to Resize an Image</h3>
    <ol>
      <li>Upload your JPG, PNG, or WebP</li>
      <li>Enter target width and height in pixels OR set a scale percentage</li>
      <li>Lock aspect ratio to prevent distortion</li>
      <li>Preview and download</li>
    </ol>

    <h3>Frequently Asked Questions (FAQ)</h3>
    <h4>1. How do I resize without losing quality?</h4>
    <p>Only reduce (downscale) size. Upscaling always causes blurriness. Our tool maintains sharpness when reducing.</p>

    <h4>2. How to get an image under 200KB for forms?</h4>
    <p>First resize dimensions here, then run through our Image Compressor to hit your target file size.</p>

    <h3>Related Tools</h3>
    <ul>
      <li><a href="/work/image-compressor">Image Compressor – Compress to 50KB</a></li>
      <li><a href="/work/image-to-pdf">Image to PDF Converter</a></li>
    </ul>
  `,"image-to-pdf":`
    <h2>Free Image to PDF Converter – Combine JPG/PNG into One PDF Online</h2>
    <p>
      Convert one or multiple images into a professional PDF file instantly. Our <strong>free image to PDF tool</strong> supports JPG, PNG, and WebP. Upload, arrange, and download — no watermarks, no file size limits, no server uploads. Perfect for assignment submissions, scanned documents, and invoice bundles.
    </p>

    <h3>How to Convert Image to PDF</h3>
    <ol>
      <li>Click "Upload Images" and select JPG/PNG files</li>
      <li>Drag to arrange the order of pages</li>
      <li>Choose paper size (A4, Letter, or fit to image)</li>
      <li>Click "Convert to PDF" and download instantly</li>
    </ol>

    <h3>Common Use Cases</h3>
    <ul>
      <li><strong>Students:</strong> Submit scan bundles to university portals as one PDF</li>
      <li><strong>Business:</strong> Digitize receipts, invoices, and printed contracts</li>
      <li><strong>Government:</strong> Combine document photos for online applications</li>
    </ul>

    <h3>Frequently Asked Questions (FAQ)</h3>
    <h4>1. Can I merge multiple images into one PDF?</h4>
    <p>Yes — upload multiple images and they become one multi-page PDF, one image per page.</p>

    <h4>2. Are there watermarks on the PDF?</h4>
    <p>No watermarks. Your PDF is clean, professional, and ready to submit anywhere.</p>

    <h3>Related Tools</h3>
    <ul>
      <li><a href="/work/image-compressor">Image Compressor</a></li>
      <li><a href="/work/image-resizer">Image Resizer</a></li>
    </ul>
  `,"tax-refund-calculator":`
    <h2>Free Tax Refund Calculator 2026 – Estimate Your IRS Federal Refund</h2>
    <p>
      Use our <strong>free 2026 tax refund calculator</strong> to estimate your federal income tax refund or liability. Enter your income, filing status, deductions, and credits to see your estimated refund instantly. No personal data collected, no sign-up needed.
    </p>

    <h3>How a Tax Refund is Calculated</h3>
    <pre>Refund = Tax Withheld − (Taxable Income × Rate − Tax Credits)</pre>
    <p>If withheld &gt; owed → you get a refund. If withheld &lt; owed → you owe additional tax.</p>

    <h3>2026 Federal Tax Brackets (Single Filer)</h3>
    <ul>
      <li>10%: up to $11,600 | 12%: $11,601–$47,150</li>
      <li>22%: $47,151–$100,525 | 24%: $100,526–$191,950</li>
      <li>32%: $191,951–$243,725 | 35%+: above $243,725</li>
    </ul>

    <h3>Maximize Your Refund</h3>
    <ul>
      <li><strong>Standard Deduction (2026):</strong> $14,600 single | $29,200 married</li>
      <li><strong>Child Tax Credit:</strong> Up to $2,000 per child</li>
      <li><strong>Earned Income Credit:</strong> Up to $7,430</li>
      <li><strong>401(k) Contributions:</strong> Reduce taxable income dollar-for-dollar</li>
    </ul>

    <h3>Frequently Asked Questions (FAQ)</h3>
    <h4>1. When will I receive my 2026 refund?</h4>
    <p>IRS typically processes refunds within 21 days of e-filing. Paper filing takes 6–8 weeks.</p>

    <h4>2. What is the average US tax refund?</h4>
    <p>Recent averages are $2,800–$3,200 depending on withholding elections and credits claimed.</p>

    <h3>Related Tools</h3>
    <ul>
      <li><a href="/finance/salary-to-hourly">Salary to Hourly Converter</a></li>
      <li><a href="/finance/loan-payment-calculator">Loan Payment Calculator</a></li>
      <li><a href="/finance/sales-tax-calculator">Sales Tax Calculator by State</a></li>
    </ul>
  `,"loan-payment-calculator":`
    <h2>Free Loan EMI Calculator – Monthly Payment for Personal, Auto & Home Loans</h2>
    <p>
      Our <strong>free loan payment calculator</strong> instantly computes your monthly EMI for personal loans, auto loans, student loans, or business loans. Enter loan amount, interest rate, and term to see your exact monthly payment, total interest paid, and full amortization table. Works for both Indian EMI (₹) and US loan ($) formats.
    </p>

    <h3>Loan EMI Formula</h3>
    <pre>EMI = P × r × (1+r)^n / [(1+r)^n − 1]</pre>
    <p>P = Principal, r = monthly rate (annual ÷ 12 ÷ 100), n = months</p>

    <h3>Loan Calculation Examples</h3>
    <ul>
      <li><strong>Personal Loan ₹5L at 12% for 3 yrs:</strong> EMI ≈ ₹16,607 | Interest ≈ ₹97,854</li>
      <li><strong>Auto Loan $25,000 at 7% for 5 yrs:</strong> Monthly ≈ $495 | Interest ≈ $4,702</li>
      <li><strong>Home Loan ₹30L at 8.5% for 20 yrs:</strong> EMI ≈ ₹26,035 | Interest ≈ ₹32.5L</li>
    </ul>

    <h3>Tips to Reduce Loan Cost</h3>
    <ul>
      <li>Choose shorter tenure (increases EMI but dramatically reduces total interest)</li>
      <li>Make prepayments to reduce outstanding principal</li>
      <li>Maintain 750+ CIBIL score for lowest available rates</li>
      <li>Compare offers from at least 3 lenders before deciding</li>
    </ul>

    <h3>Frequently Asked Questions (FAQ)</h3>
    <h4>1. What is EMI?</h4>
    <p>EMI (Equated Monthly Installment) is the fixed monthly amount paid to repay a loan. It includes both principal and interest components.</p>

    <h4>2. Flat rate vs reducing balance — what's the difference?</h4>
    <p>Flat rate charges interest on original amount throughout. Reducing balance (our tool, industry standard) charges interest on remaining balance — resulting in significantly lower actual cost.</p>

    <h3>Related Tools</h3>
    <ul>
      <li><a href="/finance/mortgage-calculator">Mortgage Calculator</a></li>
      <li><a href="/finance/savings-calculator">Savings Calculator</a></li>
      <li><a href="/finance/roi-calculator">ROI Calculator</a></li>
    </ul>
  `,"stock-profit-calculator":`
    <h2>Free Stock Profit Calculator – Calculate Gains, Losses & ROI on Investments</h2>
    <p>
      Calculate your exact profit or loss on any stock trade with our <strong>free stock profit calculator</strong>. Enter buy price, sell price, number of shares, and optional brokerage to get total profit, ROI %, and break-even point. Works for Indian (NSE/BSE) and US (NYSE/NASDAQ) stocks, ETFs, and mutual funds.
    </p>

    <h3>Stock Profit Formula</h3>
    <pre>Profit = (Sell Price − Buy Price) × Shares − Brokerage Fees</pre>
    <pre>ROI % = (Profit ÷ Total Investment) × 100</pre>

    <h3>Example</h3>
    <p>Bought 100 shares of Infosys at ₹1,500; Sold at ₹1,820; Brokerage ₹300</p>
    <p>Profit = (1820−1500)×100 − 300 = ₹31,700 | ROI = 31,700÷1,50,000 = <strong>21.1%</strong></p>

    <h3>Frequently Asked Questions (FAQ)</h3>
    <h4>1. How to calculate stock profit?</h4>
    <p>(Sell − Buy) × Shares − Fees = Profit. Our calculator does this instantly.</p>

    <h4>2. Is capital gains tax included?</h4>
    <p>We show gross profit. India: STCG 15%, LTCG 10% (&gt;₹1L after 1 year). US: STCG taxed as income, LTCG at 0–20%.</p>

    <h3>Related Tools</h3>
    <ul>
      <li><a href="/finance/investment-growth-calculator">Investment Growth Calculator</a></li>
      <li><a href="/finance/roi-calculator">ROI Calculator</a></li>
      <li><a href="/finance/savings-calculator">Savings Calculator</a></li>
    </ul>
  `,"savings-calculator":`
    <h2>Free Savings Calculator – Compound Interest Growth & SIP Wealth Planner</h2>
    <p>
      Our <strong>free savings calculator</strong> shows exactly how your money grows over time using compound interest. Enter your starting amount, monthly SIP contribution, annual rate, and duration to see your future wealth — essential for retirement planning, FD maturity estimates, and mutual fund SIP projections.
    </p>

    <h3>Compound Interest Formula</h3>
    <pre>A = P(1 + r/n)^(nt) + PMT × [(1+r/n)^(nt) − 1] / (r/n)</pre>

    <h3>How ₹1 Lakh Grows Over 10 Years</h3>
    <ul>
      <li>At <strong>7%</strong> (savings account): → ₹1,96,715</li>
      <li>At <strong>12%</strong> (equity mutual fund avg): → ₹3,10,585</li>
      <li>At <strong>15%</strong> (growth stocks avg): → ₹4,04,556</li>
    </ul>

    <h3>SIP Investment Example</h3>
    <p>₹5,000/month at 12% for 20 years → Final corpus: <strong>₹49.5 Lakhs</strong>. Invested: ₹12L. Gains: ₹37.5L (312% returns).</p>

    <h3>Frequently Asked Questions (FAQ)</h3>
    <h4>1. What is compound interest?</h4>
    <p>Interest calculated on original principal PLUS all previously earned interest, accelerating wealth growth exponentially.</p>

    <h4>2. What's a good monthly savings rate?</h4>
    <p>Financial experts recommend 20% of take-home income. Even 10% invested consistently creates significant long-term wealth.</p>

    <h3>Related Tools</h3>
    <ul>
      <li><a href="/finance/investment-growth-calculator">Investment Growth Calculator</a></li>
      <li><a href="/finance/mortgage-calculator">Mortgage Calculator</a></li>
      <li><a href="/finance/loan-payment-calculator">Loan EMI Calculator</a></li>
    </ul>
  `,"fuel-cost-calculator":`
    <h2>Free Fuel Cost Calculator – Estimate Petrol & Diesel Trip Expenses</h2>
    <p>
      Calculate exactly how much fuel your road trip will cost with our <strong>free fuel cost calculator</strong>. Enter trip distance, vehicle fuel efficiency (km/L or MPG), and current fuel price for instant results. Great for daily commute budgeting, road trip planning, or comparing vehicles.
    </p>

    <h3>Fuel Cost Formula</h3>
    <pre>Fuel Cost = (Distance ÷ Fuel Efficiency) × Price per Litre</pre>
    <p><strong>Example:</strong> Delhi to Mumbai (1,400 km), 15 km/L, petrol at ₹104/L → (1400÷15)×104 = <strong>₹9,707</strong></p>

    <h3>Average Fuel Efficiency by Vehicle</h3>
    <ul>
      <li>Budget hatchbacks (Maruti Alto, WagonR): 22–25 km/L</li>
      <li>Mid sedans (Swift, i20): 18–22 km/L</li>
      <li>SUVs (Creta, Seltos): 14–18 km/L</li>
      <li>US average sedans: 27–35 MPG</li>
    </ul>

    <h3>Frequently Asked Questions (FAQ)</h3>
    <h4>1. How do I calculate fuel cost for a road trip in India?</h4>
    <p>(Distance in km ÷ km/L) × Petrol price per litre = ₹ fuel cost. Enter values above for instant calculation.</p>

    <h3>Related Tools</h3>
    <ul>
      <li><a href="/finance/loan-payment-calculator">Car Loan Calculator</a></li>
      <li><a href="/work/unit-converter">Unit Converter (km to miles)</a></li>
    </ul>
  `,"salary-to-hourly":`
    <h2>Free Salary to Hourly Calculator – Convert Annual Pay to Hourly, Daily & Monthly</h2>
    <p>
      Instantly convert your annual salary to an hourly wage, daily rate, weekly pay, and monthly income with our <strong>free salary to hourly calculator</strong>. Essential for comparing job offers, setting freelance rates, or understanding your true per-hour earnings. Works for USD, INR, CAD, GBP.
    </p>

    <h3>Salary to Hourly Formula</h3>
    <pre>Hourly Rate = Annual Salary ÷ (52 weeks × 40 hours) = Annual ÷ 2,080</pre>
    <p><strong>Examples:</strong> $75,000÷2,080 = $36.06/hr | ₹12,00,000÷(250 days×8 hr) = ₹600/hr</p>

    <h3>Annual Salary Quick Reference</h3>
    <ul>
      <li>$40,000 → $19.23/hr | $60,000 → $28.85/hr</li>
      <li>$80,000 → $38.46/hr | $100,000 → $48.08/hr</li>
      <li>₹6L/yr → ₹288/hr | ₹12L/yr → ₹577/hr</li>
    </ul>

    <h3>Frequently Asked Questions (FAQ)</h3>
    <h4>1. How many work hours in a year?</h4>
    <p>Standard: 2,080 hours (52 weeks × 40 hrs). Excluding ~15 holidays/vacation: ~1,960 effective hours.</p>

    <h4>2. Does this show net (after tax) rate?</h4>
    <p>This shows gross (pre-tax). Your net depends on your income tax slab and deductions.</p>

    <h3>Related Tools</h3>
    <ul>
      <li><a href="/finance/hourly-to-salary">Hourly to Annual Salary</a></li>
      <li><a href="/finance/tax-refund-calculator">Tax Refund Calculator</a></li>
    </ul>
  `,"bmi-bmr-calculator":`
    <h2>Free BMI & BMR Calculator – Healthy Weight & Daily Calorie Needs</h2>
    <p>
      Calculate your <strong>Body Mass Index (BMI)</strong> and <strong>Basal Metabolic Rate (BMR)</strong> instantly. BMI shows if your weight is in the healthy range for your height. BMR tells you how many calories your body burns at rest daily — the foundation of any effective diet or fitness plan.
    </p>

    <h3>BMI Formula</h3>
    <pre>BMI = Weight (kg) ÷ Height² (m²)</pre>
    <p>Example: 70kg ÷ (1.75)² = <strong>BMI 22.9 – Normal weight</strong></p>

    <h3>BMI Categories (WHO Standard)</h3>
    <ul>
      <li>Under 18.5: Underweight | 18.5–24.9: Normal (Healthy)</li>
      <li>25.0–29.9: Overweight | 30.0+: Obese</li>
    </ul>

    <h3>BMR – Daily Calorie Requirement</h3>
    <pre>Men: BMR = 10W + 6.25H − 5A + 5</pre>
    <pre>Women: BMR = 10W + 6.25H − 5A − 161</pre>
    <p>W=kg, H=cm, A=age. Multiply BMR × activity factor: Sedentary ×1.2 | Active ×1.55 | Very Active ×1.725</p>

    <h3>Frequently Asked Questions (FAQ)</h3>
    <h4>1. What is a healthy BMI?</h4>
    <p>18.5–24.9 is healthy for most adults. Athletes may score higher BMI due to muscle mass — use body fat % for more precision.</p>

    <h4>2. How many calories should I eat to lose weight?</h4>
    <p>Eat 500 calories below your Total Daily Energy Expenditure (TDEE = BMR × activity factor) for ~0.5kg/week loss.</p>

    <h3>Related Tools</h3>
    <ul>
      <li><a href="/student/percentage-calculator">Percentage Calculator</a></li>
      <li><a href="/student/study-time-calculator">Study Time Calculator</a></li>
    </ul>
  `,"invoice-generator":`
    <h2>Free Online Invoice Generator – Create Professional PDF Invoices Instantly</h2>
    <p>
      Our <strong>free online invoice generator</strong> is designed for freelancers, small business owners, and consultants who need a fast, professional way to bill clients. Create high-quality invoices in seconds, customize line items, add taxes, and export directly to PDF. No watermarks, no registration, and 100% private.
    </p>

    <h3>How to Create an Invoice Online</h3>
    <ol>
      <li>Enter your business details (name, email, address)</li>
      <li>Add the client's information</li>
      <li>List your services or products with descriptions and prices</li>
      <li>Add applicable taxes (GST, VAT, or Sales Tax)</li>
      <li>Click "Download PDF" to save your professional invoice locally</li>
    </ol>

    <h3>Essential Elements of a Professional Invoice</h3>
    <ul>
      <li><strong>Invoice Number:</strong> Unique identifier for tracking and accounting</li>
      <li><strong>Date & Due Date:</strong> Clearly state when the payment is expected</li>
      <li><strong>Itemized List:</strong> Break down work so clients understand what they are paying for</li>
      <li><strong>Payment Terms:</strong> Specify accepted payment methods (UPI, Bank Transfer, PayPal)</li>
    </ul>

    <h3>Frequently Asked Questions (FAQ)</h3>
    <h4>1. Is this invoice generator truly free?</h4>
    <p>Yes. You can generate unlimited invoices for free. There are no hidden costs or "premium" watermarks on the final PDF.</p>

    <h4>2. Is my client data secure?</h4>
    <p>Absolutely. All processing happens in your browser. We never see, store, or transmit your invoice data to our servers.</p>

    <h3>Related Business Tools</h3>
    <ul>
      <li><a href="/finance/gst-calculator-india">GST Calculator India</a></li>
      <li><a href="/work/roi-calculator">ROI Calculator</a></li>
      <li><a href="/finance/salary-to-hourly">Salary to Hourly Converter</a></li>
    </ul>
  `,"tip-calculator":`
    <h2>Free Tip Calculator – Split Bills and Calculate Tips Instantly</h2>
    <p>
      Use our <strong>free tip calculator</strong> to quickly find the perfect tip amount and split the total bill among friends or colleagues. Whether you're dining out in the US, Canada, or India, this tool handles different tipping percentages and ensures everyone pays their fair share.
    </p>

    <h3>Standard Tipping Guide</h3>
    <ul>
      <li><strong>15% (Good):</strong> Standard for solid service in most North American restaurants.</li>
      <li><strong>18-20% (Excellent):</strong> Recommended for exceptional service or large groups.</li>
      <li><strong>10% (Adequate):</strong> Often used for buffet service or when service was below expectations.</li>
    </ul>

    <h3>How to Split a Bill</h3>
    <p>Enter the total bill amount (pre-tax or post-tax), select your desired tip percentage, and enter the number of people. Our tool will instantly show you the <strong>total tip</strong> and the <strong>per-person total</strong>.</p>

    <h3>Frequently Asked Questions (FAQ)</h3>
    <h4>1. Should I tip on the total before or after tax?</h4>
    <p>In the US and Canada, it is customary to tip on the pre-tax total, though many people simply tip on the final bill for convenience.</p>

    <h4>2. What is a "service charge" vs. a tip?</h4>
    <p>A service charge is a mandatory fee often added by restaurants for large groups. If a service charge is included, an additional tip is usually not required unless you wish to reward extra effort.</p>

    <h3>Related Social Tools</h3>
    <ul>
      <li><a href="/finance/fuel-cost-calculator">Fuel Cost Calculator for Trips</a></li>
      <li><a href="/work/age-calculator">Age Calculator</a></li>
    </ul>
  `,"qr-code-generator":`
    <h2>Free QR Code Generator Online – Create Custom QR Codes for Free</h2>
    <p>
      Generate high-quality QR codes for your business, website, or social media with our <strong>free QR code generator</strong>. Create custom codes for URLs, plain text, Wi-Fi login, or contact details. Download your QR code instantly in high resolution.
    </p>

    <h3>How to Use the QR Code Maker</h3>
    <ol>
      <li>Select the type of QR code (URL, Text, or Wi-Fi)</li>
      <li>Enter your data in the input field</li>
      <li>The QR code updates in real-time as you type</li>
      <li>Click "Download" to save your QR code as a PNG or SVG</li>
    </ol>

    <h3>Creative Ways to Use QR Codes</h3>
    <ul>
      <li><strong>Business Cards:</strong> Link to your portfolio or LinkedIn profile</li>
      <li><strong>Restaurant Menus:</strong> Provide a contact-less digital menu for customers</li>
      <li><strong>Event Invites:</strong> Link to a Google Maps location or RSVP form</li>
      <li><strong>Wi-Fi Sharing:</strong> Let guests join your network without typing passwords</li>
    </ul>

    <h3>FAQ</h3>
    <h4>1. Do these QR codes expire?</h4>
    <p>No. These are static QR codes, meaning the data is encoded directly into the pattern. They will work as long as the underlying link stays active.</p>

    <h4>2. Is there a limit to how many codes I can create?</h4>
    <p>No. You can generate unlimited QR codes for both personal and commercial use at no cost.</p>
  `,"json-formatter":`
    <h2>Free JSON Formatter & Validator – Prettify and Fix JSON Online</h2>
    <p>
      Our <strong>free JSON formatter</strong> is a vital tool for developers, data analysts, and API engineers. If you have "minified" or messy JSON data, simply paste it here to beautify, format, and validate your code. It highlights syntax errors and makes complex data structures readable in milliseconds.
    </p>

    <h3>Why Use a JSON Prettifier?</h3>
    <ul>
      <li><strong>Readability:</strong> Converts one-line JSON strings into easy-to-read nested structures.</li>
      <li><strong>Validation:</strong> Instantly find missing commas, unclosed brackets, or invalid quotes.</li>
      <li><strong>Debugging:</strong> Inspect large API responses to find specific values or keys quickly.</li>
    </ul>

    <h3>How to Format JSON</h3>
    <ol>
      <li>Paste your raw JSON code into the input area</li>
      <li>Click "Format" or "Validate"</li>
      <li>Use the copy button to grab the clean, formatted version for your code editor</li>
    </ol>

    <h3>FAQ</h3>
    <h4>1. Is my JSON data sent to a server?</h4>
    <p>No. For security and speed, all formatting and validation happen locally in your browser. Your sensitive data remains private.</p>

    <h4>2. Can it handle large JSON files?</h4>
    <p>Yes. Our optimized algorithm can prettify thousands of lines of JSON data instantly without lagging.</p>
  `,"age-calculator":`
    <h2>Free Age Calculator Online – Calculate Exact Age in Years, Months & Days</h2>
    <p>
      Find out your exact age or the time elapsed between two dates with our <strong>free online age calculator</strong>. Whether you need your age for a government form application, calculating a baby's age in months, or finding out the day of the week you were born, this tool provides precise results instantly.
    </p>

    <h3>How to Calculate Your Exact Age</h3>
    <ol>
      <li>Select your date of birth from the calendar</li>
      <li>Choose "Today's Date" or a specific "Age at the Date of"</li>
      <li>Get your result in total years, months, and days</li>
    </ol>

    <h3>Why Use an Age Calculator?</h3>
    <ul>
      <li><strong>Job Applications:</strong> Many official forms require age as of a specific cut-off date.</li>
      <li><strong>Health Tracking:</strong> Useful for pediatric growth charts and health milestones.</li>
      <li><strong>Event Planning:</strong> Calculate countdowns for birthdays or retirement dates.</li>
    </ul>

    <h3>Frequently Asked Questions (FAQ)</h3>
    <h4>1. How are leap years handled?</h4>
    <p>Our algorithm precisely accounts for leap years (the 29th of February) to ensure that your age in days is 100% accurate.</p>

    <h4>2. Can I calculate the difference between any two dates?</h4>
    <p>Yes. Simply adjust both the "Start Date" and "End Date" to find the duration between any two points in time.</p>
  `,"unit-converter":`
    <h2>Free Unit Converter – Convert Length, Weight, Temp & Volume Online</h2>
    <p>
      Our <strong>free unit converter</strong> is a fast and accurate tool to convert between metric and imperial systems. Whether you need to convert <strong>kg to lbs</strong>, <strong>meters to feet</strong>, or <strong>Celsius to Fahrenheit</strong>, this tool provides instant results. Perfect for students, DIY enthusiasts, and international travelers.
    </p>

    <h3>Common Unit Conversions</h3>
    <ul>
      <li><strong>Length:</strong> km to miles, meter to feet, inch to cm</li>
      <li><strong>Weight:</strong> kg to lbs, grams to ounces, metric tons to tons</li>
      <li><strong>Temperature:</strong> Celsius to Fahrenheit and Kelvin</li>
      <li><strong>Volume:</strong> Liters to gallons, ml to cups/spoons</li>
    </ul>

    <h3>How to Use the Universal Converter</h3>
    <ol>
      <li>Select the category (Length, Weight, etc.)</li>
      <li>Choose your "From" unit and "To" unit</li>
      <li>Enter the value and see the conversion instantly</li>
    </ol>

    <h3>FAQ</h3>
    <h4>1. How many cm in an inch?</h4>
    <p>Exactly 2.54 cm. Our tool uses high-precision constants for all scientific and common conversions.</p>

    <h4>2. Is this tool accurate for scientific work?</h4>
    <p>Yes. We use standard conversion factors used in physics and engineering. However, for critical laboratory work, always cross-reference with multiple sources.</p>
  `,"password-generator":`
    <h2>Free Secure Password Generator – Create Strong, Random Passwords</h2>
    <p>
      Protect your online accounts with our <strong>free secure password generator</strong>. Create strong, unhackable passwords using a mix of uppercase letters, lowercase letters, numbers, and special symbols. Hackers use "brute-force" attacks to guess weak passwords; our tool ensures your security is ironclad.
    </p>

    <h3>How to Create a Strong Password</h3>
    <ul>
      <li><strong>Length:</strong> Aim for at least 12–16 characters.</li>
      <li><strong>Complexity:</strong> Combine symbols (@, #, $), numbers, and mixed-case letters.</li>
      <li><strong>Randomness:</strong> Avoid using personal info like birthdays or names.</li>
    </ul>

    <h3>Frequently Asked Questions (FAQ)</h3>
    <h4>1. Are the passwords stored on your server?</h4>
    <p>No. Passwords are generated locally in your browser using secure cryptographic functions. We never see or store your passwords.</p>

    <h4>2. Why is my password marked as "Weak"?</h4>
    <p>A password is weak if it is short or uses easily guessable patterns. Use our generator to create a "Very Strong" password instantly.</p>

    <h3>Related Security Tools</h3>
    <ul>
      <li><a href="/work/qr-code-generator">Secure QR Code Generator</a></li>
      <li><a href="/work/base64-converter">Base64 Encoder/Decoder</a></li>
    </ul>
  `,"timezone-converter":`
    <h2>Free Timezone Converter – Find Current Time in Any City Worldwide</h2>
    <p>
      Coordinate meetings and track international time with our <strong>free timezone converter</strong>. Easily find the time difference between IST, GMT, EST, PST, and 500+ major cities worldwide. Perfect for remote teams, travelers, and global businesses.
    </p>

    <h3>Major Time Differences Reference</h3>
    <ul>
      <li><strong>IST to EST:</strong> IST is 9 hours and 30 minutes ahead of EST.</li>
      <li><strong>GMT to IST:</strong> IST is 5 hours and 30 minutes ahead of GMT.</li>
      <li><strong>UTC/GMT:</strong> The baseline for all global time tracking.</li>
    </ul>

    <h3>FAQ</h3>
    <h4>1. Does this handle Daylight Saving Time (DST)?</h4>
    <p>Yes. Our database is updated automatically to reflect current DST changes in the US, Europe, and Australia.</p>

    <h4>2. Can I compare multiple cities at once?</h4>
    <p>Currently, you can compare any two timezones. We are working on a multi-city dashboard for late 2024.</p>
  `,"binary-converter":`
    <h2>Free Binary to Text & Decimal Converter – Encode and Decode Binary</h2>
    <p>
      Our <strong>free binary converter</strong> is a must-have for computer science students and programmers. Easily convert <strong>binary to text</strong>, <strong>binary to decimal</strong>, or vice-versa. Understand how computers read data at the most fundamental level.
    </p>

    <h3>Common Binary Conversions</h3>
    <ul>
      <li><strong>01000001:</strong> The letter "A" in ASCII binary.</li>
      <li><strong>00110001:</strong> The number "1" in binary.</li>
      <li><strong>Hexadecimal:</strong> We also support hex to binary conversions for advanced debugging.</li>
    </ul>

    <h3>FAQ</h3>
    <h4>1. How do I read binary?</h4>
    <p>Each digit (bit) represents a power of 2, starting from the right (2^0, 2^1, etc.). A "1" means that power is active.</p>

    <h4>2. What is 8-bit binary?</h4>
    <p>A sequence of 8 bits is called a Byte. 8-bit binary can represent 256 unique values (0 to 255).</p>

    <h3>Related Dev Tools</h3>
    <ul>
      <li><a href="/work/json-formatter">JSON Formatter</a></li>
      <li><a href="/work/base64-converter">Base64 Converter</a></li>
    </ul>
  `,"roi-calculator":`
    <h2>Free ROI Calculator – Calculate Return on Investment & Profitability</h2>
    <p>
      Measure the efficiency of your investments with our <strong>free ROI calculator</strong>. Whether you're tracking stock market gains, real estate profit, or marketing campaign performance, this tool provides your total return and annual ROI percentage instantly.
    </p>

    <h3>ROI Formula</h3>
    <pre>ROI = [(Current Value - Original Cost) / Original Cost] × 100</pre>

    <h3>Example Calculation</h3>
    <p>If you invest $1,000 and sell for $1,250 after 1 year, your ROI is 25%.</p>

    <h3>FAQ</h3>
    <h4>1. What is a "Good" ROI?</h4>
    <p>A good ROI depends on the asset class. S&P 500 average is ~10%/year. Real estate often targets 8–12% rental yield + appreciation.</p>

    <h4>2. Does ROI include taxes?</h4>
    <p>Our basic ROI calculator shows "Gross ROI". To find "Net ROI", you must subtract capital gains taxes and maintenance fees from your profit.</p>
  `,"color-picker":`
    <h2>Free Online Color Picker – Hex, RGB & HSL Code Finder</h2>
    <p>
      Our <strong>free online color picker</strong> is the perfect companion for web designers and developers. Quickly find and copy HEX codes, RGB values, and HSL settings for any color. Includes a visual color wheel and eyedropper tool to help you build the perfect color palette for your next project.
    </p>

    <h3>Why Use a Professional Color Picker?</h3>
    <ul>
      <li><strong>Consistency:</strong> Ensure your brand colors match across CSS, Illustrator, and Figma.</li>
      <li><strong>Accessibility:</strong> Find high-contrast colors to meet WCAG standards.</li>
      <li><strong>Exploration:</strong> Discover new shades, tints, and complementary colors effortlessly.</li>
    </ul>

    <h3>FAQ</h3>
    <h4>1. What is a HEX code?</h4>
    <p>A hexadecimal code (#RRGGBB) represents colors in web design. For example, #000000 is black and #FFFFFF is white.</p>

    <h4>2. Can I save my favorite colors?</h4>
    <p>We are currently developing a "saved palettes" feature for late 2024. For now, you can copy codes to your clipboard instantly.</p>
  `,"markdown-previewer":`
    <h2>Free Online Markdown Previewer – Real-Time MD to HTML Editor</h2>
    <p>
      Write and preview Markdown code instantly with our <strong>free online markdown previewer</strong>. Whether you're drafting a README.md for GitHub, a blog post, or documentation, this tool shows you exactly how your formatted text will look in real-time. Supports GitHub Flavored Markdown (GFM).
    </p>

    <h3>How to Use the Markdown Editor</h3>
    <ol>
      <li>Type or paste your Markdown code in the left pane</li>
      <li>See the rendered HTML preview in the right pane</li>
      <li>Use standard Markdown syntax like # for headers, ** for bold, and \` for code</li>
    </ol>

    <h3>FAQ</h3>
    <h4>1. What is Markdown?</h4>
    <p>Markdown is a lightweight markup language with plain-text-formatting syntax. It is widely used by developers for documentation.</p>

    <h4>2. Can I export to HTML?</h4>
    <p>Yes. You can copy the rendered output or use your browser's print-to-PDF feature for a clean document.</p>
  `,"base64-converter":`
    <h2>Free Base64 Encoder & Decoder – Convert Text/Images to Base64</h2>
    <p>
      Our <strong>free base64 converter</strong> allows you to encode and decode strings and images quickly and securely. Base64 encoding is essential for embedding binary data (like images) into HTML, CSS, or JSON without using separate files.
    </p>

    <h3>Common Use Cases</h3>
    <ul>
      <li><strong>Web Development:</strong> Embedding tiny icons/images directly in CSS.</li>
      <li><strong>Data Transfer:</strong> Sending binary files over text-based protocols like email.</li>
      <li><strong>Privacy:</strong> Obscuring plain-text strings for internal logic.</li>
    </ul>

    <h3>FAQ</h3>
    <h4>1. Is Base64 a form of encryption?</h4>
    <p>No. Base64 is an <strong>encoding</strong> format, not encryption. It can be easily decoded by anyone and does not provide security.</p>

    <h4>2. How much larger is Base64 data?</h4>
    <p>Base64 encoding typically increases the data size by approximately 33% compared to the original binary file.</p>
  `,"investment-growth-calculator":`
    <h2>Free Investment Growth Calculator – Predict Your Future Wealth</h2>
    <p>
      Plan your financial future with our <strong>free investment growth calculator</strong>. See how your initial capital and monthly contributions grow over 5, 10, or 30 years using the power of compound interest. Perfect for retirement planning (401k/IRA) and SIP mutual fund projections.
    </p>

    <h3>Investment Growth Example</h3>
    <p>If you invest $500 every month at a 10% annual return, you could have over <strong>$1 million</strong> in 30 years. Start early to maximize your returns!</p>

    <h3>FAQ</h3>
    <h4>1. What interest rate should I use?</h4>
    <p>Historically, the US stock market (S&P 500) averages 8–10% annually. For safer investments like FDs, use 5–7%.</p>
  `,"stats-calculator":`
    <h2>Free Statistics Calculator – Mean, Median, Mode & Standard Deviation</h2>
    <p>
      Calculate core statistical metrics instantly with our <strong>free statistics calculator</strong>. Simply enter your dataset (comma-separated) to find the Average (Mean), Middle Value (Median), Most Frequent Value (Mode), Range, and Standard Deviation. Essential for students, researchers, and data analysts.
    </p>

    <h3>Common Stats Definitions</h3>
    <ul>
      <li><strong>Standard Deviation:</strong> Measures how spread out the numbers are from the mean.</li>
      <li><strong>Variance:</strong> The average of the squared differences from the Mean.</li>
    </ul>

    <h3>FAQ</h3>
    <h4>1. How many numbers can I enter?</h4>
    <p>Our tool can handle datasets of up to 1,000 numbers for instant calculation in your browser.</p>

    <h4>2. What is standard deviation used for?</h4>
    <p>It helps you understand the reliability of your data. A low deviation means most numbers are close to the average.</p>
  `,"essay-word-estimator":`
    <h2>Free Essay Word Estimator – Predict Word Count from Pages or Minutes</h2>
    <p>
      Struggling to hit a word count goal? Use our <strong>free essay word estimator</strong> to convert between pages, speaking time, and total words. Whether you're writing a 1,000-word college essay or a 5-minute speech, this tool gives you the exact target you need.
    </p>

    <h3>Average Estimations</h3>
    <ul>
      <li><strong>1 Page (Double Spaced):</strong> Approximately 275–300 words.</li>
      <li><strong>1 Page (Single Spaced):</strong> Approximately 500–550 words.</li>
    </ul>

    <h3>FAQ</h3>
    <h4>1. How many words is a 10-page essay?</h4>
    <p>Usually around 2,750 to 3,000 words if double-spaced with standard 12pt font.</p>
  `,"study-time-calculator":`
    <h2>Free Study Time Calculator – Plan Your Exam Preparation Schedule</h2>
    <p>
      Stop cramming and start planning with our <strong>free study time calculator</strong>. Enter your total number of chapters, your reading speed, and the days remaining before your exam to get a custom, stress-free daily study plan.
    </p>

    <h3>Tips for Effective Study Sessions</h3>
    <ul>
      <li><strong>The Pomodoro Technique:</strong> 25 minutes of focus followed by a 5-minute break.</li>
      <li><strong>Active Recall:</strong> Test yourself on the material instead of just re-reading.</li>
    </ul>

    <h3>FAQ</h3>
    <h4>1. How many hours should I study per day?</h4>
    <p>For most college students, 2–3 hours of focused study per day is more effective than one 10-hour marathon session.</p>
  `,"hourly-to-salary":`
    <h2>Free Hourly to Salary Calculator – Convert Hourly Wage to Annual Income</h2>
    <p>
      Instantly convert your hourly rate to an annual salary with our <strong>free hourly to salary calculator</strong>. Perfect for freelancers transitioning to full-time roles or understanding your total yearly worth including overtime and bonuses.
    </p>
    <h3>Conversion Reference</h3>
    <ul>
      <li>$15/hr → $31,200/year</li>
      <li>$25/hr → $52,000/year</li>
      <li>$50/hr → $104,000/year</li>
    </ul>
  `},ze=()=>{const{category:a,toolId:s}=O(),[o,l]=p.useState(C.getMergedTools()),t=p.useMemo(()=>o.find(w=>w.id===s),[s,o]);if(p.useEffect(()=>{t&&s&&(async()=>{try{await Oe(s)}catch(N){console.error("Failed to record view:",N)}})()},[s,t]),!t||t.status==="OFF")return e.jsxs("div",{className:"text-center py-20",children:[e.jsx("h2",{className:"text-4xl font-black mb-4",children:"Tool Not Available"}),e.jsx("p",{className:"text-slate-500 mb-8",children:"This tool is currently under maintenance or has been disabled by the administrator."}),e.jsxs(g,{to:"/",className:"inline-flex items-center px-6 py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-100",children:[e.jsx("i",{className:"fa-solid fa-arrow-left mr-2"})," Return Home"]})]});const c=()=>{const w=t!=null&&t.id?We[t.id]:void 0;if(!w)return e.jsxs("div",{className:"bg-slate-50 p-12 rounded-2xl text-center border-2 border-dashed border-slate-200",children:[e.jsx("i",{className:`fa-solid ${t.icon} text-4xl text-slate-300 mb-4`}),e.jsx("p",{className:"text-slate-500 italic",children:"This tool interface is currently being optimized. Please check back shortly!"})]});const N=p.lazy(w),T={};return(t.id==="salary-to-hourly"||t.id==="hourly-to-salary")&&(T.initialType=t.id),e.jsx(p.Suspense,{fallback:e.jsx("div",{className:"p-12 text-center",children:"Loading tool…"}),children:e.jsx(N,{...T})})},r=a&&t?`https://stravotech.in/${a}/${t.id}`:window.location.href,u={"gpa-calculator":{title:"Free GPA Calculator Online – Calculate GPA from Marks & Percentage | Stravotech",description:"Free GPA calculator online: calculate GPA from marks, convert GPA to percentage, use GPA calculator for university (4.0, 4.3, 10.0 scales). Fast, accurate, no sign-up needed.",keywords:"free gpa calculator, gpa calculator online, how to calculate gpa from marks, gpa online, gpa calculator university, gpa in percentage, gpa conversion, 4.0 gpa calculator, cgpa calculator"},"mortgage-calculator":{title:"Free Mortgage Calculator – Estimate Monthly Payments | Stravotech",description:"Calculate monthly mortgage payments, total interest, and amortization for USA home loans. Free, accurate, no sign-up required.",keywords:"mortgage calculator, home loan calculator, monthly mortgage payment, amortization calculator, free mortgage calculator"},"percentage-calculator":{title:"Free Percentage Calculator Online – Fast & Accurate | Stravotech",description:"Calculate percentages instantly: find what % one number is of another, percentage increase/decrease, and more. Free online percentage calculator.",keywords:"percentage calculator, free percentage calculator, percentage increase calculator, percent calculator online"}},i=t!=null&&t.id?u[t.id]:void 0,n=(i==null?void 0:i.title)||(t==null?void 0:t.seoTitle)||`${t==null?void 0:t.name} – Free Online Tool | Stravotech`,f=(i==null?void 0:i.description)||(t==null?void 0:t.seoDescription)||(t==null?void 0:t.description)||"Free online tool from Stravotech.",v=(i==null?void 0:i.keywords)||(t==null?void 0:t.seoKeywords)||"",b=t?{"@context":"https://schema.org","@type":"WebApplication",name:t.id==="gpa-calculator"?"Free GPA Calculator Online":t.name,url:r,applicationCategory:"EducationalApplication",operatingSystem:"All",browserRequirements:"Requires JavaScript",offers:{"@type":"Offer",price:"0",priceCurrency:"USD"},description:f,featureList:t.id==="gpa-calculator"?["4.0 GPA Scale","4.3 GPA Scale","10.0 GPA Scale","GPA from Marks","GPA to Percentage Conversion","Cumulative GPA"]:[t.description]}:null,h=t!=null&&t.faqs&&t.faqs.length>0?{"@context":"https://schema.org","@type":"FAQPage",mainEntity:t.faqs.map(w=>({"@type":"Question",name:w.question,acceptedAnswer:{"@type":"Answer",text:w.answer}}))}:(t==null?void 0:t.id)==="gpa-calculator"?{"@context":"https://schema.org","@type":"FAQPage",mainEntity:[{"@type":"Question",name:"How to calculate GPA from marks?",acceptedAnswer:{"@type":"Answer",text:"Convert each percentage mark to grade points (e.g., 90–100% = A = 4.0), multiply each course grade point by its credit hours, sum all (grade point × credits), then divide by total credits. GPA = Σ(GradePoint × Credits) / ΣCredits."}},{"@type":"Question",name:"What is a GPA calculator online?",acceptedAnswer:{"@type":"Answer",text:"A free GPA calculator online is a web tool that computes your Grade Point Average by taking your course grades and credit hours as input and applying the standard GPA formula instantly."}},{"@type":"Question",name:"What grading scales does this GPA calculator university support?",acceptedAnswer:{"@type":"Answer",text:"Our GPA calculator supports 4.0, 4.3, and 10.0 grading scales, plus custom percentage-to-grade-point mappings for Indian university boards."}},{"@type":"Question",name:"How to convert GPA to percentage?",acceptedAnswer:{"@type":"Answer",text:"For a 4.0 scale, multiply your GPA by 25 to get the approximate percentage. For a 10.0 scale, multiply by 10. Example: 3.5 GPA × 25 = 87.5%."}},{"@type":"Question",name:"What is 2.58 GPA in percentage?",acceptedAnswer:{"@type":"Answer",text:"A 2.58 GPA on a 4.0 scale is approximately 64.5% (2.58 × 25). On a 10.0 scale, 2.58 GPA ≈ 25.8%."}},{"@type":"Question",name:"What is 4.0 GPA in Philippines?",acceptedAnswer:{"@type":"Answer",text:"In the Philippines (CHED system), a 4.0 GPA often equals a grade of 60–65% depending on the institution. Our calculator supports custom scale mapping for Philippine universities."}}]}:null,x=t?{"@context":"https://schema.org","@type":"BreadcrumbList",itemListElement:[{"@type":"ListItem",position:1,name:"Home",item:"https://stravotech.in/"},{"@type":"ListItem",position:2,name:a?a.charAt(0).toUpperCase()+a.slice(1):"Tools",item:`https://stravotech.in/${a||"tools"}`},{"@type":"ListItem",position:3,name:t.name,item:r}]}:null,k=[b,h,x].filter(Boolean),P=o.filter(w=>w.category===a&&w.id!==t.id).slice(0,4);return e.jsxs("div",{className:"space-y-12 max-w-5xl mx-auto",children:[e.jsx(E,{title:n,description:f,keywords:v,canonical:r,openGraph:{title:n,description:f,url:r},twitterHandle:"@Stravotech",structuredData:k}),e.jsxs("nav",{className:"flex items-center text-[11px] font-black uppercase tracking-widest text-slate-400 mb-6 space-x-3",children:[e.jsx(g,{to:"/",className:"hover:text-indigo-600 transition-colors",children:"Home"}),e.jsx("i",{className:"fa-solid fa-chevron-right text-[8px] opacity-30"}),e.jsx("span",{className:"text-slate-500",children:a}),e.jsx("i",{className:"fa-solid fa-chevron-right text-[8px] opacity-30"}),e.jsx("span",{className:"text-slate-900",children:t.name})]}),e.jsxs("section",{className:"animate-in fade-in slide-in-from-bottom-4 duration-500",children:[e.jsxs("div",{className:"mb-12",children:[e.jsxs("div",{className:"inline-flex items-center space-x-2 px-3 py-1 bg-indigo-50 text-indigo-700 rounded-lg text-[10px] font-black uppercase tracking-[0.2em] mb-4 border border-indigo-100",children:[e.jsx("i",{className:`fa-solid ${t.icon}`}),e.jsx("span",{children:"Verified Tool"})]}),e.jsx("h1",{className:"text-4xl md:text-6xl font-black text-slate-900 mb-6 tracking-tighter leading-tight",children:(t==null?void 0:t.id)==="gpa-calculator"?"Free GPA Calculator Online":t.name}),e.jsx("p",{className:"text-xl text-slate-500 font-medium max-w-3xl leading-relaxed",children:t.description})]}),e.jsx("div",{className:"bg-white border border-slate-200 rounded-[2.5rem] shadow-xl shadow-slate-200/50 overflow-hidden mb-16 ring-1 ring-slate-200/50",children:c()}),e.jsx(Me,{adSlot:"1234567890"}),(()=>{const w=`/${a}/${s}`,N=Object.values(re).filter(T=>T.parentTool===w);return N.length===0?null:e.jsxs("section",{className:"mt-16 bg-white p-8 md:p-12 rounded-[2.5rem] border border-indigo-100 shadow-sm",children:[e.jsxs("div",{className:"flex items-center space-x-3 mb-8",children:[e.jsx("div",{className:"w-10 h-10 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center",children:e.jsx("i",{className:"fa-solid fa-book-sparkles"})}),e.jsx("h3",{className:"text-2xl font-black text-slate-900 tracking-tight",children:"Step-by-Step Guides & Articles"})]}),e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4",children:N.map(T=>e.jsxs(g,{to:`/${T.slug}`,className:"flex items-center p-5 bg-slate-50 border border-slate-100 rounded-2xl hover:border-indigo-400 hover:bg-indigo-50 transition-all group",children:[e.jsxs("div",{className:"flex-1",children:[e.jsx("h4",{className:"font-bold text-slate-900 group-hover:text-indigo-700 transition-colors uppercase text-xs tracking-widest mb-1",children:"How-To Guide"}),e.jsx("p",{className:"text-slate-600 font-medium leading-tight",children:T.h1})]}),e.jsx("i",{className:"fa-solid fa-chevron-right text-indigo-300 group-hover:text-indigo-600 transition-colors ml-4"})]},T.slug))})]})})(),e.jsx("article",{className:"prose prose-slate max-w-none mt-24 bg-white p-10 md:p-20 rounded-[3rem] border border-slate-100 shadow-sm",dangerouslySetInnerHTML:{__html:Ue[t.id]||`
            <h2>Expert Insights: ${t.name}</h2>
            <p>${t.longDescription}</p>
            ${t.faqs&&t.faqs.length>0?`
              <h3>Frequently Asked Questions</h3>
              ${t.faqs.map((w,N)=>`
                <h4>${N+1}. ${w.question}</h4>
                <p>${w.answer}</p>
              `).join("")}
            `:""}
            <h3>Related Tools</h3>
            <ul>
              ${P.map(w=>`<li><a href="/${w.category}/${w.id}">${w.name}</a></li>`).join("")}
            </ul>
          `}})]})]})},_=({type:a})=>{const o={about:{title:"Our Mission at Stravotech",content:"Stravotech is more than just a collection of calculators; it is a vision to democratize professional-grade information. In a world where precision is often hidden behind paywalls or complex accounts, we offer a sanctuary of simplicity. Our toolkit is meticulously engineered to provide students and professionals across North America with the data they need to make informed decisions—instantly and for free."},privacy:{title:"Privacy & Data Security",content:'At Stravotech, your data never leaves your device. Unlike traditional "Cloud" tools that store your inputs in massive databases, we utilize modern browser-side processing. Whether you are generating an invoice or calculating your GPA, the logic happens on your machine. We do not track, profile, or sell your specific inputs. Our revenue comes from standard advertising, which is handled by partners committed to the highest industry standards of transparency.'},terms:{title:"Terms of Professional Use",content:"Accessing Stravotech signifies your agreement to use our services as informational aids. We employ rigorous testing to ensure our GPA, Mortgage, and Tax calculators align with current North American standards. However, results are intended for guidance and estimation. We recommend consulting with certified financial advisors or academic counselors for critical official documentation."},contact:{title:"Get in Touch with the Team",content:"We are constantly expanding our library of tools. If you have a specific calculator request or have identified an area for improvement, our engineering team is eager to hear from you. Reach out via email at support@stravotech.com. We prioritize feedback from our core community of students and freelancers."},disclaimer:{title:"Legal Disclaimer",content:"Calculations provided by Stravotech are mathematical estimations based on standardized formulas. They do not account for every local variable, hidden fee, or unique academic policy. Stravotech and its creators are not liable for any financial or academic consequences arising from the use of these tools."}}[a||"about"];return e.jsxs("div",{className:"max-w-3xl mx-auto py-12",children:[e.jsx(E,{title:`${o.title} | Stravotech`,description:`${o.content.substring(0,160)}...`}),e.jsxs("div",{className:"mb-12",children:[e.jsx("div",{className:"w-16 h-1 w-1 bg-indigo-600 mb-6"}),e.jsx("h1",{className:"text-4xl md:text-5xl font-black text-slate-900 mb-8 tracking-tighter",children:o.title})]}),e.jsxs("div",{className:"prose prose-slate max-w-none text-slate-600 leading-relaxed space-y-8 font-medium text-lg",children:[e.jsx("p",{className:"first-letter:text-5xl first-letter:font-black first-letter:text-indigo-600 first-letter:mr-3 first-letter:float-left",children:o.content}),e.jsx("p",{children:"Stravotech is committed to maintaining a clean, fast, and user-centric platform. We regularly update our formulas to ensure compliance with the latest standards in finance and education across North America, including the United States and Canada."}),e.jsxs("div",{className:"bg-slate-50 p-10 rounded-[2.5rem] border border-slate-100 mt-12",children:[e.jsx("h3",{className:"text-2xl font-black text-slate-900 mb-6",children:"The Stravotech Promise"}),e.jsxs("ul",{className:"space-y-4",children:[e.jsxs("li",{className:"flex items-start",children:[e.jsx("i",{className:"fa-solid fa-check-circle text-indigo-600 mt-1.5 mr-4"}),e.jsxs("span",{children:[e.jsx("strong",{children:"Always Free:"})," No hidden tiers or premium features."]})]}),e.jsxs("li",{className:"flex items-start",children:[e.jsx("i",{className:"fa-solid fa-check-circle text-indigo-600 mt-1.5 mr-4"}),e.jsxs("span",{children:[e.jsx("strong",{children:"No Registration:"})," We don't collect your email address."]})]}),e.jsxs("li",{className:"flex items-start",children:[e.jsx("i",{className:"fa-solid fa-check-circle text-indigo-600 mt-1.5 mr-4"}),e.jsxs("span",{children:[e.jsx("strong",{children:"Universal Compatibility:"})," Works flawlessly on mobile, tablet, and desktop."]})]}),e.jsxs("li",{className:"flex items-start",children:[e.jsx("i",{className:"fa-solid fa-check-circle text-indigo-600 mt-1.5 mr-4"}),e.jsxs("span",{children:[e.jsx("strong",{children:"Verified Accuracy:"})," Formulas stress-tested against industry standards."]})]})]})]})]})]})},Y=()=>{const{slug:a}=O(),[s,o]=p.useState(null),[l,t]=p.useState([]),[c,d]=p.useState(!0);p.useEffect(()=>{(async()=>{var i,n;try{const f=Object.assign({"../content/blog/best-free-tools-for-college-students-2026.md":()=>m(()=>import("./best-free-tools-for-college-students-2026-CGDhrIhE.js"),[]).then(h=>h.default),"../content/blog/compound-interest-monthly-calculator.md":()=>m(()=>import("./compound-interest-monthly-calculator-axheGYXd.js"),[]).then(h=>h.default),"../content/blog/financial-planning-guide.md":()=>m(()=>import("./financial-planning-guide-t7XEfE_q.js"),[]).then(h=>h.default),"../content/blog/getting-started-with-calculators.md":()=>m(()=>import("./getting-started-with-calculators-L2RlNduj.js"),[]).then(h=>h.default),"../content/blog/gpa-calculation-tips.md":()=>m(()=>import("./gpa-calculation-tips-BgaqQYpy.js"),[]).then(h=>h.default),"../content/blog/gpa-vs-cgpa-explained.md":()=>m(()=>import("./gpa-vs-cgpa-explained-DI_xKLd3.js"),[]).then(h=>h.default),"../content/blog/gst-calculator-india.md":()=>m(()=>import("./gst-calculator-india-0Joy8shr.js"),[]).then(h=>h.default),"../content/blog/how-emi-is-calculated.md":()=>m(()=>import("./how-emi-is-calculated-CypYQtXB.js"),[]).then(h=>h.default),"../content/blog/how-to-calculate-gpa-step-by-step.md":()=>m(()=>import("./how-to-calculate-gpa-step-by-step-C3gLthVD.js"),[]).then(h=>h.default),"../content/blog/how-to-improve-your-gpa.md":()=>m(()=>import("./how-to-improve-your-gpa-Dw5W6zjm.js"),[]).then(h=>h.default),"../content/blog/how-to-use-scientific-calculator.md":()=>m(()=>import("./how-to-use-scientific-calculator-Cqh_FGwm.js"),[]).then(h=>h.default),"../content/blog/image-optimization-tips.md":()=>m(()=>import("./image-optimization-tips-2B_tb1WN.js"),[]).then(h=>h.default),"../content/blog/percentage-to-cgpa-conversion.md":()=>m(()=>import("./percentage-to-cgpa-conversion-DWlMET3v.js"),[]).then(h=>h.default),"../content/blog/qr-code-technology.md":()=>m(()=>import("./qr-code-technology-D9DBP1hz.js"),[]).then(h=>h.default),"../content/blog/secure-password-generator.md":()=>m(()=>import("./secure-password-generator-CUO9RRxD.js"),[]).then(h=>h.default),"../content/blog/tax-refund-calculator-2026.md":()=>m(()=>import("./tax-refund-calculator-2026-CnBNGAz1.js"),[]).then(h=>h.default),"../content/blog/time-zone-conversions.md":()=>m(()=>import("./time-zone-conversions-DjfG5UyA.js"),[]).then(h=>h.default),"../content/blog/trending-20260307.md":()=>m(()=>import("./trending-20260307-CSz7zNeU.js"),[]).then(h=>h.default),"../content/blog/unit-conversion-guide.md":()=>m(()=>import("./unit-conversion-guide-9SxT_pRl.js"),[]).then(h=>h.default)}),v=Object.keys(f).sort().reverse(),b=[];for(const h of v){const x=await f[h](),k=r(x);if(!k)continue;const P=k.meta,w={id:P.slug||((i=h.split("/").pop())==null?void 0:i.replace(".md",""))||h,title:P.title||"Untitled",slug:P.slug||((n=P.title)==null?void 0:n.toLowerCase().replace(/[^a-z0-9]+/g,"-"))||"",meta:P.meta||"",tags:P.tags||[],date:P.date||"",body:k.body||""};b.push(w)}if(t(b),a){const h=b.find(x=>x.slug===a);o(h||null)}}catch(f){console.error("Error loading blog posts:",f)}finally{d(!1)}})()},[a]);const r=u=>{const i=/^---\n([\s\S]*?)\n---\n([\s\S]*)$/,n=u.match(i);if(!n)return null;const f=n[1],v=n[2],b={};return f.split(`
`).forEach(h=>{const x=h.indexOf(":");if(x===-1)return;const k=h.slice(0,x).trim();let P=h.slice(x+1).trim();if(P.startsWith('"')&&P.endsWith('"')&&(P=P.slice(1,-1)),P.startsWith("[")&&P.endsWith("]"))try{b[k]=JSON.parse(P.replace(/'/g,'"'))}catch{b[k]=[]}else b[k]=P}),{meta:b,body:v}};return c?e.jsx(j,{children:e.jsx("div",{className:"max-w-4xl mx-auto px-6 py-20 text-center",children:e.jsx("p",{className:"text-slate-600",children:"Loading..."})})}):a&&s?e.jsxs(j,{children:[e.jsx(E,{title:s.title,description:s.meta,image:"https://stravotech.com/og-image.png"}),e.jsxs("div",{className:"max-w-4xl mx-auto px-6 py-12",children:[e.jsx(g,{to:"/blog",className:"text-indigo-600 hover:text-indigo-700 mb-8 inline-block",children:"← Back to Blog"}),e.jsxs("article",{className:"bg-white rounded-2xl p-8 border border-slate-100",children:[e.jsxs("header",{className:"mb-8 pb-8 border-b border-slate-200",children:[e.jsx("h1",{className:"text-4xl font-black text-slate-900 mb-4",children:s.title}),e.jsxs("div",{className:"flex items-center gap-4 text-sm text-slate-600 mb-4",children:[e.jsx("time",{children:new Date(s.date).toLocaleDateString()}),e.jsx("span",{children:"•"}),e.jsxs("span",{children:[Math.ceil(s.body.split(" ").length/200)," min read"]})]}),e.jsx("div",{className:"flex gap-2 flex-wrap",children:s.tags.map(u=>e.jsx("span",{className:"px-3 py-1 bg-indigo-100 text-indigo-700 text-xs font-bold rounded-full",children:u},u))})]}),e.jsx("div",{className:"prose prose-slate max-w-none",children:s.body.split(`
`).map((u,i)=>u.startsWith("# ")?e.jsx("h1",{className:"text-3xl font-black text-slate-900 mt-8 mb-4",children:u.slice(2)},i):u.startsWith("## ")?e.jsx("h2",{className:"text-2xl font-bold text-slate-900 mt-6 mb-3",children:u.slice(3)},i):u.startsWith("### ")?e.jsx("h3",{className:"text-xl font-bold text-slate-900 mt-4 mb-2",children:u.slice(4)},i):u.startsWith("- ")?e.jsx("li",{className:"ml-6 text-slate-700",children:u.slice(2)},i):u.trim()===""?e.jsx("div",{className:"h-4"},i):e.jsx("p",{className:"text-slate-700 leading-relaxed mb-3",children:u},i))})]}),l.length>1&&e.jsxs("section",{className:"mt-16",children:[e.jsx("h2",{className:"text-2xl font-black text-slate-900 mb-6",children:"More Articles"}),e.jsx("div",{className:"grid gap-4",children:l.filter(u=>u.slug!==a).slice(0,3).map(u=>e.jsxs(g,{to:`/blog/${u.slug}`,className:"p-4 border border-slate-200 rounded-lg hover:border-indigo-500 transition-colors",children:[e.jsx("h3",{className:"font-bold text-slate-900 hover:text-indigo-600",children:u.title}),e.jsx("p",{className:"text-sm text-slate-600",children:u.meta})]},u.slug))})]})]})]}):e.jsxs(j,{children:[e.jsx(E,{title:"Blog - Stravotech",description:"Read articles about calculators, finance tools, optimization, and more."}),e.jsxs("div",{className:"max-w-5xl mx-auto px-6 py-12",children:[e.jsxs("header",{className:"mb-12 text-center",children:[e.jsx("h1",{className:"text-4xl font-black text-slate-900 mb-4",children:"Blog"}),e.jsx("p",{className:"text-xl text-slate-600",children:"Tips, tricks, and insights about our tools"})]}),l.length===0?e.jsx("div",{className:"text-center py-12",children:e.jsx("p",{className:"text-slate-600",children:"No blog posts yet. Check back soon!"})}):e.jsx("div",{className:"grid gap-6",children:l.map(u=>e.jsx(g,{to:`/blog/${u.slug}`,children:e.jsxs("article",{className:"bg-white rounded-2xl p-8 border border-slate-100 hover:border-indigo-500 hover:shadow-lg transition-all",children:[e.jsxs("div",{className:"flex justify-between items-start gap-4 mb-3",children:[e.jsx("h2",{className:"text-2xl font-black text-slate-900 hover:text-indigo-600",children:u.title}),e.jsx("time",{className:"text-sm text-slate-500 whitespace-nowrap",children:new Date(u.date).toLocaleDateString()})]}),e.jsx("p",{className:"text-slate-600 mb-4",children:u.meta}),e.jsx("div",{className:"flex gap-2 flex-wrap",children:u.tags.map(i=>e.jsx("span",{className:"px-2 py-1 bg-slate-100 text-slate-700 text-xs font-bold rounded",children:i},i))})]})},u.slug))})]})]})},He=({template:a,onSelect:s})=>e.jsxs("div",{className:"cursor-pointer rounded overflow-hidden shadow-lg hover:scale-105 transform transition",onClick:()=>s(a),children:[e.jsx("img",{src:a.thumbnailUrl,alt:a.title,className:"w-full h-48 object-cover"}),e.jsx("div",{className:"p-2 bg-white",children:e.jsx("h3",{className:"text-sm font-semibold",children:a.title})})]}),Ke=[{id:"template-1",title:"Rainbow Splash Post",category:"post",thumbnailUrl:"/templates/holi/template-1.jpg",defaultText:"Happy Holi!"},{id:"template-2",title:"Color Burst Story",category:"story",thumbnailUrl:"/templates/holi/template-2.jpg"},{id:"template-3",title:"Traditional Card",category:"card",thumbnailUrl:"/templates/holi/template-3.jpg"},{id:"template-4",title:"Business Offer",category:"offer",thumbnailUrl:"/templates/holi/template-4.jpg"}],$e=async(a="",s)=>{let o=Ke;return s&&(o=o.filter(l=>l.category===s)),a&&(o=o.filter(l=>l.title.toLowerCase().includes(a.toLowerCase()))),o},Ve=async a=>{const s=U(A,"holiDesigns");await Se(s,{...a,createdAt:a.createdAt.toISOString()})},Je=async a=>{const s=U(A,"holiDesigns"),o=ke(s,Ne("userId","==",a));return(await te(o)).docs.map(t=>({id:t.id,...t.data()}))},Qe=({search:a,category:s,onSearchChange:o,onCategoryChange:l})=>e.jsxs("div",{className:"flex flex-col sm:flex-row sm:items-center sm:space-x-4 space-y-2",children:[e.jsx("input",{type:"text",className:"border rounded px-3 py-2 w-full sm:w-1/2",placeholder:"Search templates...",value:a,onChange:t=>o(t.target.value)}),e.jsxs("select",{className:"border rounded px-3 py-2 w-full sm:w-1/4",value:s||"",onChange:t=>l(t.target.value||void 0),children:[e.jsx("option",{value:"",children:"All Categories"}),e.jsx("option",{value:"post",children:"Post"}),e.jsx("option",{value:"story",children:"Story"}),e.jsx("option",{value:"card",children:"Card"}),e.jsx("option",{value:"offer",children:"Offer"})]})]}),Ye=({onTemplateSelect:a})=>{const[s,o]=p.useState([]),[l,t]=p.useState(""),[c,d]=p.useState(void 0);return p.useEffect(()=>{$e(l,c).then(o)},[l,c]),e.jsxs("div",{className:"space-y-4",children:[e.jsx(Qe,{search:l,category:c,onSearchChange:t,onCategoryChange:d}),e.jsx("div",{className:"grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4",children:s.map(r=>e.jsx(He,{template:r,onSelect:a},r.id))})]})},Xe=({templateUrl:a,templateId:s,onClose:o})=>{const l=p.useRef(null),[t,c]=p.useState(null),{user:d}=L();p.useEffect(()=>{if(l.current){const n=new G.fabric.Canvas(l.current,{width:800,height:800,backgroundColor:"#ffffff"});c(n),a&&G.fabric.Image.fromURL(a,f=>{f.set({selectable:!1,evented:!1}),n.setBackgroundImage(f,n.renderAll.bind(n))})}return()=>{t==null||t.dispose()}},[l,a]);const r=()=>{if(!t)return;const n=new G.fabric.IText("Your text here",{left:100,top:100,fontFamily:"Arial",fill:"#000",fontSize:32});t.add(n).setActiveObject(n)},u=n=>{if(!t)return;let f=null;d||(f=new G.fabric.Text("Made with Stravotech",{fontSize:20,fill:"rgba(255,255,255,0.7)",selectable:!1,evented:!1,originX:"center",originY:"center"}),f.set({left:t.getWidth()/2,top:t.getHeight()-30}),t.add(f));const v=t.toDataURL({format:n,quality:.9});f&&t.remove(f);const b=document.createElement("a");b.download=`holi-design.${n}`,b.href=v,b.click(),d&&s&&Ve({userId:d.uid,templateId:s,dataUrl:v,createdAt:new Date})},i=n=>{if(!t)return;const f=new FileReader;f.onload=v=>{var b;G.fabric.Image.fromURL((b=v.target)==null?void 0:b.result,h=>{h.scaleToWidth(200),t.add(h)})},f.readAsDataURL(n)};return e.jsx("div",{className:"fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50",children:e.jsxs("div",{className:"bg-white w-full max-w-4xl p-4 relative",children:[e.jsx("button",{className:"absolute top-2 right-2 text-gray-700",onClick:o,children:"✕"}),e.jsxs("div",{className:"flex",children:[e.jsx("div",{className:"flex-1",children:e.jsx("canvas",{ref:l,className:"border"})}),e.jsxs("div",{className:"w-64 pl-4 space-y-2",children:[e.jsx("button",{onClick:r,className:"btn",children:"Add text"}),e.jsx("input",{type:"file",accept:"image/*",onChange:n=>n.target.files&&i(n.target.files[0])}),e.jsx("button",{onClick:()=>u("png"),className:"btn",children:"Download PNG"}),e.jsx("button",{onClick:()=>u("jpeg"),className:"btn",children:"Download JPG"})]})]})]})})},Ze=({onClose:a})=>{const[s,o]=p.useState(""),[l,t]=p.useState(""),[c,d]=p.useState(null),r=async()=>{const i=new Ae;try{await Te(I,i),a&&a()}catch(n){d(n.message)}},u=async i=>{i.preventDefault();try{await ee(I,s,l),a&&a()}catch(n){d(n.message)}};return e.jsx("div",{className:"fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50",children:e.jsxs("div",{className:"bg-white p-4 rounded w-full max-w-sm",children:[e.jsx("h2",{className:"text-xl font-bold mb-4",children:"Login"}),c&&e.jsx("div",{className:"text-red-600 mb-2",children:c}),e.jsx("button",{onClick:r,className:"w-full btn mb-2",children:"Sign in with Google"}),e.jsxs("form",{onSubmit:u,className:"space-y-2",children:[e.jsx("input",{type:"email",placeholder:"Email",className:"border px-2 py-1 w-full",value:s,onChange:i=>o(i.target.value)}),e.jsx("input",{type:"password",placeholder:"Password",className:"border px-2 py-1 w-full",value:l,onChange:i=>t(i.target.value)}),e.jsx("button",{type:"submit",className:"btn w-full",children:"Sign in"})]}),e.jsx("button",{className:"mt-4 text-sm text-gray-600",onClick:a,children:"Cancel"})]})})},et=()=>{const[a,s]=p.useState(null),{user:o}=L(),[l,t]=p.useState(!1),c=d=>{if(!o){t(!0);return}s(d)};return e.jsxs("div",{className:"container mx-auto py-8",children:[e.jsx(E,{title:"Holi Wishes Generator – Create Happy Holi Greetings Online | Stravotech",description:"Wish your friends and family a happy Holi with our custom image generator. Choose from multiple templates and share personalized Holi wishes instantly.",keywords:"holi wishes generator, happy holi greeting maker, colorful holi images creator, holi 2026 wishes"}),e.jsx("h1",{className:"text-3xl font-bold mb-6 text-center text-pink-600 bg-gradient-to-r from-pink-300 via-yellow-300 to-green-300 py-4 rounded-lg",children:"Holi Wishes Generator"}),l&&e.jsx(Ze,{onClose:()=>t(!1)}),!a&&e.jsx(Ye,{onTemplateSelect:c}),a&&e.jsx(Xe,{templateId:a.id,templateUrl:a.thumbnailUrl,onClose:()=>s(null)})]})},tt=()=>{const{username:a}=O();p.useEffect(()=>{document.title=`Happy Holi from ${a}`},[a]);const s=()=>{const o=encodeURIComponent(`Happy Holi from ${a}!
${window.location.href}`);window.open(`https://wa.me/?text=${o}`,"_blank")};return e.jsxs("div",{className:"min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-pink-300 via-yellow-200 to-blue-300",children:[e.jsx(le,{recycle:!1}),e.jsxs("h1",{className:"text-4xl font-extrabold text-white drop-shadow-lg",children:["Happy Holi from ",a]}),e.jsx("button",{onClick:s,className:"mt-6 bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-lg",children:"Share on WhatsApp"})]})},at=()=>{const{user:a,loading:s}=L(),[o,l]=p.useState([]);return p.useEffect(()=>{a&&Je(a.uid).then(l)},[a]),s?e.jsx("div",{children:"Loading..."}):a?e.jsxs("div",{className:"container mx-auto py-8",children:[e.jsx("h1",{className:"text-2xl font-bold mb-4",children:"My Holi Designs"}),e.jsx("div",{className:"grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4",children:o.map(t=>e.jsxs("div",{className:"border p-2",children:[e.jsx("img",{src:t.dataUrl,alt:"design",className:"w-full"}),e.jsx("p",{className:"text-xs text-gray-500",children:new Date(t.createdAt).toLocaleString()})]},t.id))})]}):e.jsx("div",{children:"Please log in to see your designs."})},st=()=>{const[a,s]=p.useState(""),[o,l]=p.useState(""),[t,c]=p.useState(""),d=M(),r=async u=>{u.preventDefault(),c("");try{await C.login(a,o)?d("/admin"):c("Invalid Administrative Credentials")}catch{c("Authentication failed")}};return e.jsx("div",{className:"min-h-screen bg-slate-900 flex items-center justify-center p-6",children:e.jsxs("div",{className:"max-w-md w-full bg-white rounded-[2.5rem] p-12 shadow-2xl relative overflow-hidden",children:[e.jsx("div",{className:"absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 blur-3xl rounded-full"}),e.jsxs("div",{className:"text-center mb-10",children:[e.jsx("div",{className:"w-16 h-16 bg-slate-900 rounded-2xl flex items-center justify-center text-white mx-auto mb-6",children:e.jsx("i",{className:"fa-solid fa-lock text-2xl"})}),e.jsx("h2",{className:"text-3xl font-black text-slate-900 tracking-tight",children:"System Login"}),e.jsx("p",{className:"text-slate-400 font-bold mt-2",children:"Enter your admin credentials"})]}),e.jsxs("form",{onSubmit:r,className:"space-y-6",children:[e.jsxs("div",{children:[e.jsx("label",{className:"text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-3",children:"Gmail / Email Address"}),e.jsxs("div",{className:"relative",children:[e.jsx("i",{className:"fa-solid fa-envelope absolute left-5 top-1/2 -translate-y-1/2 text-slate-400"}),e.jsx("input",{type:"email",className:"w-full pl-12 pr-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl font-bold focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all",placeholder:"admin@stravotech.com",value:a,onChange:u=>s(u.target.value),required:!0})]})]}),e.jsxs("div",{children:[e.jsx("label",{className:"text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-3",children:"Admin Password"}),e.jsxs("div",{className:"relative",children:[e.jsx("i",{className:"fa-solid fa-key absolute left-5 top-1/2 -translate-y-1/2 text-slate-400"}),e.jsx("input",{type:"password",className:"w-full pl-12 pr-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl font-black focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all",placeholder:"••••••••",value:o,onChange:u=>l(u.target.value),required:!0})]})]}),t&&e.jsxs("div",{className:"bg-red-50 text-red-500 p-4 rounded-xl text-xs font-bold text-center animate-in fade-in zoom-in duration-300",children:[e.jsx("i",{className:"fa-solid fa-circle-exclamation mr-2"})," ",t]}),e.jsx("button",{className:"w-full py-5 bg-indigo-600 text-white font-black rounded-2xl shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all uppercase tracking-widest text-xs",children:"Authenticate Session"})]}),e.jsx("div",{className:"mt-8 text-center",children:e.jsx("span",{className:"text-xs text-slate-400 font-medium",children:"Stravotech Enterprise v4.2.0"})})]})})},ot=()=>{var v,b,h;const[a,s]=p.useState(null),[o,l]=p.useState([]),[t,c]=p.useState(!0),[d,r]=p.useState(null),[u,i]=p.useState(new Date),n=async()=>{try{r(null);const x=await qe();s(x);const k=await Be(5);l(k),i(new Date),console.log(`✓ Dashboard updated: ${x.totalTools} tools, ${x.liveTools} live, ${x.totalViews} views`)}catch(x){console.error("Dashboard error:",x),r("Failed to load dashboard data"),s({totalTools:0,liveTools:0,totalViews:0}),l([])}};p.useEffect(()=>{(async()=>{c(!0),await n(),c(!1)})()},[]),p.useEffect(()=>{const x=setInterval(n,5e3);return()=>clearInterval(x)},[]);const f=[{label:"Total Library",value:(v=a==null?void 0:a.totalTools)!=null?v:0,icon:"fa-boxes-stacked",color:"bg-indigo-500"},{label:"Live Tools",value:(b=a==null?void 0:a.liveTools)!=null?b:0,icon:"fa-signal",color:"bg-emerald-500"},{label:"Views",value:((h=a==null?void 0:a.totalViews)!=null?h:0).toLocaleString(),icon:"fa-eye",color:"bg-blue-500"},{label:"Avg Latency",value:"42ms",icon:"fa-bolt",color:"bg-amber-500"}];return e.jsxs("div",{className:"space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500",children:[e.jsxs("div",{className:"flex justify-between items-center",children:[e.jsxs("div",{className:"text-sm text-slate-600",children:[e.jsx("span",{className:"font-semibold",children:"Last updated:"})," ",u.toLocaleTimeString()]}),e.jsxs("button",{onClick:()=>n(),className:"px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-bold rounded-lg transition-all active:scale-95",children:[e.jsx("i",{className:"fa-solid fa-arrows-rotate mr-2"}),"Refresh Now"]})]}),d&&e.jsxs("div",{className:"bg-red-50 border border-red-200 rounded-lg p-4 text-red-700 text-sm",children:[e.jsx("strong",{children:"Warning:"})," ",d,". Displaying fallback data."]}),t&&e.jsx("div",{className:"flex justify-center items-center py-8",children:e.jsxs("div",{className:"text-slate-500",children:[e.jsx("i",{className:"fa-solid fa-spinner animate-spin text-2xl mr-3"}),"Loading stats..."]})}),!t&&e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"grid md:grid-cols-4 gap-6",children:f.map(x=>e.jsxs("div",{className:"bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm flex items-center space-x-6",children:[e.jsx("div",{className:`w-14 h-14 ${x.color} rounded-2xl flex items-center justify-center text-white text-xl shadow-lg`,children:e.jsx("i",{className:`fa-solid ${x.icon}`})}),e.jsxs("div",{children:[e.jsx("span",{className:"text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1",children:x.label}),e.jsx("span",{className:"text-2xl font-black text-slate-900",children:typeof x.value=="number"?x.value.toLocaleString():x.value})]})]},x.label))}),e.jsxs("div",{className:"grid lg:grid-cols-2 gap-8",children:[e.jsxs("div",{className:"bg-white p-10 rounded-[2.5rem] border border-slate-100 shadow-sm",children:[e.jsxs("div",{className:"flex justify-between items-center mb-8",children:[e.jsx("h3",{className:"text-xl font-black text-slate-900",children:"Top Traffic Pages"}),e.jsx("span",{className:"text-[10px] font-black text-indigo-500 uppercase",children:"Live Data"})]}),e.jsx("div",{className:"space-y-6",children:o.length>0?o.map((x,k)=>{var N;const P=((N=o[0])==null?void 0:N.views)||1,w=x.views/P*100;return e.jsxs("div",{className:"space-y-2",children:[e.jsxs("div",{className:"flex justify-between text-xs font-black text-slate-600",children:[e.jsx("span",{children:x.name}),e.jsx("span",{children:(x.views||0).toLocaleString()})]}),e.jsx("div",{className:"h-2 w-full bg-slate-50 rounded-full overflow-hidden",children:e.jsx("div",{style:{width:`${w}%`},className:"h-full bg-indigo-500 rounded-full"})})]},x.id)}):e.jsx("div",{className:"text-center py-8 text-slate-500",children:e.jsx("p",{className:"text-sm",children:"No tools with views yet"})})})]}),e.jsxs("div",{className:"bg-slate-900 p-10 rounded-[2.5rem] text-white relative overflow-hidden",children:[e.jsx("div",{className:"absolute top-0 right-0 w-64 h-64 bg-indigo-600/20 blur-3xl"}),e.jsx("h3",{className:"text-xl font-black mb-2",children:"Quick Toggles"}),e.jsx("p",{className:"text-slate-400 text-sm mb-8",children:"Global system overrides"}),e.jsx("div",{className:"space-y-4",children:[{name:"Maintenance Mode",status:"OFF"},{name:"API Caching",status:"ON"},{name:"Cloud CDN",status:"ON"}].map(x=>e.jsxs("div",{className:"flex justify-between items-center p-4 bg-slate-800 rounded-2xl",children:[e.jsx("span",{className:"font-bold text-sm",children:x.name}),e.jsx("button",{className:`px-4 py-1.5 rounded-lg text-[10px] font-black uppercase ${x.status==="ON"?"bg-emerald-500/20 text-emerald-400":"bg-slate-700 text-slate-500"}`,children:x.status})]},x.name))})]})]})]})]})},rt=()=>{const[a,s]=p.useState(C.getMergedTools()),[o,l]=p.useState(""),[t]=ce(I),c=async(r,u)=>{if(!(t!=null&&t.email)){alert("You must be logged in");return}const i=u==="ON"?"OFF":"ON",n=i==="ON";try{await Le(r,n,t.email),C.updateTool(r,{status:i}),s(C.getMergedTools())}catch(f){console.error("Error toggling tool:",f),alert(`Failed to ${n?"enable":"disable"} tool: ${f}`)}},d=a.filter(r=>r.name.toLowerCase().includes(o.toLowerCase()));return e.jsxs("div",{className:"bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden animate-in fade-in duration-500",children:[e.jsxs("div",{className:"p-10 border-b border-slate-100 flex justify-between items-center",children:[e.jsx("h3",{className:"text-xl font-black text-slate-900",children:"Tool Library Management"}),e.jsxs("div",{className:"relative w-64",children:[e.jsx("i",{className:"fa-solid fa-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"}),e.jsx("input",{type:"text",placeholder:"Filter tools...",className:"w-full pl-12 pr-4 py-2.5 bg-slate-50 border border-slate-100 rounded-xl text-xs font-bold outline-none focus:ring-2 focus:ring-indigo-500",value:o,onChange:r=>l(r.target.value)})]})]}),e.jsx("div",{className:"overflow-x-auto",children:e.jsxs("table",{className:"w-full text-left",children:[e.jsx("thead",{children:e.jsxs("tr",{className:"bg-slate-50/50",children:[e.jsx("th",{className:"px-10 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest",children:"Tool Name"}),e.jsx("th",{className:"px-6 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest",children:"URL Slug"}),e.jsx("th",{className:"px-6 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest",children:"SEO Status"}),e.jsx("th",{className:"px-6 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center",children:"Visibility"})]})}),e.jsx("tbody",{className:"divide-y divide-slate-100",children:d.map(r=>e.jsxs("tr",{className:"hover:bg-slate-50/50 transition-colors",children:[e.jsx("td",{className:"px-10 py-6",children:e.jsxs("div",{className:"flex items-center space-x-4",children:[e.jsx("div",{className:"w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center text-slate-500",children:e.jsx("i",{className:`fa-solid ${r.icon}`})}),e.jsx("span",{className:"font-bold text-slate-900",children:r.name})]})}),e.jsxs("td",{className:"px-6 py-6 text-xs font-mono text-slate-400",children:["/",r.id]}),e.jsx("td",{className:"px-6 py-6",children:e.jsxs("div",{className:"flex space-x-2",children:[e.jsx("span",{className:`w-2 h-2 rounded-full ${r.seoTitle?"bg-emerald-500":"bg-amber-400"}`}),e.jsx("span",{className:"text-[10px] font-black text-slate-400 uppercase",children:r.seoTitle?"Optimized":"Default"})]})}),e.jsx("td",{className:"px-6 py-6 text-center",children:e.jsx("button",{onClick:()=>c(r.id,r.status||"ON"),className:`px-5 py-2 rounded-xl text-[10px] font-black uppercase transition-all ${r.status==="OFF"?"bg-red-50 text-red-500":"bg-emerald-50 text-emerald-600"}`,children:r.status==="OFF"?"Disabled":"Enabled"})})]},r.id))})]})})]})},nt=()=>{const[a,s]=p.useState(C.getMergedTools()),[o,l]=p.useState(null),t=a.find(i=>i.id===o),[c,d]=p.useState({seoTitle:"",seoDescription:"",canonicalUrl:""}),r=i=>{const n=a.find(f=>f.id===i);n&&(l(i),d({seoTitle:n.seoTitle||"",seoDescription:n.seoDescription||"",canonicalUrl:n.canonicalUrl||`https://stravotech.com/#${n.path}`}))},u=()=>{o&&(C.updateTool(o,c),s(C.getMergedTools()),alert("SEO Metadata Synchronized Successfully!"))};return e.jsxs("div",{className:"grid lg:grid-cols-3 gap-10 animate-in fade-in duration-500",children:[e.jsxs("div",{className:"lg:col-span-1 space-y-4 h-[700px] overflow-y-auto pr-4 custom-scrollbar",children:[e.jsx("h4",{className:"text-[10px] font-black text-slate-400 uppercase tracking-widest px-4 mb-4",children:"Select Tool to Optimize"}),a.map(i=>e.jsxs("button",{onClick:()=>r(i.id),className:`w-full text-left p-5 rounded-2xl border transition-all flex items-center space-x-4 ${o===i.id?"bg-white border-indigo-500 shadow-xl shadow-indigo-50":"bg-white border-slate-100 hover:border-slate-300"}`,children:[e.jsx("div",{className:`w-10 h-10 rounded-xl flex items-center justify-center ${o===i.id?"bg-indigo-600 text-white":"bg-slate-50 text-slate-400"}`,children:e.jsx("i",{className:`fa-solid ${i.icon}`})}),e.jsxs("div",{children:[e.jsx("span",{className:"block font-bold text-sm text-slate-900",children:i.name}),e.jsx("span",{className:"text-[10px] text-slate-400 font-bold uppercase",children:i.id})]})]},i.id))]}),e.jsx("div",{className:"lg:col-span-2",children:o?e.jsxs("div",{className:"bg-white p-12 rounded-[2.5rem] border border-slate-100 shadow-sm space-y-10 sticky top-10",children:[e.jsxs("div",{className:"flex justify-between items-end border-b border-slate-100 pb-8",children:[e.jsxs("div",{children:[e.jsx("h3",{className:"text-2xl font-black text-slate-900 tracking-tight",children:"Editing Metadata"}),e.jsxs("p",{className:"text-slate-400 font-bold text-sm",children:["Path: ",t==null?void 0:t.path]})]}),e.jsx("div",{className:"flex space-x-3",children:e.jsx("button",{onClick:u,className:"px-8 py-3 bg-indigo-600 text-white font-black rounded-xl text-xs uppercase tracking-widest shadow-lg shadow-indigo-100",children:"Save Changes"})})]}),e.jsxs("div",{className:"space-y-8",children:[e.jsxs("div",{children:[e.jsx("label",{className:"text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-3",children:"SEO Title (Target 50-60 chars)"}),e.jsx("input",{className:"w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl font-bold focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all",value:c.seoTitle,onChange:i=>d({...c,seoTitle:i.target.value}),placeholder:"e.g. Best Free GPA Calculator | Stravotech"})]}),e.jsxs("div",{children:[e.jsx("label",{className:"text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-3",children:"Meta Description (Target 150-160 chars)"}),e.jsx("textarea",{className:"w-full h-32 px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl font-bold focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all resize-none",value:c.seoDescription,onChange:i=>d({...c,seoDescription:i.target.value}),placeholder:"A highly accurate, free GPA calculator for students in the USA and Canada..."})]}),e.jsxs("div",{children:[e.jsx("label",{className:"text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-3",children:"Canonical URL"}),e.jsx("input",{className:"w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl font-mono text-xs focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all",value:c.canonicalUrl,onChange:i=>d({...c,canonicalUrl:i.target.value})})]})]}),e.jsxs("div",{className:"mt-12 p-8 bg-slate-50 rounded-3xl border border-slate-200 border-dashed",children:[e.jsx("h4",{className:"text-[10px] font-black text-slate-400 uppercase tracking-widest mb-6",children:"Google SERP Preview"}),e.jsxs("div",{className:"max-w-md",children:[e.jsx("div",{className:"text-[#1a0dab] text-xl font-medium mb-1 truncate hover:underline cursor-pointer",children:c.seoTitle||(t==null?void 0:t.name)}),e.jsx("div",{className:"text-[#006621] text-sm mb-1",children:c.canonicalUrl}),e.jsx("div",{className:"text-[#545454] text-sm leading-relaxed line-clamp-2",children:c.seoDescription||(t==null?void 0:t.description)})]})]})]}):e.jsxs("div",{className:"h-full flex flex-col items-center justify-center bg-slate-100/50 border-2 border-dashed border-slate-200 rounded-[3rem] p-20 text-center",children:[e.jsx("div",{className:"w-20 h-20 bg-white rounded-3xl shadow-sm flex items-center justify-center text-slate-300 text-3xl mb-6",children:e.jsx("i",{className:"fa-solid fa-edit"})}),e.jsx("h3",{className:"text-xl font-black text-slate-900 mb-2",children:"Editor Inactive"}),e.jsx("p",{className:"text-slate-400 font-bold max-w-xs",children:"Select a tool from the library sidebar to begin optimizing its search engine profile."})]})})]})},it=a=>{const s=/^---\n([\s\S]*?)\n---\n([\s\S]*)$/,o=a.match(s);if(!o)return null;const l=o[1],t=o[2],c={};return l.split(`
`).forEach(d=>{const r=d.indexOf(":");if(r===-1)return;const u=d.slice(0,r).trim();let i=d.slice(r+1).trim();if(i.startsWith('"')&&i.endsWith('"')&&(i=i.slice(1,-1)),i.startsWith("[")&&i.endsWith("]"))try{c[u]=JSON.parse(i.replace(/'/g,'"'))}catch{c[u]=[]}else c[u]=i}),{meta:c,body:t}},lt=()=>{const[a,s]=p.useState([]),[o,l]=p.useState(!1);p.useEffect(()=>{const d=Object.assign({"../../content/blog/best-free-tools-for-college-students-2026.md":()=>m(()=>import("./best-free-tools-for-college-students-2026-CGDhrIhE.js"),[]).then(r=>r.default),"../../content/blog/compound-interest-monthly-calculator.md":()=>m(()=>import("./compound-interest-monthly-calculator-axheGYXd.js"),[]).then(r=>r.default),"../../content/blog/financial-planning-guide.md":()=>m(()=>import("./financial-planning-guide-t7XEfE_q.js"),[]).then(r=>r.default),"../../content/blog/getting-started-with-calculators.md":()=>m(()=>import("./getting-started-with-calculators-L2RlNduj.js"),[]).then(r=>r.default),"../../content/blog/gpa-calculation-tips.md":()=>m(()=>import("./gpa-calculation-tips-BgaqQYpy.js"),[]).then(r=>r.default),"../../content/blog/gpa-vs-cgpa-explained.md":()=>m(()=>import("./gpa-vs-cgpa-explained-DI_xKLd3.js"),[]).then(r=>r.default),"../../content/blog/gst-calculator-india.md":()=>m(()=>import("./gst-calculator-india-0Joy8shr.js"),[]).then(r=>r.default),"../../content/blog/how-emi-is-calculated.md":()=>m(()=>import("./how-emi-is-calculated-CypYQtXB.js"),[]).then(r=>r.default),"../../content/blog/how-to-calculate-gpa-step-by-step.md":()=>m(()=>import("./how-to-calculate-gpa-step-by-step-C3gLthVD.js"),[]).then(r=>r.default),"../../content/blog/how-to-improve-your-gpa.md":()=>m(()=>import("./how-to-improve-your-gpa-Dw5W6zjm.js"),[]).then(r=>r.default),"../../content/blog/how-to-use-scientific-calculator.md":()=>m(()=>import("./how-to-use-scientific-calculator-Cqh_FGwm.js"),[]).then(r=>r.default),"../../content/blog/image-optimization-tips.md":()=>m(()=>import("./image-optimization-tips-2B_tb1WN.js"),[]).then(r=>r.default),"../../content/blog/percentage-to-cgpa-conversion.md":()=>m(()=>import("./percentage-to-cgpa-conversion-DWlMET3v.js"),[]).then(r=>r.default),"../../content/blog/qr-code-technology.md":()=>m(()=>import("./qr-code-technology-D9DBP1hz.js"),[]).then(r=>r.default),"../../content/blog/secure-password-generator.md":()=>m(()=>import("./secure-password-generator-CUO9RRxD.js"),[]).then(r=>r.default),"../../content/blog/tax-refund-calculator-2026.md":()=>m(()=>import("./tax-refund-calculator-2026-CnBNGAz1.js"),[]).then(r=>r.default),"../../content/blog/time-zone-conversions.md":()=>m(()=>import("./time-zone-conversions-DjfG5UyA.js"),[]).then(r=>r.default),"../../content/blog/trending-20260307.md":()=>m(()=>import("./trending-20260307-CSz7zNeU.js"),[]).then(r=>r.default),"../../content/blog/unit-conversion-guide.md":()=>m(()=>import("./unit-conversion-guide-9SxT_pRl.js"),[]).then(r=>r.default)});(async()=>{var i,n;const r=Object.keys(d).sort(),u=[];for(const f of r){const v=await d[f](),b=it(v);if(!b)continue;const h=b.meta;u.push({id:h.slug||((i=f.split("/").pop())==null?void 0:i.replace(".md",""))||f,title:h.title||"Untitled",slug:h.slug||((n=h.title)==null?void 0:n.toLowerCase().replace(/[^a-z0-9]+/g,"-"))||"",meta:h.meta||"",tags:h.tags||[],date:h.date||"",body:b.body||""})}s(u)})()},[]);const t=async d=>{if(!C.getAuth())return alert("Unauthorized: please sign in as admin");l(!0);try{await Q(d.slug||d.id,d),alert(`Published: ${d.title}`)}catch(r){console.error(r),alert("Publish failed. See console.")}finally{l(!1)}},c=async()=>{if(!C.getAuth())return alert("Unauthorized: please sign in as admin");if(!a.length)return alert("No articles to publish");l(!0);let d=0;for(let r=0;r<a.length;r++){const u=a[r];try{await Q(u.slug||u.id,u),d++}catch(i){console.error("Publish failed for",u.slug,i)}}l(!1),alert(`Published ${d} / ${a.length} articles`)};return e.jsxs("div",{className:"space-y-8",children:[e.jsx("h2",{className:"text-2xl font-black",children:"Content Publisher"}),e.jsxs("p",{className:"text-sm text-slate-500",children:["Load markdown briefs from ",e.jsx("code",{children:"content/blog/"})," and publish to Firestore as articles."]}),e.jsxs("div",{className:"grid md:grid-cols-2 gap-6",children:[e.jsx("div",{className:"md:col-span-2 flex justify-end",children:e.jsx("button",{disabled:o,onClick:c,className:"px-4 py-2 bg-indigo-600 text-white rounded-lg font-bold",children:"Publish All"})}),a.map(d=>e.jsxs("div",{className:"bg-white p-6 rounded-2xl border border-slate-100 shadow-sm",children:[e.jsx("h3",{className:"font-bold text-lg mb-2",children:d.title}),e.jsxs("p",{className:"text-xs text-slate-500 mb-4",children:["slug: ",d.slug," • tags: ",d.tags.join(", ")]}),e.jsx("p",{className:"text-sm text-slate-700 mb-4 line-clamp-4",children:d.meta}),e.jsxs("div",{className:"flex space-x-3",children:[e.jsx("button",{disabled:o,onClick:()=>t(d),className:"px-4 py-2 bg-emerald-600 text-white rounded-lg font-bold",children:"Publish"}),e.jsx("a",{className:"px-4 py-2 bg-slate-100 rounded-lg",href:`/#/admin/editor?slug=${d.slug}`,children:"Edit"})]})]},d.id))]})]})},ct=()=>{const{pathname:a,hash:s}=B();return p.useEffect(()=>{if(s){const o=s.replace("#",""),l=document.getElementById(o);l&&l.scrollIntoView({behavior:"smooth"})}else window.scrollTo(0,0)},[a,s]),null},R=({children:a})=>C.getAuth()?e.jsx(Ge,{children:a}):e.jsx(X,{to:"/admin/login",replace:!0}),dt=()=>{const{toolId:a}=O(),o=C.getMergedTools().find(l=>l.id===a);return o?e.jsx(X,{to:`/${o.category}/${o.id}`,replace:!0}):e.jsx(j,{children:e.jsx(se,{})})},ut=()=>{const[a,s]=p.useState(null),[o,l]=p.useState(!0);return p.useEffect(()=>{const t=I.onAuthStateChanged(c=>{s(c),l(!1)});return()=>t()},[]),a==null||a.email,e.jsx(e.Fragment,{children:e.jsxs(de,{children:[e.jsx(ct,{}),e.jsxs(ue,{children:[e.jsx(y,{path:"/",element:e.jsx(j,{children:e.jsx(se,{})})}),e.jsx(y,{path:"/blog",element:e.jsx(Y,{})}),e.jsx(y,{path:"/blog/:slug",element:e.jsx(Y,{})}),e.jsx(y,{path:"/compress-image-to-50kb",element:e.jsx(j,{children:e.jsx(S,{})})}),e.jsx(y,{path:"/compress-image-to-100kb",element:e.jsx(j,{children:e.jsx(S,{})})}),e.jsx(y,{path:"/jpeg-compressor-online",element:e.jsx(j,{children:e.jsx(S,{})})}),e.jsx(y,{path:"/resize-image-online",element:e.jsx(j,{children:e.jsx(S,{})})}),e.jsx(y,{path:"/income-tax-calculator-india",element:e.jsx(j,{children:e.jsx(S,{})})}),e.jsx(y,{path:"/gst-calculator-india",element:e.jsx(j,{children:e.jsx(S,{})})}),e.jsx(y,{path:"/gpa-calculator-from-percentage",element:e.jsx(j,{children:e.jsx(S,{})})}),e.jsx(y,{path:"/cgpa-to-percentage",element:e.jsx(j,{children:e.jsx(S,{})})}),e.jsx(y,{path:"/percentage-calculator-marks",element:e.jsx(j,{children:e.jsx(S,{})})}),e.jsx(y,{path:"/:category/:toolId",element:e.jsx(j,{children:e.jsx(ze,{})})}),e.jsx(y,{path:"/about",element:e.jsx(j,{children:e.jsx(_,{type:"about"})})}),e.jsx(y,{path:"/privacy",element:e.jsx(j,{children:e.jsx(_,{type:"privacy"})})}),e.jsx(y,{path:"/terms",element:e.jsx(j,{children:e.jsx(_,{type:"terms"})})}),e.jsx(y,{path:"/contact",element:e.jsx(j,{children:e.jsx(_,{type:"contact"})})}),e.jsx(y,{path:"/disclaimer",element:e.jsx(j,{children:e.jsx(_,{type:"disclaimer"})})}),e.jsx(y,{path:"/holi-generator",element:e.jsx(j,{children:e.jsx(et,{})})}),e.jsx(y,{path:"/holi/:username",element:e.jsx(tt,{})}),e.jsx(y,{path:"/holi/dashboard",element:e.jsx(j,{children:e.jsx(at,{})})}),e.jsx(y,{path:"/:toolId",element:e.jsx(dt,{})}),e.jsx(y,{path:"/admin/login",element:e.jsx(st,{})}),e.jsx(y,{path:"/admin",element:e.jsx(R,{children:e.jsx(ot,{})})}),e.jsx(y,{path:"/admin/tools",element:e.jsx(R,{children:e.jsx(rt,{})})}),e.jsx(y,{path:"/admin/seo",element:e.jsx(R,{children:e.jsx(nt,{})})}),e.jsx(y,{path:"/admin/publisher",element:e.jsx(R,{children:e.jsx(lt,{})})})]})]})})};class mt extends Z.Component{constructor(s){super(s),this.state={hasError:!1}}static getDerivedStateFromError(s){return{hasError:!0,error:s}}componentDidCatch(s,o){console.error("ErrorBoundary caught:",s,o)}render(){return this.state.hasError?e.jsxs("div",{style:{padding:32,fontFamily:"Plus Jakarta Sans, sans-serif"},children:[e.jsx("h1",{style:{color:"#111827"},children:"Something went wrong"}),e.jsx("p",{style:{color:"#374151"},children:"An error occurred while rendering the application. Details are shown below (also logged to console)."}),e.jsx("pre",{style:{background:"#f3f4f6",padding:16,borderRadius:8,overflow:"auto",color:"#111827"},children:this.state.error?String(this.state.error.stack||this.state.error.message):"Unknown error"})]}):this.props.children}}console.log("Bootstrapping Stravotech app...");const ne=document.getElementById("root");if(!ne)throw new Error("Could not find root element to mount to");const ht=me.createRoot(ne);ht.render(e.jsx(Z.StrictMode,{children:e.jsx(he,{children:e.jsx(mt,{children:e.jsx(ut,{})})})}));export{ft as S};
